import { useState, useEffect } from "react";
import { ChevronLeft, ChevronRight, ChevronDown } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { useNavigate } from "react-router-dom";
import heroRealEstate from "@/assets/hero-real-estate.jpg";
import heroIndustrial from "@/assets/hero-industrial.jpg";
import heroAgriculture from "@/assets/hero-agriculture.jpg";

const slides = [
  {
    image: heroRealEstate,
    title: "Exceptional Real Estate",
    subtitle: "Creating sustainable living spaces for modern Egypt",
  },
  {
    image: heroIndustrial,
    title: "Industrial Excellence",
    subtitle: "Powering Egypt's industrial transformation",
  },
  {
    image: heroAgriculture,
    title: "Agricultural Innovation",
    subtitle: "Cultivating Egypt's agricultural future",
  },
];

const HeroSlider = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % slides.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => setCurrentSlide((prev) => (prev + 1) % slides.length);
  const prevSlide = () => setCurrentSlide((prev) => (prev - 1 + slides.length) % slides.length);

  return (
    <section className="relative h-screen w-full overflow-hidden">
      {slides.map((slide, index) => (
        <div
          key={index}
          className={`absolute inset-0 transition-opacity duration-1000 ${
            index === currentSlide ? "opacity-100" : "opacity-0"
          }`}
        >
          <img src={slide.image} alt={slide.title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-b from-brand-blue/70 via-brand-blue/50 to-brand-blue/85" />
        </div>
      ))}

      <div className="relative h-full flex items-center justify-center">
        <div className="container mx-auto px-4 lg:px-8 text-center">
          <div className="max-w-4xl mx-auto animate-fade-in">
            <h1 className="text-5xl md:text-7xl font-serif font-bold text-white mb-6">
              {t("hero.title")}
            </h1>
            <p className="text-xl md:text-2xl text-brand-green-light mb-4 font-light">
              {slides[currentSlide].subtitle}
            </p>
            <p className="text-lg text-white/90 mb-12 max-w-2xl mx-auto">
              {t("hero.subtitle")}
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Button
                size="lg"
                className="bg-brand-green text-white hover:bg-brand-green-light font-semibold px-8"
                onClick={() => navigate('/projects')}
              >
                {t("hero.cta.projects")}
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-brand-blue font-semibold px-8"
                onClick={() => navigate('/about')}
              >
                {t("hero.cta.about")}
              </Button>
            </div>
          </div>
        </div>
      </div>

      <button
        onClick={prevSlide}
        className="absolute left-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-brand-green hover:text-white transition-all duration-300"
      >
        <ChevronLeft className="w-6 h-6" />
      </button>
      <button
        onClick={nextSlide}
        className="absolute right-4 top-1/2 -translate-y-1/2 w-12 h-12 rounded-full bg-white/10 backdrop-blur-sm flex items-center justify-center text-white hover:bg-brand-green hover:text-white transition-all duration-300"
      >
        <ChevronRight className="w-6 h-6" />
      </button>

      <div className="absolute bottom-24 left-1/2 -translate-x-1/2 flex space-x-3">
        {slides.map((_, index) => (
          <button
            key={index}
            onClick={() => setCurrentSlide(index)}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentSlide ? "bg-brand-green w-8" : "bg-white/40 hover:bg-white/60"
            }`}
          />
        ))}
      </div>

      <div className="absolute bottom-8 left-1/2 -translate-x-1/2 animate-bounce">
        <ChevronDown className="w-8 h-8 text-brand-green" />
      </div>
    </section>
  );
};

export default HeroSlider;
