import { Eye, Target } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";

interface VMItem {
  title?: { en: string; ar: string };
  text: { en: string; ar: string };
}

interface Props {
  vision: VMItem[];
  mission: VMItem[];
}

const SectorVisionMission = ({ vision, mission }: Props) => {
  const { language } = useLanguage();
  const isAr = language === "ar";

  const renderItems = (items: VMItem[]) => (
    <ul className="space-y-3 text-muted-foreground leading-relaxed">
      {items.map((item, i) => (
        <li key={i} className="flex gap-3">
          <span className="text-brand-green font-bold mt-1">•</span>
          <div>
            {item.title && (
              <span className="text-foreground font-semibold">
                {isAr ? item.title.ar : item.title.en}:{" "}
              </span>
            )}
            <span>{isAr ? item.text.ar : item.text.en}</span>
          </div>
        </li>
      ))}
    </ul>
  );

  return (
    <section className="py-20 bg-muted" dir={isAr ? "rtl" : "ltr"}>
      <div className="container mx-auto px-4 lg:px-8">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          <Card className="bg-card border-brand-green/30 hover:shadow-brand transition-all duration-300">
            <CardContent className="p-10">
              <div className="w-14 h-14 rounded-full bg-brand-green/10 flex items-center justify-center mb-6">
                <Eye className="w-7 h-7 text-brand-green" />
              </div>
              <h3 className="text-3xl font-serif font-bold mb-6">
                {isAr ? "الرؤية" : "Vision"}
              </h3>
              {renderItems(vision)}
            </CardContent>
          </Card>

          <Card className="bg-card border-brand-green/30 hover:shadow-brand transition-all duration-300">
            <CardContent className="p-10">
              <div className="w-14 h-14 rounded-full bg-brand-green/10 flex items-center justify-center mb-6">
                <Target className="w-7 h-7 text-brand-green" />
              </div>
              <h3 className="text-3xl font-serif font-bold mb-6">
                {isAr ? "الرسالة" : "Mission"}
              </h3>
              {renderItems(mission)}
            </CardContent>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default SectorVisionMission;