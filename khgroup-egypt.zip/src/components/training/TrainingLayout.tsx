import { useEffect } from "react";
import { Outlet, useNavigate } from "react-router-dom";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import TrainingNav from "./TrainingNav";

const TrainingLayout = () => {
  const { user, loading } = useTrainingAuthContext();
  const navigate = useNavigate();

  useEffect(() => {
    if (!loading && !user) {
      navigate("/training/login", { replace: true });
    }
  }, [user, loading, navigate]);

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-primary" />
      </div>
    );
  }

  if (!user) return null;

  return (
    <div className="min-h-screen bg-background">
      <TrainingNav />
      <main className="container mx-auto px-4 lg:px-8 py-6">
        <Outlet />
      </main>
    </div>
  );
};

export default TrainingLayout;
