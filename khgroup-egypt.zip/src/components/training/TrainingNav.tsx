import { Link, useLocation } from "react-router-dom";
import { LayoutDashboard, Building2, Map, ClipboardList, LogOut, Globe, Shield } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import khLogo from "@/assets/kh-logo.png";

const TrainingNav = () => {
  const { signOut, profile, isAdmin } = useTrainingAuthContext();
  const { language, setLanguage } = useLanguage();
  const location = useLocation();

  const links = [
    { path: "/training/dashboard", icon: LayoutDashboard, label: language === "ar" ? "لوحة التحكم" : "Dashboard" },
    { path: "/training/departments", icon: Building2, label: language === "ar" ? "الأقسام" : "Departments" },
    { path: "/training/roadmap", icon: Map, label: language === "ar" ? "خارطة الطريق" : "Roadmap" },
    { path: "/training/plan", icon: ClipboardList, label: language === "ar" ? "الخطة الكاملة" : "Full Plan" },
    ...(isAdmin ? [{ path: "/training/admin", icon: Shield, label: language === "ar" ? "الإدارة" : "Admin" }] : []),
  ];

  const isActive = (path: string) => location.pathname === path;

  return (
    <nav className="sticky top-0 z-50 bg-white border-b border-border shadow-sm">
      <div className="container mx-auto px-4 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center gap-6">
            <Link to="/training/dashboard" className="flex items-center gap-2">
              <img src={khLogo} alt="KH Group" className="h-10 w-auto" />
              <span className="hidden sm:block text-sm font-semibold text-secondary">
                {language === "ar" ? "بوابة التدريب" : "AI Training Portal"}
              </span>
            </Link>

            <div className="hidden md:flex items-center gap-1">
              {links.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={`flex items-center gap-2 px-3 py-2 rounded-md text-sm font-medium transition-colors ${
                    isActive(link.path)
                      ? "bg-primary/10 text-primary"
                      : "text-muted-foreground hover:text-foreground hover:bg-muted"
                  }`}
                >
                  <link.icon className="w-4 h-4" />
                  {link.label}
                </Link>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-3">
            {profile && (
              <span className="hidden sm:block text-sm text-muted-foreground">
                {profile.full_name}
              </span>
            )}
            <Button
              variant="ghost"
              size="sm"
              onClick={() => setLanguage(language === "en" ? "ar" : "en")}
            >
              <Globe className="w-4 h-4" />
              <span className="ml-1">{language === "en" ? "EN" : "AR"}</span>
            </Button>
            <Button variant="ghost" size="sm" onClick={signOut}>
              <LogOut className="w-4 h-4" />
            </Button>
          </div>
        </div>

        {/* Mobile nav */}
        <div className="md:hidden flex gap-1 pb-2 overflow-x-auto">
          {links.map((link) => (
            <Link
              key={link.path}
              to={link.path}
              className={`flex items-center gap-1.5 px-3 py-1.5 rounded-md text-xs font-medium whitespace-nowrap transition-colors ${
                isActive(link.path)
                  ? "bg-primary/10 text-primary"
                  : "text-muted-foreground hover:bg-muted"
              }`}
            >
              <link.icon className="w-3.5 h-3.5" />
              {link.label}
            </Link>
          ))}
        </div>
      </div>
    </nav>
  );
};

export default TrainingNav;
