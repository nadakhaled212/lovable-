import { Link } from "react-router-dom";
import { Facebook, Twitter, Instagram, Linkedin, Mail, Phone, MapPin } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import khLogoLight from "@/assets/kh-logo-light.png";

const Footer = () => {
  const currentYear = new Date().getFullYear();
  const { t } = useLanguage();

  return (
    <footer className="bg-secondary text-secondary-foreground">
      <div className="container mx-auto px-4 lg:px-8 py-12">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {/* Company Info */}
          <div>
            <div className="flex items-center space-x-2 mb-4">
              <img src={khLogoLight} alt="KH Group" className="h-12 w-auto" />
            </div>
            <p className="text-white/70 text-sm leading-relaxed">
              {t("footer.description")}
            </p>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-white font-semibold mb-4">{t("footer.quicklinks")}</h3>
            <ul className="space-y-2">
              <li><Link to="/about" className="text-white/70 hover:text-brand-green text-sm transition-colors">{t("nav.about")}</Link></li>
              <li><Link to="/projects" className="text-white/70 hover:text-brand-green text-sm transition-colors">{t("nav.projects")}</Link></li>
              <li><Link to="/news" className="text-white/70 hover:text-brand-green text-sm transition-colors">{t("nav.news")}</Link></li>
              <li><Link to="/careers" className="text-white/70 hover:text-brand-green text-sm transition-colors">{t("nav.careers")}</Link></li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-white font-semibold mb-4">{t("footer.contact")}</h3>
            <ul className="space-y-3">
              <li className="flex items-start space-x-2 text-white/70 text-sm">
                <MapPin className="w-4 h-4 mt-0.5 text-brand-green flex-shrink-0" />
                <span>Cairo, Egypt</span>
              </li>
              <li className="flex items-center space-x-2 text-white/70 text-sm">
                <Phone className="w-4 h-4 text-brand-green flex-shrink-0" />
                <span>01033110708</span>
              </li>
              <li className="flex items-center space-x-2 text-white/70 text-sm">
                <Phone className="w-4 h-4 text-brand-green flex-shrink-0" />
                <span>01030148413</span>
              </li>
              <li className="flex items-center space-x-2 text-white/70 text-sm">
                <Mail className="w-4 h-4 text-brand-green flex-shrink-0" />
                <span>https://khgroup.online</span>
              </li>
            </ul>
          </div>

          {/* Social Media */}
          <div>
            <h3 className="text-white font-semibold mb-4">{t("footer.follow")}</h3>
            <div className="flex space-x-3">
              <a href="https://www.facebook.com/profile.php?id=61578940479760" target="_blank" rel="noopener noreferrer" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-brand-green hover:text-white transition-all duration-300">
                <Facebook className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-brand-green hover:text-white transition-all duration-300">
                <Twitter className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-brand-green hover:text-white transition-all duration-300">
                <Instagram className="w-5 h-5" />
              </a>
              <a href="#" className="w-10 h-10 rounded-full bg-white/10 flex items-center justify-center text-white hover:bg-brand-green hover:text-white transition-all duration-300">
                <Linkedin className="w-5 h-5" />
              </a>
            </div>
          </div>
        </div>

        {/* Bottom Bar */}
        <div className="mt-12 pt-8 border-t border-white/10">
          <div className="flex flex-col md:flex-row justify-between items-center space-y-4 md:space-y-0">
            <p className="text-white/60 text-sm">
              © {currentYear} KH Group. {t("footer.rights")}
            </p>
            <div className="flex space-x-6">
              <Link to="#" className="text-white/60 hover:text-brand-green text-sm transition-colors">{t("footer.privacy")}</Link>
              <Link to="#" className="text-white/60 hover:text-brand-green text-sm transition-colors">{t("footer.terms")}</Link>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
