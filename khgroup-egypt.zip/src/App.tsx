import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { LanguageProvider } from "@/contexts/LanguageContext";
import { TrainingAuthProvider } from "@/contexts/TrainingAuthContext";
import Home from "./pages/Home";
import About from "./pages/About";
import Projects from "./pages/Projects";
import ProjectDetails from "./pages/ProjectDetails";
import News from "./pages/News";
import NewsDetail from "./pages/NewsDetail";
import Brochure from "./pages/Brochure";
import Careers from "./pages/Careers";
import Contact from "./pages/Contact";
import RealEstate from "./pages/RealEstate";
import Industrial from "./pages/Industrial";
import Agriculture from "./pages/Agriculture";
import Education from "./pages/Education";
import NotFound from "./pages/NotFound";
import Chatbot from "./components/Chatbot";
import TrainingLogin from "./pages/training/Login";
import TrainingLayout from "./components/training/TrainingLayout";
import TrainingDashboard from "./pages/training/Dashboard";
import TrainingDepartments from "./pages/training/Departments";
import TrainingRoadmap from "./pages/training/Roadmap";
import TrainingPlan from "./pages/training/Plan";
import TrainingAdmin from "./pages/training/Admin";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <TooltipProvider>
        <Toaster />
        <Sonner />
        <BrowserRouter>
          <Routes>
            {/* Public website */}
            <Route path="/" element={<Home />} />
            <Route path="/about" element={<About />} />
            <Route path="/projects" element={<Projects />} />
            <Route path="/projects/:id" element={<ProjectDetails />} />
            <Route path="/news" element={<News />} />
            <Route path="/news/:id" element={<NewsDetail />} />
            <Route path="/brochure" element={<Brochure />} />
            <Route path="/careers" element={<Careers />} />
            <Route path="/contact" element={<Contact />} />
            <Route path="/real-estate" element={<RealEstate />} />
            <Route path="/industrial" element={<Industrial />} />
            <Route path="/agriculture" element={<Agriculture />} />
            <Route path="/education" element={<Education />} />

            {/* Training Portal */}
            <Route
              path="/training/*"
              element={
                <TrainingAuthProvider>
                  <Routes>
                    <Route path="login" element={<TrainingLogin />} />
                    <Route element={<TrainingLayout />}>
                      <Route path="dashboard" element={<TrainingDashboard />} />
                      <Route path="departments" element={<TrainingDepartments />} />
                      <Route path="roadmap" element={<TrainingRoadmap />} />
                      <Route path="plan" element={<TrainingPlan />} />
                      <Route path="admin" element={<TrainingAdmin />} />
                    </Route>
                  </Routes>
                </TrainingAuthProvider>
              }
            />

            <Route path="*" element={<NotFound />} />
          </Routes>
        </BrowserRouter>
        <Chatbot />
      </TooltipProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
