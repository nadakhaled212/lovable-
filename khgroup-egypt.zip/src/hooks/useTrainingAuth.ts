import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { User } from "@supabase/supabase-js";

export type AppRole = "admin" | "manager" | "employee";

export interface EmployeeProfile {
  id: string;
  user_id: string;
  full_name: string;
  employee_id: string;
  department_id: string | null;
  job_role: string | null;
  job_role_ar: string | null;
  roadmap_level: string;
  manager_id: string | null;
  avatar_url: string | null;
}

export interface DepartmentInfo {
  id: string;
  name: string;
  name_ar: string | null;
  goals: string | null;
  goals_ar: string | null;
}

export function useTrainingAuth() {
  const [user, setUser] = useState<User | null>(null);
  const [profile, setProfile] = useState<EmployeeProfile | null>(null);
  const [department, setDepartment] = useState<DepartmentInfo | null>(null);
  const [roles, setRoles] = useState<AppRole[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        const currentUser = session?.user ?? null;
        setUser(currentUser);

        if (currentUser) {
          // Fetch profile
          const { data: emp } = await supabase
            .from("employees")
            .select("*")
            .eq("user_id", currentUser.id)
            .maybeSingle();
          
          setProfile(emp as EmployeeProfile | null);

          // Fetch department
          if (emp?.department_id) {
            const { data: dept } = await supabase
              .from("departments")
              .select("*")
              .eq("id", emp.department_id)
              .maybeSingle();
            setDepartment(dept as DepartmentInfo | null);
          }

          // Fetch roles
          const { data: userRoles } = await supabase
            .from("user_roles")
            .select("role")
            .eq("user_id", currentUser.id);
          
          setRoles((userRoles?.map((r: any) => r.role) as AppRole[]) ?? []);
        } else {
          setProfile(null);
          setDepartment(null);
          setRoles([]);
        }
        setLoading(false);
      }
    );

    supabase.auth.getSession();

    return () => subscription.unsubscribe();
  }, []);

  const signIn = async (email: string, password: string) => {
    const { error } = await supabase.auth.signInWithPassword({ email, password });
    return { error };
  };

  const signOut = async () => {
    await supabase.auth.signOut();
  };

  const hasRole = (role: AppRole) => roles.includes(role);
  const isAdmin = hasRole("admin");
  const isManager = hasRole("manager");

  return {
    user,
    profile,
    department,
    roles,
    loading,
    signIn,
    signOut,
    hasRole,
    isAdmin,
    isManager,
  };
}
