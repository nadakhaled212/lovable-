import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { Calendar, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { useNavigate } from "react-router-dom";

const News = () => {
  const { language, t } = useLanguage();
  const navigate = useNavigate();

  const newsArticles = [
    { id: 1, title: language === "ar" ? "مجموعة KH تطلق مشروع إسكان مستدام جديد" : "KH Group Launches New Sustainable Housing Project", date: "2024-01-15", category: language === "ar" ? "العقارات" : "Real Estate", excerpt: language === "ar" ? "تعلن مجموعة KH عن إطلاق أحدث مشروع إسكان مستدام في القاهرة الجديدة، يتميز بتصميم صديق للبيئة وتقنية المنزل الذكي." : "KH Group announces the launch of its latest sustainable housing development in New Cairo, featuring eco-friendly design and smart home technology.", image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800" },
    { id: 2, title: language === "ar" ? "المجمع الصناعي يحصل على جائزة الاستدامة الدولية" : "Industrial Complex Receives International Sustainability Award", date: "2024-01-10", category: language === "ar" ? "الصناعة" : "Industrial", excerpt: language === "ar" ? "تم تكريم مجمعنا الصناعي الذكي بجائزة التميز في الاستدامة العالمية لممارسات التصنيع الأخضر المبتكرة." : "Our Smart Industrial Park has been recognized with the Global Sustainability Excellence Award for innovative green manufacturing practices.", image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800" },
    { id: 3, title: language === "ar" ? "الإعلان عن شراكة مع وزارة الزراعة" : "Partnership with Ministry of Agriculture Announced", date: "2024-01-05", category: language === "ar" ? "الزراعة" : "Agriculture", excerpt: language === "ar" ? "تتعاون مجموعة KH مع وزارة الزراعة لتطوير مرافق زراعية متطورة تعزز الأمن الغذائي في مصر." : "KH Group partners with the Ministry of Agriculture to develop state-of-the-art agricultural facilities promoting food security in Egypt.", image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800" },
    { id: 4, title: language === "ar" ? "عام قياسي لمجموعة KH" : "Record-Breaking Year for KH Group", date: "2023-12-28", category: language === "ar" ? "أخبار الشركة" : "Company News", excerpt: language === "ar" ? "يمثل عام 2023 أنجح عام لنا حتى الآن، مع إتمام أكثر من 15 مشروعًا واستقرار 5000 عائلة جديدة في مجتمعاتنا." : "2023 marks our most successful year yet, with over 15 projects completed and 5,000 new families settling into our communities.", image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800" },
    { id: 5, title: language === "ar" ? "حفل وضع حجر الأساس لمشروع الساحل الشمالي" : "Groundbreaking Ceremony for North Coast Development", date: "2023-12-20", category: language === "ar" ? "العقارات" : "Real Estate", excerpt: language === "ar" ? "يجتمع المسؤولون وأصحاب المصلحة لحفل وضع حجر الأساس لمنتجعنا الفاخر على الساحل الشمالي، المصمم لإعادة تعريف الحياة الساحلية الفاخرة." : "Officials and stakeholders gather for the groundbreaking of our premium North Coast resort, set to redefine luxury coastal living.", image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=800" },
    { id: 6, title: language === "ar" ? "مجموعة KH تستثمر في البنية التحتية للطاقة المتجددة" : "KH Group Invests in Renewable Energy Infrastructure", date: "2023-12-15", category: language === "ar" ? "الصناعة" : "Industrial", excerpt: language === "ar" ? "تم تركيب مرافق جديدة للطاقة الشمسية عبر مجمعاتنا الصناعية، مما يقلل البصمة الكربونية بنسبة 40% ويدعم التحول الأخضر في مصر." : "New solar energy facilities installed across our industrial parks, reducing carbon footprint by 40% and supporting Egypt's green transition.", image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800" },
    { id: 7, title: language === "ar" ? "مجموعة KH تفتتح مركز الابتكار التقني الجديد" : "KH Group Opens New Tech Innovation Center", date: "2024-02-10", category: language === "ar" ? "أخبار الشركة" : "Company News", excerpt: language === "ar" ? "افتتحت مجموعة KH مركزًا جديدًا للابتكار التقني في القاهرة الجديدة لدعم التحول الرقمي وتطوير حلول المدن الذكية." : "KH Group inaugurates a new Tech Innovation Center in New Cairo to drive digital transformation and develop smart city solutions.", image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800" },
    { id: 8, title: language === "ar" ? "إطلاق برنامج التدريب بالذكاء الاصطناعي للموظفين" : "AI Training Program Launched for Employees", date: "2024-02-20", category: language === "ar" ? "أخبار الشركة" : "Company News", excerpt: language === "ar" ? "أطلقت مجموعة KH برنامج تدريب شامل بالذكاء الاصطناعي لجميع الموظفين لتعزيز الكفاءة والإنتاجية عبر جميع الأقسام." : "KH Group rolls out a comprehensive AI training program for all employees to boost efficiency and productivity across every department.", image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800" },
    { id: 9, title: language === "ar" ? "توسعة مشروع الصوب الزراعية الذكية" : "Smart Greenhouse Project Expansion Announced", date: "2024-03-05", category: language === "ar" ? "الزراعة" : "Agriculture", excerpt: language === "ar" ? "تعلن مجموعة KH عن توسعة مشروع الصوب الزراعية الذكية بمساحة 5000 فدان إضافية باستخدام تقنيات الزراعة الدقيقة والري بالتنقيط." : "KH Group announces a 5,000-acre expansion of its Smart Greenhouse project using precision farming and drip irrigation technologies.", image: "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800" },
    { id: 10, title: language === "ar" ? "مجموعة KH توقع اتفاقية تمويل أخضر بقيمة 500 مليون جنيه" : "KH Group Signs EGP 500M Green Financing Agreement", date: "2024-03-18", category: language === "ar" ? "الصناعة" : "Industrial", excerpt: language === "ar" ? "وقعت مجموعة KH اتفاقية تمويل أخضر مع بنك مصر لتمويل مشاريع الطاقة المتجددة والبنية التحتية المستدامة." : "KH Group secures a EGP 500 million green financing deal with Banque Misr to fund renewable energy and sustainable infrastructure projects.", image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800" },
    { id: 11, title: language === "ar" ? "تسليم المرحلة الأولى من مشروع بيت الوطن" : "Phase One Delivery of Beit Al Watan Project", date: "2024-04-01", category: language === "ar" ? "العقارات" : "Real Estate", excerpt: language === "ar" ? "أعلنت مجموعة KH عن تسليم المرحلة الأولى من مشروع بيت الوطن والذي يضم 800 وحدة سكنية بتشطيبات فاخرة." : "KH Group delivers Phase One of the Beit Al Watan project, comprising 800 fully finished luxury residential units.", image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800" },
  ];

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString(language === "ar" ? "ar-EG" : "en-US", { year: "numeric", month: "long", day: "numeric" });
  };

  return (
    <div className="min-h-screen">
      <SEO title="News & Updates | KH Group Egypt" description="Stay updated with the latest news, project milestones, and announcements from KH Group." path="/news" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">{t("news.title")}</h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">{t("news.subtitle")}</p>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <Card className="bg-card border-brand-green/30 overflow-hidden hover:shadow-brand transition-all duration-300">
            <div className="grid grid-cols-1 lg:grid-cols-2">
              <div className="relative h-96 lg:h-auto">
                <img src={newsArticles[0].image} alt={newsArticles[0].title} className="w-full h-full object-cover" />
                <div className="absolute top-4 left-4 bg-brand-green text-white px-4 py-2 rounded-full font-semibold">{t("news.featured")}</div>
              </div>
              <CardContent className="p-10 flex flex-col justify-center">
                <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-4">
                  <Calendar className="w-4 h-4 text-brand-green" />
                  <span>{formatDate(newsArticles[0].date)}</span>
                  <span className="text-brand-green">•</span>
                  <span>{newsArticles[0].category}</span>
                </div>
                <h2 className="text-3xl md:text-4xl font-serif font-bold mb-6">{newsArticles[0].title}</h2>
                <p className="text-lg text-muted-foreground leading-relaxed mb-8">{newsArticles[0].excerpt}</p>
                <Button onClick={() => navigate(`/news/${newsArticles[0].id}`)} className="bg-brand-green text-white hover:bg-brand-green-light w-fit">
                  {t("news.readfull")} <ArrowRight className="w-4 h-4 ml-2" />
                </Button>
              </CardContent>
            </div>
          </Card>
        </div>
      </section>

      <section className="py-24 bg-muted">
        <div className="container mx-auto px-4 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-12 text-center">{t("news.recentupdates")}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {newsArticles.slice(1).map((article, index) => (
              <Card key={article.id} className="bg-card border-border hover:border-brand-green transition-all duration-300 group overflow-hidden animate-scale-in" style={{ animationDelay: `${index * 100}ms` }}>
                <div className="relative overflow-hidden h-56">
                  <img src={article.image} alt={article.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                </div>
                <CardContent className="p-6">
                  <div className="flex items-center space-x-2 text-sm text-muted-foreground mb-3">
                    <Calendar className="w-4 h-4 text-brand-green" /><span>{formatDate(article.date)}</span>
                  </div>
                  <div className="text-xs text-brand-green font-semibold mb-2">{article.category}</div>
                  <h3 className="text-xl font-serif font-bold mb-3 group-hover:text-brand-green transition-colors line-clamp-2">{article.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed line-clamp-3">{article.excerpt}</p>
                  <Button variant="ghost" onClick={() => navigate(`/news/${article.id}`)} className="text-brand-green hover:text-brand-green-light hover:bg-brand-green/10 p-0 h-auto">
                    {t("news.readmore")} <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default News;
