import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { MapPin, Phone, Mail, Clock } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useLanguage } from "@/contexts/LanguageContext";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const contactSchema = z.object({
  name: z.string().trim().min(1, "Name is required").max(100),
  email: z.string().trim().email("Invalid email address").max(255),
  phone: z.string().trim().max(20).optional().or(z.literal("")),
  subject: z.string().trim().min(1, "Subject is required").max(200),
  message: z.string().trim().min(1, "Message is required").max(2000),
});

type ContactFormValues = z.infer<typeof contactSchema>;

const Contact = () => {
  const { toast } = useToast();
  const { language, t } = useLanguage();

  const form = useForm<ContactFormValues>({
    resolver: zodResolver(contactSchema),
    defaultValues: { name: "", email: "", phone: "", subject: "", message: "" },
  });

  const contactInfo = [
    { icon: MapPin, titleKey: "contact.info.office", details: language === "ar" ? ["مدينة العاشر من رمضان", "الشرقية، مصر"] : ["10th of Ramadan City", "Sharqia, Egypt"] },
    { icon: Phone, titleKey: "contact.info.phone", details: ["01033110708", "01030148413"] },
    { icon: Mail, titleKey: "contact.info.email", details: ["info@khgroup.com", "support@khgroup.com"] },
    { icon: Clock, titleKey: "contact.info.hours", details: [t("contact.info.hours.weekdays"), t("contact.info.hours.weekend")] },
  ];

  const onSubmit = (data: ContactFormValues) => {
    console.log("Form submitted:", data);
    toast({ title: t("contact.form.success.title"), description: t("contact.form.success.desc") });
    form.reset();
  };

  return (
    <div className="min-h-screen">
      <SEO title="Contact KH Group | 10th of Ramadan City, Egypt" description="Get in touch with KH Group. Our headquarters is in 10th of Ramadan City, Egypt. Reach out for partnerships, investments, or inquiries." path="/contact" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">{t("contact.title")}</h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">{t("contact.subtitle")}</p>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-16">
            {contactInfo.map((info, index) => (
              <Card key={index} className="bg-card border-border hover:border-brand-green transition-all duration-300 group">
                <CardContent className="p-6 text-center">
                  <div className="w-14 h-14 rounded-full bg-brand-green/10 flex items-center justify-center mx-auto mb-4 group-hover:bg-brand-green group-hover:scale-110 transition-all duration-300">
                    <info.icon className="w-7 h-7 text-brand-green group-hover:text-white" />
                  </div>
                  <h3 className="text-lg font-serif font-bold mb-3">{t(info.titleKey)}</h3>
                  {info.details.map((detail, idx) => (
                    <p key={idx} className="text-muted-foreground text-sm leading-relaxed">{detail}</p>
                  ))}
                </CardContent>
              </Card>
            ))}
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="bg-card border-brand-green/30">
              <CardContent className="p-8">
                <h2 className="text-3xl font-serif font-bold mb-6">{t("contact.form.title")}</h2>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <FormField control={form.control} name="name" render={({ field }) => (
                      <FormItem><FormLabel>{t("contact.form.name")} *</FormLabel><FormControl><Input {...field} maxLength={100} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField control={form.control} name="email" render={({ field }) => (
                        <FormItem><FormLabel>{t("contact.form.email")} *</FormLabel><FormControl><Input {...field} type="email" maxLength={255} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>
                      )} />
                      <FormField control={form.control} name="phone" render={({ field }) => (
                        <FormItem><FormLabel>{t("contact.form.phone")}</FormLabel><FormControl><Input {...field} type="tel" maxLength={20} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>
                      )} />
                    </div>
                    <FormField control={form.control} name="subject" render={({ field }) => (
                      <FormItem><FormLabel>{t("contact.form.subject")} *</FormLabel><FormControl><Input {...field} maxLength={200} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <FormField control={form.control} name="message" render={({ field }) => (
                      <FormItem><FormLabel>{t("contact.form.message")} *</FormLabel><FormControl><Textarea {...field} rows={6} maxLength={2000} className="bg-background border-border resize-none" /></FormControl><FormMessage /></FormItem>
                    )} />
                    <Button type="submit" className="w-full bg-brand-green text-white hover:bg-brand-green-light py-6">
                      {t("contact.form.send")}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>

            <Card className="bg-card border-brand-green/30 overflow-hidden">
              <div className="h-full min-h-[500px]">
                <iframe
                  src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d27356.14324912587!2d31.730678!3d30.280647!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x14f9c5d3b7c9f5c5%3A0x1f0d9e9e9e9e9e9e!2s10th%20of%20Ramadan%20City%2C%20Sharqia%20Governorate!5e0!3m2!1sen!2seg!4v1234567890123!5m2!1sen!2seg"
                  width="100%" height="100%" style={{ border: 0 }} allowFullScreen loading="lazy"
                  referrerPolicy="no-referrer-when-downgrade" title="KH Group Location"
                />
              </div>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Contact;
