import { useState } from "react";
import { useParams, useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Button } from "@/components/ui/button";
import { Building2, Factory, Sprout, MapPin, Maximize2, ArrowLeft, Calendar, X } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

import project6aStreet from "@/assets/project6a-street.jpg";
import project6aVillas from "@/assets/project6a-villas.jpg";
import project6aNight from "@/assets/project6a-night.jpg";
import project6aCommunity from "@/assets/project6a-community.jpg";
import project6aAerialDay from "@/assets/project6a-aerial-day.jpg";
import project6aAerialTop from "@/assets/project6a-aerial-top.jpg";
import project6aAerialSunset from "@/assets/project6a-aerial-sunset.jpg";
import villa26Img from "@/assets/villa26.jpg";
import cyprusCompoundImg from "@/assets/cyprus-compound.jpg";
import cyprusBuilding from "@/assets/cyprus-building.png";
import cyprusPoolSea from "@/assets/cyprus-pool-sea.png";
import cyprusPool from "@/assets/cyprus-pool.png";
import cyprusPanorama from "@/assets/cyprus-panorama.jpg";

type Bilingual = { en: string; ar: string };

interface GalleryImage {
  src: string;
  caption: Bilingual;
}

const ProjectDetails = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { t, language } = useLanguage();
  const [lightboxImage, setLightboxImage] = useState<string | null>(null);

  const projects = [
    {
      id: 1,
      title: { en: "Project 6A", ar: "مشروع 6ع" },
      category: "Real Estate",
      location: { en: "10th of Ramadan City, Egypt", ar: "العاشر من رمضان، مصر" },
      area: { en: "352 Villas", ar: "352 فيلا" },
      status: { en: "Under Construction", ar: "تحت الإنشاء" },
      image: project6aAerialDay,
      coordinates: { lat: 30.2619573, lng: 31.7176527 },
      address: {
        en: "10th of Ramadan City, Sharqia Governorate, Egypt",
        ar: "مدينة العاشر من رمضان، محافظة الشرقية، مصر",
      },
      locationNote: {
        en: "Located in 10th of Ramadan City with direct access to Belbeis Road and key surrounding areas.",
        ar: "يقع في مدينة العاشر من رمضان مع وصول مباشر لطريق بلبيس والمناطق المحيطة الرئيسية.",
      },
      description: {
        en: "Located in 10th of Ramadan City on the Belbeis – 10th of Ramadan Road, the project offers a modern residential community that combines comfort, sustainability, and integrated services. The design embraces smart living with natural ventilation, optimized daylighting, clean energy solutions, and greywater recycling for landscape irrigation.",
        ar: "يقع المشروع في مدينة العاشر من رمضان على طريق بلبيس – العاشر من رمضان، ويقدم مجتمعًا سكنيًا عصريًا يجمع بين الراحة والاستدامة والخدمات المتكاملة. يتبنى التصميم مفهوم الحياة الذكية مع التهوية الطبيعية والإضاءة الطبيعية المُحسّنة وحلول الطاقة النظيفة وإعادة تدوير المياه الرمادية لري المساحات الخضراء."
      },
      fullDescription: {
        en: "The development provides a complete lifestyle with a community club, modern hospital, higher education institute, and contemporary shopping mall, along with extensive green spaces and water features that enhance the environment. Pedestrian-friendly pathways and smart infrastructure ensure a safe, comfortable, and high-quality living experience for all residents.",
        ar: "يوفر المشروع أسلوب حياة متكامل مع نادٍ اجتماعي ومستشفى حديث ومعهد للتعليم العالي ومركز تسوق عصري، إلى جانب مساحات خضراء واسعة ومعالم مائية تعزز البيئة المحيطة. كما تضمن الممرات الصديقة للمشاة والبنية التحتية الذكية تجربة معيشية آمنة ومريحة وعالية الجودة لجميع السكان."
      },
      features: [
        { title: { en: "Prime Strategic Location", ar: "موقع استراتيجي متميز" }, desc: { en: "Easy access to major roads and services.", ar: "سهولة الوصول للطرق الرئيسية والخدمات." } },
        { title: { en: "Smart & Sustainable Living", ar: "حياة ذكية ومستدامة" }, desc: { en: "Natural ventilation, daylighting & efficient planning.", ar: "تهوية طبيعية وإضاءة وتخطيط موفر للطاقة." } },
        { title: { en: "Clean Energy & Water", ar: "طاقة نظيفة وإدارة مياه" }, desc: { en: "Renewable energy & greywater recycling systems.", ar: "طاقة متجددة وأنظمة إعادة تدوير المياه." } },
        { title: { en: "Integrated Services", ar: "خدمات متكاملة" }, desc: { en: "Hospital, education institute & shopping mall.", ar: "مستشفى ومعهد تعليمي ومركز تسوق." } },
        { title: { en: "Community Club", ar: "نادٍ اجتماعي" }, desc: { en: "Recreation, sports & social activities.", ar: "أنشطة ترفيهية ورياضية واجتماعية." } },
        { title: { en: "Green Landscapes", ar: "مساحات خضراء" }, desc: { en: "Extensive gardens & relaxing outdoor spaces.", ar: "حدائق واسعة ومساحات خارجية مريحة." } },
        { title: { en: "Water Features", ar: "معالم مائية" }, desc: { en: "Visual water elements improving the microclimate.", ar: "عناصر مائية تحسن المناخ المحلي." } },
        { title: { en: "Pedestrian-Friendly", ar: "صديق للمشاة" }, desc: { en: "Safe pathways for all ages & abilities.", ar: "ممرات آمنة لجميع الأعمار والقدرات." } },
        { title: { en: "Privacy-Oriented", ar: "خصوصية مراعاة" }, desc: { en: "Private clusters with green space views.", ar: "تجمعات خاصة بإطلالات خضراء." } },
        { title: { en: "Modern Architecture", ar: "عمارة معاصرة" }, desc: { en: "Distinctive & elegant residential identity.", ar: "هوية سكنية مميزة وأنيقة." } },
        { title: { en: "Smart Infrastructure", ar: "بنية تحتية ذكية" }, desc: { en: "Efficient lighting, security & utility systems.", ar: "إضاءة وأمن وإدارة مرافق ذكية." } },
      ],
      gallery: [
        { src: project6aStreet, caption: { en: "Landscape Design", ar: "تصميم المناظر الطبيعية" } },
        { src: project6aVillas, caption: { en: "Residential Buildings", ar: "المباني السكنية" } },
        { src: project6aNight, caption: { en: "Night View", ar: "منظر ليلي" } },
        { src: project6aCommunity, caption: { en: "Community Area", ar: "منطقة المجتمع" } },
        { src: project6aAerialDay, caption: { en: "Aerial View", ar: "منظر جوي" } },
        { src: project6aAerialTop, caption: { en: "Block 1", ar: "بلوك 1" } },
        { src: project6aAerialSunset, caption: { en: "Daytime View", ar: "منظر نهاري" } },
      ] as GalleryImage[],
    },
    {
      id: 8,
      title: { en: "Villa 26", ar: "فيلا 26" },
      category: "Real Estate",
      location: { en: "10th of Ramadan City, Neighborhood 26", ar: "العاشر من رمضان، مجاورة 26" },
      area: { en: "Residential Building", ar: "مبنى سكني" },
      status: { en: "Completed", ar: "مكتمل" },
      image: villa26Img,
      description: { en: "A premium residential building in Neighborhood 26, 10th of Ramadan City, featuring elegant architectural design with modern finishes and spacious units.", ar: "مبنى سكني فاخر في مجاورة 26 بمدينة العاشر من رمضان، بتصميم معماري أنيق وتشطيبات حديثة ووحدات واسعة." },
      fullDescription: { en: "Villa 26 is a distinguished residential building located in Neighborhood 26, 10th of Ramadan City. The project features a classic yet modern architectural style with premium finishes, balconies with green elements, and a welcoming entrance. It offers comfortable living spaces designed for families seeking quality and elegance.", ar: "فيلا 26 هو مبنى سكني متميز يقع في مجاورة 26 بمدينة العاشر من رمضان. يتميز المشروع بطراز معماري كلاسيكي عصري مع تشطيبات فاخرة وشرفات بعناصر خضراء ومدخل ترحيبي. يوفر مساحات معيشية مريحة مصممة للعائلات الباحثة عن الجودة والأناقة." },
      features: [
        { title: { en: "Elegant Architecture", ar: "عمارة أنيقة" }, desc: { en: "Classic modern design with premium facade.", ar: "تصميم كلاسيكي عصري بواجهة فاخرة." } },
        { title: { en: "Premium Finishes", ar: "تشطيبات فاخرة" }, desc: { en: "High-quality interior and exterior finishes.", ar: "تشطيبات داخلية وخارجية عالية الجودة." } },
        { title: { en: "Green Balconies", ar: "شرفات خضراء" }, desc: { en: "Balconies adorned with plants and greenery.", ar: "شرفات مزينة بالنباتات والخضرة." } },
        { title: { en: "Spacious Units", ar: "وحدات واسعة" }, desc: { en: "Comfortable living spaces for families.", ar: "مساحات معيشية مريحة للعائلات." } },
        { title: { en: "Prime Location", ar: "موقع متميز" }, desc: { en: "Central location in Neighborhood 26.", ar: "موقع مركزي في مجاورة 26." } },
        { title: { en: "Completed Project", ar: "مشروع مكتمل" }, desc: { en: "Ready for immediate occupancy.", ar: "جاهز للسكن الفوري." } },
      ],
      gallery: [
        { src: villa26Img, caption: { en: "Building Facade", ar: "واجهة المبنى" } },
      ] as GalleryImage[],
    },
    {
      id: 9,
      title: { en: "Cyprus Residential Compound", ar: "مجمع قبرص السكني" },
      category: "Real Estate",
      location: { en: "North Cyprus", ar: "شمال قبرص" },
      area: { en: "3 Donums · 5 Buildings", ar: "3 دونمات · 5 مباني" },
      status: { en: "Completed", ar: "مكتمل" },
      image: cyprusCompoundImg,
      description: { en: "A modern residential compound in North Cyprus with panoramic sea views for all units, featuring a unique architectural concept across 5 buildings.", ar: "مجمع سكني عصري في شمال قبرص بإطلالات بانورامية على البحر لجميع الوحدات، بتصميم معماري فريد عبر 5 مباني." },
      fullDescription: { en: "Located in the northern part of Cyprus, this premium residential compound spans 3 donums and consists of 5 carefully designed buildings. The project features a unique architectural concept that ensures every unit enjoys panoramic sea views. With a well-planned layout, modern amenities, and a focus on quality living, this development represents an exceptional international investment opportunity.", ar: "يقع هذا المجمع السكني الفاخر في الجزء الشمالي من قبرص على مساحة 3 دونمات ويتكون من 5 مبانٍ مصممة بعناية. يتميز المشروع بمفهوم معماري فريد يضمن لكل وحدة إطلالات بانورامية على البحر. بتخطيط محكم ومرافق عصرية وتركيز على جودة الحياة، يمثل هذا المشروع فرصة استثمارية دولية استثنائية." },
      features: [
        { title: { en: "Panoramic Sea Views", ar: "إطلالات بانورامية على البحر" }, desc: { en: "All units designed with unobstructed sea views.", ar: "جميع الوحدات مصممة بإطلالات مفتوحة على البحر." } },
        { title: { en: "Unique Design Concept", ar: "مفهوم تصميم فريد" }, desc: { en: "Innovative layout ensuring views for every unit.", ar: "تخطيط مبتكر يضمن إطلالات لكل وحدة." } },
        { title: { en: "Modern Buildings", ar: "مبانٍ عصرية" }, desc: { en: "Contemporary architecture across 5 buildings.", ar: "عمارة معاصرة عبر 5 مبانٍ." } },
        { title: { en: "Prime Location", ar: "موقع متميز" }, desc: { en: "Strategic location in North Cyprus.", ar: "موقع استراتيجي في شمال قبرص." } },
        { title: { en: "Premium Finishes", ar: "تشطيبات فاخرة" }, desc: { en: "High-end materials and finishes throughout.", ar: "مواد وتشطيبات عالية الجودة." } },
        { title: { en: "International Investment", ar: "استثمار دولي" }, desc: { en: "A valuable opportunity in Mediterranean real estate.", ar: "فرصة قيّمة في العقارات المتوسطية." } },
      ],
      gallery: [
        { src: cyprusCompoundImg, caption: { en: "Compound Overview", ar: "نظرة عامة على المجمع" } },
        { src: cyprusPanorama, caption: { en: "Panoramic View", ar: "منظر بانورامي" } },
        { src: cyprusBuilding, caption: { en: "Building Facade", ar: "واجهة المبنى" } },
        { src: cyprusPoolSea, caption: { en: "Pool & Sea View", ar: "المسبح وإطلالة البحر" } },
        { src: cyprusPool, caption: { en: "Swimming Pool", ar: "حمام السباحة" } },
      ] as GalleryImage[],
    },
    {
      id: 2,
      title: { en: "Ebdaa 1 Industrial Complex", ar: "مجمع ابداع 1 الصناعي" },
      category: "Industrial",
      location: { en: "10th of Ramadan City", ar: "مدينة العاشر من رمضان" },
      area: { en: "120 Hectares", ar: "120 هكتار" },
      status: { en: "Completed", ar: "مكتمل" },
      image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800",
      description: { en: "Integrated industrial complex completed with the latest specifications", ar: "مجمع صناعي متكامل تم الانتهاء من تنفيذه بأحدث المواصفات" },
      fullDescription: { en: "Ebdaa 1 is the first industrial complex built in 10th of Ramadan City, featuring advanced infrastructure and comprehensive services that meet the needs of factories and investors.", ar: "مجمع ابداع 1 هو أول المجمعات الصناعية التي تم تنفيذها في مدينة العاشر من رمضان، ويتميز بالبنية التحتية المتطورة والخدمات المتكاملة التي تلبي احتياجات المصانع والمستثمرين." },
      features: [
        { title: { en: "Ready-to-Operate Units", ar: "وحدات جاهزة للتشغيل" }, desc: { en: "Fully equipped industrial spaces.", ar: "مساحات صناعية مجهزة بالكامل." } },
        { title: { en: "Integrated Infrastructure", ar: "بنية تحتية متكاملة" }, desc: { en: "Complete utilities and road networks.", ar: "مرافق وشبكات طرق متكاملة." } },
        { title: { en: "High-Capacity Power", ar: "طاقة عالية القدرة" }, desc: { en: "Reliable high-voltage electricity grid.", ar: "شبكة كهرباء عالية الجهد موثوقة." } },
        { title: { en: "Water Treatment", ar: "معالجة المياه" }, desc: { en: "On-site water treatment plant.", ar: "محطة معالجة مياه داخلية." } },
        { title: { en: "24/7 Security", ar: "أمن على مدار الساعة" }, desc: { en: "Round-the-clock surveillance systems.", ar: "أنظمة مراقبة على مدار الساعة." } },
        { title: { en: "Strategic Access", ar: "وصول استراتيجي" }, desc: { en: "Close to main roads and highways.", ar: "قرب من الطرق الرئيسية والسريعة." } },
      ],
      gallery: [
        { src: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800", caption: { en: "Main Entrance", ar: "المدخل الرئيسي" } },
        { src: "https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=800", caption: { en: "Industrial Units", ar: "الوحدات الصناعية" } },
        { src: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800", caption: { en: "Aerial View", ar: "منظر جوي" } },
      ] as GalleryImage[],
    },
    {
      id: 3,
      title: { en: "Egyptian Countryside - HQI", ar: "الريف المصري - HQI" },
      category: "Agricultural",
      location: { en: "Egypt", ar: "مصر" },
      area: { en: "200 Hectares", ar: "200 هكتار" },
      status: { en: "Ongoing", ar: "جاري التنفيذ" },
      image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800",
      description: { en: "Integrated agricultural project by HQI aimed at developing the Egyptian countryside with the latest agricultural technologies", ar: "مشروع زراعي متكامل من شركة HQI يهدف إلى تطوير الريف المصري بأحدث التقنيات الزراعية" },
      fullDescription: { en: "The Egyptian Countryside project by HQI is an ambitious agricultural initiative aimed at modernizing and developing the agricultural sector in Egypt using the latest technologies and sustainable farming practices, focusing on improving productivity and crop quality.", ar: "مشروع الريف المصري من شركة HQI هو مبادرة زراعية طموحة تهدف إلى تحديث وتطوير القطاع الزراعي في مصر باستخدام أحدث التقنيات والممارسات الزراعية المستدامة، مع التركيز على تحسين الإنتاجية وجودة المحاصيل." },
      features: [
        { title: { en: "Advanced Agri-Tech", ar: "تقنيات زراعية متطورة" }, desc: { en: "Modern farming technologies.", ar: "تقنيات زراعة حديثة." } },
        { title: { en: "Smart Irrigation", ar: "ري ذكي" }, desc: { en: "Water-saving irrigation systems.", ar: "أنظمة ري موفرة للمياه." } },
        { title: { en: "Organic Farming", ar: "زراعة عضوية" }, desc: { en: "Sustainable organic practices.", ar: "ممارسات عضوية مستدامة." } },
        { title: { en: "Storage & Packaging", ar: "تخزين وتعبئة" }, desc: { en: "Modern post-harvest facilities.", ar: "مرافق ما بعد الحصاد حديثة." } },
        { title: { en: "Farmer Training", ar: "تدريب المزارعين" }, desc: { en: "Educational development programs.", ar: "برامج تطوير تعليمية." } },
        { title: { en: "Market Access", ar: "وصول للأسواق" }, desc: { en: "Local & international distribution.", ar: "توزيع محلي ودولي." } },
      ],
      gallery: [
        { src: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800", caption: { en: "Farm Overview", ar: "نظرة عامة" } },
        { src: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800", caption: { en: "Green Fields", ar: "حقول خضراء" } },
        { src: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=800", caption: { en: "Harvest Season", ar: "موسم الحصاد" } },
      ] as GalleryImage[],
    },
    {
      id: 5,
      title: { en: "Ebdaa 2 Industrial Complex", ar: "مجمع ابداع 2 الصناعي" },
      category: "Industrial",
      location: { en: "10th of Ramadan City", ar: "مدينة العاشر من رمضان" },
      area: { en: "150 Hectares", ar: "150 هكتار" },
      status: { en: "Under Construction", ar: "تحت الإنشاء" },
      image: "https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=800",
      description: { en: "Modern industrial complex under construction with international specifications", ar: "مجمع صناعي حديث تحت التنفيذ بمواصفات عالمية" },
      fullDescription: { en: "Ebdaa 2 Industrial Complex represents the second phase of industrial development, currently under construction with the latest technologies and international specifications to serve local and international investors.", ar: "مجمع ابداع 2 الصناعي يمثل المرحلة الثانية من التطوير الصناعي، وهو حالياً تحت التنفيذ بأحدث التقنيات والمواصفات العالمية لخدمة المستثمرين المحليين والدوليين." },
      features: [
        { title: { en: "Modern Units", ar: "وحدات حديثة" }, desc: { en: "State-of-the-art industrial spaces.", ar: "مساحات صناعية بأحدث المواصفات." } },
        { title: { en: "Sustainable Energy", ar: "طاقة مستدامة" }, desc: { en: "Green energy solutions.", ar: "حلول طاقة خضراء." } },
        { title: { en: "Advanced Logistics", ar: "لوجستيات متقدمة" }, desc: { en: "Efficient supply chain facilities.", ar: "مرافق سلسلة إمداد فعالة." } },
        { title: { en: "24/7 Security", ar: "أمن على مدار الساعة" }, desc: { en: "Comprehensive monitoring systems.", ar: "أنظمة مراقبة شاملة." } },
        { title: { en: "Strategic Location", ar: "موقع استراتيجي" }, desc: { en: "Near major highways.", ar: "بالقرب من الطرق السريعة." } },
        { title: { en: "Ready Services", ar: "خدمات جاهزة" }, desc: { en: "Complete utilities on-site.", ar: "مرافق متكاملة في الموقع." } },
      ],
      gallery: [
        { src: "https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=800", caption: { en: "Construction Site", ar: "موقع البناء" } },
        { src: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800", caption: { en: "Industrial Zone", ar: "المنطقة الصناعية" } },
        { src: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800", caption: { en: "Aerial View", ar: "منظر جوي" } },
      ] as GalleryImage[],
    },
    {
      id: 7,
      title: { en: "Ebdaa 3 Industrial Complex", ar: "مجمع ابداع 3 الصناعي" },
      category: "Industrial",
      location: { en: "10th of Ramadan City", ar: "مدينة العاشر من رمضان" },
      area: { en: "180 Hectares", ar: "180 هكتار" },
      status: { en: "Planning", ar: "قيد التخطيط" },
      image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800",
      description: { en: "Industrial complex in planning phase to be the largest in the region", ar: "مجمع صناعي قيد التخطيط ليكون أكبر المجمعات في المنطقة" },
      fullDescription: { en: "Ebdaa 3 Industrial Complex is the largest and most ambitious project, being planned to be the largest integrated industrial complex in the region with the highest quality and sustainability standards.", ar: "مجمع ابداع 3 الصناعي هو المشروع الأكبر والأكثر طموحاً، حيث يتم التخطيط له ليكون أكبر مجمع صناعي متكامل في المنطقة مع مراعاة أعلى معايير الجودة والاستدامة." },
      features: [
        { title: { en: "Largest in Region", ar: "الأكبر في المنطقة" }, desc: { en: "Unmatched industrial scale.", ar: "نطاق صناعي لا مثيل له." } },
        { title: { en: "Modern Planning", ar: "تخطيط عصري" }, desc: { en: "Advanced urban design.", ar: "تصميم حضري متطور." } },
        { title: { en: "Specialized Zones", ar: "مناطق متخصصة" }, desc: { en: "Dedicated industrial sectors.", ar: "قطاعات صناعية مخصصة." } },
        { title: { en: "Smart Infrastructure", ar: "بنية تحتية ذكية" }, desc: { en: "IoT-enabled systems.", ar: "أنظمة مدعومة بإنترنت الأشياء." } },
        { title: { en: "Full Services", ar: "خدمات شاملة" }, desc: { en: "Complete support facilities.", ar: "مرافق دعم متكاملة." } },
        { title: { en: "Green Spaces", ar: "مساحات خضراء" }, desc: { en: "Parks & recreation areas.", ar: "حدائق ومناطق ترفيهية." } },
      ],
      gallery: [
        { src: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800", caption: { en: "Overview", ar: "نظرة عامة" } },
        { src: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800", caption: { en: "Industrial Area", ar: "المنطقة الصناعية" } },
        { src: "https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=800", caption: { en: "Site Overview", ar: "نظرة عامة" } },
      ] as GalleryImage[],
    },
    {
      id: 6,
      title: { en: "Organic Farming Initiative", ar: "مبادرة الزراعة العضوية" },
      category: "Agricultural",
      location: { en: "Upper Egypt", ar: "صعيد مصر" },
      area: { en: "300 Hectares", ar: "300 هكتار" },
      status: { en: "Under Construction", ar: "تحت الإنشاء" },
      image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800",
      description: { en: "Sustainable organic farming with focus on food security", ar: "زراعة عضوية مستدامة مع التركيز على الأمن الغذائي" },
      fullDescription: { en: "A pioneering organic agriculture project promoting sustainable farming practices and contributing to Egypt's food security goals.", ar: "مشروع زراعي عضوي رائد يعزز ممارسات الزراعة المستدامة ويساهم في تحقيق أهداف الأمن الغذائي في مصر." },
      features: [
        { title: { en: "100% Organic", ar: "عضوي 100%" }, desc: { en: "Certified organic produce.", ar: "منتجات عضوية معتمدة." } },
        { title: { en: "Renewable Energy", ar: "طاقة متجددة" }, desc: { en: "Solar-powered operations.", ar: "عمليات بالطاقة الشمسية." } },
        { title: { en: "Water Conservation", ar: "حفظ المياه" }, desc: { en: "Efficient water management.", ar: "إدارة مياه فعالة." } },
        { title: { en: "Composting", ar: "تسميد عضوي" }, desc: { en: "On-site organic composting.", ar: "تسميد عضوي في الموقع." } },
        { title: { en: "Farm Tours", ar: "جولات المزرعة" }, desc: { en: "Educational visitor experiences.", ar: "تجارب تعليمية للزوار." } },
        { title: { en: "Direct Market", ar: "سوق مباشر" }, desc: { en: "Farm-to-table distribution.", ar: "توزيع من المزرعة للمائدة." } },
      ],
      gallery: [
        { src: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800", caption: { en: "Organic Fields", ar: "حقول عضوية" } },
        { src: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800", caption: { en: "Green Landscape", ar: "مناظر خضراء" } },
        { src: "https://images.unsplash.com/photo-1560493676-04071c5f467b?w=800", caption: { en: "Harvest Season", ar: "موسم الحصاد" } },
      ] as GalleryImage[],
    },
  ];

  const categoryLabels: Record<string, Bilingual> = {
    "Real Estate": { en: "Real Estate", ar: "العقارات" },
    "Industrial": { en: "Industrial", ar: "الصناعة" },
    "Agricultural": { en: "Agricultural", ar: "الزراعة" },
  };

  const l = (val: Bilingual) => val[language];

  const project = projects.find((p) => p.id === parseInt(id || "0"));

  if (!project) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="container mx-auto px-4 py-32 text-center">
          <h1 className="text-4xl font-serif font-bold text-foreground mb-4">
            {language === "ar" ? "المشروع غير موجود" : "Project Not Found"}
          </h1>
          <Button onClick={() => navigate("/projects")} className="bg-brand-green text-white hover:bg-brand-green-light">
            <ArrowLeft className="mr-2 h-4 w-4" />
            {language === "ar" ? "العودة للمشاريع" : "Back to Projects"}
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Real Estate": return Building2;
      case "Industrial": return Factory;
      case "Agricultural": return Sprout;
      default: return Building2;
    }
  };

  const Icon = getCategoryIcon(project.category);
  const featureIcons = ["📍", "🏡", "⚡", "🏥", "🎾", "🌿", "💧", "🚶", "🔒", "🏛️", "🔧"];

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero Section */}
      <section className="pt-32 pb-12 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <Button
            onClick={() => navigate("/projects")}
            variant="outline"
            className="mb-8 border-brand-green text-brand-green hover:bg-brand-green hover:text-white"
          >
            <ArrowLeft className={`h-4 w-4 ${language === "ar" ? "ml-2 rotate-180" : "mr-2"}`} />
            {language === "ar" ? "العودة للمشاريع" : "Back to Projects"}
          </Button>

          <div className="flex items-center space-x-3 mb-6">
            <Icon className="w-8 h-8 text-brand-green" />
            <span className="text-lg text-muted-foreground">{categoryLabels[project.category]?.[language]}</span>
          </div>

          <h1 className="text-5xl md:text-6xl font-serif font-bold text-foreground mb-6">
            {l(project.title)}
          </h1>

          <div className="flex flex-wrap gap-4 mb-8">
            <div className="flex items-center space-x-2 text-muted-foreground">
              <MapPin className="w-5 h-5 text-brand-green" />
              <span>{l(project.location)}</span>
            </div>
            <div className="flex items-center space-x-2 text-muted-foreground">
              <Maximize2 className="w-5 h-5 text-brand-green" />
              <span>{l(project.area)}</span>
            </div>
            <div className="flex items-center space-x-2">
              <Calendar className="w-5 h-5 text-brand-green" />
              <span className="bg-brand-green text-white px-3 py-1 rounded-full text-sm font-semibold">
                {l(project.status)}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* Main Image */}
      <section className="py-12 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="rounded-xl overflow-hidden shadow-elegant mb-16">
            <img
              src={project.image}
              alt={l(project.title)}
              className="w-full h-[500px] object-cover"
            />
          </div>

          {/* Description */}
          <div className="max-w-4xl mx-auto mb-20">
            <h2 className="text-3xl font-serif font-bold text-foreground mb-6">
              {language === "ar" ? "نظرة عامة" : "Overview"}
            </h2>
            <p className="text-xl text-muted-foreground leading-relaxed mb-4">
              {l(project.description)}
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              {l(project.fullDescription)}
            </p>
          </div>

          {/* Key Features - Elegant List with Separators */}
          <div className="max-w-5xl mx-auto mb-20">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-serif font-bold text-foreground mb-3">
                {language === "ar" ? "المميزات الرئيسية" : "Key Features"}
              </h2>
              <div className="w-16 h-0.5 bg-brand-green mx-auto" />
            </div>

            <div className="space-y-0">
              {project.features.map((feature, index) => (
                <div
                  key={index}
                  className="group flex items-start gap-5 py-6 border-b border-border/50 last:border-b-0 hover:bg-card/30 transition-colors duration-300 px-4 rounded-lg"
                >
                  <span className="text-2xl flex-shrink-0 mt-0.5 opacity-80 group-hover:opacity-100 transition-opacity">
                    {featureIcons[index] || "✦"}
                  </span>
                  <div className="flex-1 min-w-0">
                    <h3 className="text-lg font-semibold text-foreground mb-1 group-hover:text-brand-green transition-colors duration-300">
                      {l(feature.title)}
                    </h3>
                    <p className="text-muted-foreground text-sm leading-relaxed">
                      {l(feature.desc)}
                    </p>
                  </div>
                  <span className="text-brand-green/30 text-sm font-mono flex-shrink-0 mt-1">
                    {String(index + 1).padStart(2, "0")}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Gallery */}
          <div className="max-w-6xl mx-auto mb-16">
            <div className="text-center mb-12">
              <h2 className="text-3xl font-serif font-bold text-foreground mb-3">
                {language === "ar" ? "معرض الصور" : "Project Gallery"}
              </h2>
              <div className="w-16 h-0.5 bg-brand-green mx-auto" />
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-5">
              {(project.gallery as GalleryImage[]).map((item, index) => (
                <div
                  key={index}
                  className="group cursor-pointer"
                  onClick={() => setLightboxImage(item.src)}
                >
                  <div className="relative overflow-hidden rounded-xl shadow-lg">
                    <img
                      src={item.src}
                      alt={l(item.caption)}
                      className="w-full h-64 object-cover group-hover:scale-105 transition-transform duration-500 ease-out"
                    />
                    <div className="absolute inset-0 bg-black/0 group-hover:bg-black/20 transition-colors duration-300" />
                  </div>
                  <p className="mt-3 text-center text-sm text-muted-foreground font-light tracking-wide">
                    {l(item.caption)}
                  </p>
                </div>
              ))}
            </div>
          </div>

          {/* Project Location */}
          {project.coordinates && (() => {
            const { lat, lng } = project.coordinates;
            const toDMS = (val: number, pos: string, neg: string) => {
              const abs = Math.abs(val);
              const d = Math.floor(abs);
              const mFloat = (abs - d) * 60;
              const m = Math.floor(mFloat);
              const s = ((mFloat - m) * 60).toFixed(1);
              return `${d}°${String(m).padStart(2, "0")}′${s}″${val >= 0 ? pos : neg}`;
            };
            const dms = `${toDMS(lat, "N", "S")} ${toDMS(lng, "E", "W")}`;
            const embedUrl = `https://www.google.com/maps?q=${lat},${lng}&z=17&output=embed`;
            const placeUrl = `https://www.google.com/maps/place/${lat},${lng}/@${lat},${lng},17z`;
            return (
            <div className="max-w-6xl mx-auto mb-20 animate-fade-in">
              <div className="text-center mb-12">
                <div className="flex items-center justify-center gap-2 mb-3">
                  <MapPin className="w-6 h-6 text-brand-green" />
                  <h2 className="text-3xl font-serif font-bold text-foreground">
                    {language === "ar" ? "موقع المشروع" : "Project Location"}
                  </h2>
                </div>
                <div className="w-16 h-0.5 bg-brand-green mx-auto" />
              </div>

              <div className="grid grid-cols-1 lg:grid-cols-5 gap-6 items-stretch">
                <div className="lg:col-span-3 rounded-2xl overflow-hidden shadow-elegant border border-border/30 min-h-[420px]">
                  <iframe
                    src={embedUrl}
                    width="100%"
                    height="100%"
                    style={{ border: 0, minHeight: 420 }}
                    allowFullScreen
                    loading="lazy"
                    referrerPolicy="no-referrer-when-downgrade"
                    title="Project Location"
                    className="w-full h-full"
                  />
                </div>

                <div className="lg:col-span-2 bg-secondary/40 border border-border/30 rounded-2xl p-6 flex flex-col justify-between">
                  <div className="space-y-5">
                    <div>
                      <h3 className="text-xl font-serif font-bold text-foreground mb-2">
                        {l(project.title)}
                      </h3>
                      {project.locationNote && (
                        <p className="text-muted-foreground leading-relaxed">
                          {l(project.locationNote)}
                        </p>
                      )}
                    </div>

                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-brand-green mt-0.5 shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-foreground mb-1">
                          {language === "ar" ? "العنوان" : "Address"}
                        </p>
                        <p className="text-sm text-muted-foreground">
                          {l(project.address ?? project.location)}
                        </p>
                      </div>
                    </div>

                    <div className="flex items-start gap-3">
                      <MapPin className="w-5 h-5 text-brand-green mt-0.5 shrink-0" />
                      <div>
                        <p className="text-sm font-semibold text-foreground mb-1">
                          {language === "ar" ? "الإحداثيات" : "Coordinates"}
                        </p>
                        <p className="text-sm text-muted-foreground font-mono" dir="ltr">
                          {dms}
                        </p>
                        <p className="text-xs text-muted-foreground/80 font-mono mt-0.5" dir="ltr">
                          {lat}, {lng}
                        </p>
                      </div>
                    </div>
                  </div>

                  <a
                    href={placeUrl}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="mt-6"
                  >
                    <Button className="w-full bg-brand-green text-white hover:bg-brand-green-light gap-2">
                      <MapPin className="w-4 h-4" />
                      {language === "ar" ? "عرض على خرائط جوجل" : "View on Google Maps"}
                    </Button>
                  </a>
                </div>
              </div>
            </div>
            );
          })()}
        </div>
      </section>

      {/* Lightbox */}
      {lightboxImage && (
        <div
          className="fixed inset-0 z-50 bg-black/90 flex items-center justify-center p-4 animate-fade-in"
          onClick={() => setLightboxImage(null)}
        >
          <button
            className="absolute top-6 right-6 text-white/80 hover:text-white transition-colors"
            onClick={() => setLightboxImage(null)}
          >
            <X className="w-8 h-8" />
          </button>
          <img
            src={lightboxImage}
            alt=""
            className="max-w-full max-h-[90vh] object-contain rounded-lg"
            onClick={(e) => e.stopPropagation()}
          />
        </div>
      )}

      <Footer />
    </div>
  );
};

export default ProjectDetails;
