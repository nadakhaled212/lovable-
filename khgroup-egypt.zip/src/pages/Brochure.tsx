import { MapPin, Phone, Mail, Download } from "lucide-react";
import { useRef, useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import khLogo from "@/assets/kh-logo.png";
import heroBuilding from "@/assets/cyprus-panorama.jpg";
import projectImage from "@/assets/cyprus-pool-sea.png";
import footerImage from "@/assets/cyprus-building.png";

const Brochure = () => {
  const contentRef = useRef<HTMLDivElement>(null);
  const [downloading, setDownloading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [activeId, setActiveId] = useState<string>("hero");

  const sections = [
    { id: "hero", en: "Cover", ar: "الغلاف" },
    { id: "about", en: "About", ar: "من نحن" },
    { id: "projects", en: "Projects", ar: "المشاريع" },
    { id: "contact", en: "Contact", ar: "تواصل" },
  ];

  useEffect(() => {
    const onScroll = () => {
      const h = document.documentElement;
      const scrolled = h.scrollTop;
      const total = h.scrollHeight - h.clientHeight;
      setProgress(total > 0 ? (scrolled / total) * 100 : 0);

      // Determine active section
      let current = sections[0].id;
      for (const s of sections) {
        const el = document.getElementById(s.id);
        if (el && el.getBoundingClientRect().top <= 120) current = s.id;
      }
      setActiveId(current);
    };
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const scrollTo = (id: string) => {
    document.getElementById(id)?.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const handleDownload = async () => {
    if (!contentRef.current) return;
    setDownloading(true);
    try {
      const [{ default: html2canvas }, { default: jsPDF }] = await Promise.all([
        import("html2canvas"),
        import("jspdf"),
      ]);

      const sections = Array.from(
        contentRef.current.querySelectorAll<HTMLElement>("[data-pdf-section]")
      );

      const pdf = new jsPDF({ orientation: "portrait", unit: "mm", format: "a4" });
      const pageWidth = pdf.internal.pageSize.getWidth();
      const pageHeight = pdf.internal.pageSize.getHeight();

      for (let i = 0; i < sections.length; i++) {
        const canvas = await html2canvas(sections[i], {
          scale: 2,
          useCORS: true,
          backgroundColor: null,
          logging: false,
        });
        const imgData = canvas.toDataURL("image/jpeg", 0.92);
        const imgWidth = pageWidth;
        const imgHeight = (canvas.height * imgWidth) / canvas.width;

        if (imgHeight <= pageHeight) {
          if (i > 0) pdf.addPage();
          pdf.addImage(imgData, "JPEG", 0, 0, imgWidth, imgHeight);
        } else {
          // Slice tall sections across multiple pages
          let remaining = imgHeight;
          let position = 0;
          let first = true;
          while (remaining > 0) {
            if (i > 0 || !first) pdf.addPage();
            pdf.addImage(imgData, "JPEG", 0, -position, imgWidth, imgHeight);
            remaining -= pageHeight;
            position += pageHeight;
            first = false;
          }
        }
      }

      pdf.save("KH-Group-Brochure.pdf");
    } finally {
      setDownloading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#0e1318] text-white scroll-smooth">
      {/* Top progress bar */}
      <div className="fixed top-0 left-0 right-0 z-[60] h-1 bg-white/10 print:hidden">
        <div
          className="h-full bg-[#c9a96a] transition-[width] duration-150"
          style={{ width: `${progress}%` }}
        />
      </div>

      {/* Sticky bilingual section nav */}
      <nav className="fixed top-4 left-1/2 -translate-x-1/2 z-50 print:hidden hidden md:flex items-center gap-1 rounded-full bg-black/60 backdrop-blur-md border border-white/10 px-2 py-1.5">
        {sections.map((s) => (
          <button
            key={s.id}
            onClick={() => scrollTo(s.id)}
            className={`px-3 py-1.5 rounded-full text-xs tracking-wide transition-colors ${
              activeId === s.id
                ? "bg-[#c9a96a] text-black"
                : "text-white/70 hover:text-white hover:bg-white/10"
            }`}
          >
            <span className="font-medium">{s.en}</span>
            <span className="font-arabic mx-1.5 opacity-70">·</span>
            <span className="font-arabic">{s.ar}</span>
          </button>
        ))}
      </nav>

      {/* Floating download button (excluded from PDF) */}
      <div className="fixed top-6 right-6 z-50 print:hidden">
        <Button
          onClick={handleDownload}
          disabled={downloading}
          className="bg-[#c9a96a] text-black hover:bg-[#b89656] shadow-lg"
        >
          <Download className="w-4 h-4" />
          {downloading ? "Generating..." : "Download PDF"}
        </Button>
      </div>

      <div ref={contentRef}>
      {/* HERO */}
      <section id="hero" data-pdf-section className="relative h-[100vh] w-full overflow-hidden scroll-mt-20">
        <img src={heroBuilding} alt="Luxury development" className="absolute inset-0 w-full h-full object-cover" />
        <div className="absolute inset-0 bg-gradient-to-b from-black/50 via-black/30 to-black/70" />
        <div className="relative z-10 h-full flex flex-col items-center pt-16 px-6 text-center">
          <img src={khLogo} alt="KH Group" className="h-20 w-auto mb-4 brightness-0 invert opacity-90" />
          <p className="font-arabic text-[#c9a96a] tracking-widest text-sm mb-10">نبني عن ثقة</p>
          <h1 className="font-serif text-4xl md:text-6xl tracking-[0.2em] text-white/95 leading-tight">
            LUXURY REAL ESTATE
            <br />
            DEVELOPMENT
          </h1>
          <div className="mt-6 w-12 h-px bg-[#c9a96a]" />
        </div>
      </section>

      {/* WHO WE ARE */}
      <section id="about" data-pdf-section className="bg-white text-[#0e1318] py-20 px-6 md:px-16 scroll-mt-20">
        <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          {/* English */}
          <div>
            <h2 className="font-serif text-3xl tracking-[0.15em] mb-10 text-[#0e1318]">WHO WE ARE</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-[#c9a96a] tracking-[0.2em] text-sm mb-3">ABOUT KH GROUP</h3>
                <p className="text-sm leading-relaxed text-neutral-700">
                  We are a leading multinational holding group with diversified investments across real estate development, industrial complexes, agriculture, and infrastructure. Our portfolio reflects decades of trusted delivery and excellence across the Middle East and Mediterranean.
                </p>
              </div>
              <div>
                <h3 className="text-[#c9a96a] tracking-[0.2em] text-sm mb-3">OUR VISION</h3>
                <p className="text-sm leading-relaxed text-neutral-700">
                  We aim to be a globally recognized developer known for creating sustainable, intelligent, and architecturally distinguished communities that enhance the lives of residents and elevate the standards of modern living.
                </p>
              </div>
              <div>
                <h3 className="text-[#c9a96a] tracking-[0.2em] text-sm mb-3">OUR MISSION</h3>
                <p className="text-sm leading-relaxed text-neutral-700">
                  We deliver innovative real estate and industrial projects that combine modern architectural design, premium construction quality, and long-term value, while creating lasting partnerships built on transparency, integrity, and quality management.
                </p>
              </div>
            </div>
          </div>
          {/* Arabic */}
          <div dir="rtl" className="font-arabic">
            <h2 className="font-serif text-3xl tracking-wide mb-10 text-[#0e1318]">من نحن</h2>
            <div className="space-y-8">
              <div>
                <h3 className="text-[#c9a96a] text-sm mb-3">نبذة عن مجموعة KH</h3>
                <p className="text-sm leading-relaxed text-neutral-700">
                  نحن مجموعة قابضة متعددة الجنسيات ورائدة في الاستثمارات المتنوعة عبر التطوير العقاري والمجمعات الصناعية والزراعة والبنية التحتية. تعكس محفظتنا عقوداً من الإنجاز الموثوق والتميز في الشرق الأوسط ومنطقة البحر المتوسط.
                </p>
              </div>
              <div>
                <h3 className="text-[#c9a96a] text-sm mb-3">الرؤية</h3>
                <p className="text-sm leading-relaxed text-neutral-700">
                  نسعى لأن نكون مطوّراً عقارياً عالمياً معروفاً بإنشاء مجتمعات مستدامة وذكية ومتميزة معمارياً، تُحسّن حياة الساكنين وترفع معايير العيش العصري.
                </p>
              </div>
              <div>
                <h3 className="text-[#c9a96a] text-sm mb-3">الرسالة</h3>
                <p className="text-sm leading-relaxed text-neutral-700">
                  نقدم مشاريع عقارية وصناعية مبتكرة تجمع بين التصميم المعماري الحديث وجودة البناء الفاخرة والقيمة طويلة الأمد، مع بناء شراكات مستدامة قائمة على الشفافية والنزاهة وإدارة الجودة.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* DIVIDER IMAGE */}
      <section data-pdf-section className="relative h-[40vh] overflow-hidden">
        <img src={heroBuilding} alt="Project view" className="w-full h-full object-cover" />
      </section>

      {/* SIGNATURE PROJECTS */}
      <section id="projects" data-pdf-section className="bg-[#0e1318] py-20 px-6 md:px-16 scroll-mt-20">
        <div className="max-w-6xl mx-auto text-center mb-12">
          <p className="font-arabic text-[#c9a96a] text-sm mb-2">مشاريعنا</p>
          <h2 className="font-serif text-3xl md:text-4xl tracking-[0.2em] text-white">SIGNATURE PROJECTS</h2>
          <div className="w-16 h-px bg-[#c9a96a] mx-auto mt-4" />
        </div>

        <div className="max-w-6xl mx-auto space-y-16">
          {/* Project 1 */}
          <div>
            <div className="grid md:grid-cols-2 gap-4 mb-6">
              <h3 className="text-[#c9a96a] tracking-[0.15em] text-lg">IBDAA INDUSTRIAL COMPLEX (1)</h3>
              <h3 className="font-arabic text-[#c9a96a] text-lg text-right" dir="rtl">مجمع صناعات إبداع (1)</h3>
            </div>
            <img src={projectImage} alt="Ibdaa Industrial Complex" className="w-full h-72 md:h-96 object-cover rounded-sm mb-6" />
            <div className="grid md:grid-cols-2 gap-12 text-sm text-white/80">
              <div>
                <p className="leading-relaxed mb-4">
                  A landmark mixed-use complex aimed at supporting production of fabric and textiles, garment production, and various other industries within a fully integrated environment that includes:
                </p>
                <ul className="space-y-1 list-disc list-inside text-white/70">
                  <li>Industrial units</li>
                  <li>Workforce housing</li>
                  <li>Logistics services</li>
                </ul>
              </div>
              <div dir="rtl" className="font-arabic">
                <p className="leading-relaxed mb-4">
                  مشروع متكامل في 6 أكتوبر بمساحة تتجاوز 21,000 م² يضم وحدات صناعية وسكناً للعمالة وخدمات لوجستية متطورة، يدعم قطاعات الغزل والنسيج والصناعات التحويلية:
                </p>
                <ul className="space-y-1 list-disc list-inside text-white/70 mr-4">
                  <li>مساحة 21,000 م²</li>
                  <li>113 وحدة صناعية</li>
                  <li>سكن للعمالة وخدمات لوجستية</li>
                </ul>
              </div>
            </div>
          </div>

          <div className="w-full h-px bg-white/10" />

          {/* Project 2 */}
          <div className="bg-[#1a1f25] p-8 md:p-12 rounded-sm">
            <div className="grid md:grid-cols-2 gap-12">
              <div>
                <h3 className="text-[#c9a96a] tracking-[0.15em] text-lg mb-4">RIYADH INFRASTRUCTURE</h3>
                <p className="text-sm leading-relaxed text-white/70">
                  Strategic infrastructure development supporting smart city expansion in Riyadh — including roadworks, utility networks, and renewable-ready zones aligned with Saudi Vision 2030.
                </p>
              </div>
              <div dir="rtl" className="font-arabic text-right">
                <h3 className="text-[#c9a96a] text-lg mb-4">أعمال البنية التحتية في الرياض</h3>
                <p className="text-sm leading-relaxed text-white/70">
                  تطوير بنية تحتية استراتيجية يدعم توسع المدن الذكية في الرياض، تشمل أعمال الطرق وشبكات المرافق ومناطق جاهزة للطاقة المتجددة بما يتماشى مع رؤية المملكة 2030.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* FOOTER IMAGE */}
      <section data-pdf-section className="relative h-[35vh] overflow-hidden">
        <img src={footerImage} alt="Building" className="w-full h-full object-cover" />
      </section>

      {/* GET IN TOUCH */}
      <section id="contact" data-pdf-section className="bg-white text-[#0e1318] py-16 px-6 scroll-mt-20">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="font-serif text-3xl tracking-[0.2em] mb-2">GET IN TOUCH</h2>
          <p className="font-arabic text-[#c9a96a] mb-10">تواصل معنا</p>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full border border-[#c9a96a] flex items-center justify-center mb-3">
                <MapPin className="w-5 h-5 text-[#c9a96a]" />
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                Cairo, Egypt<br />
                <span className="font-arabic">القاهرة، مصر</span>
              </p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full border border-[#c9a96a] flex items-center justify-center mb-3">
                <Phone className="w-5 h-5 text-[#c9a96a]" />
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                +20 XX XXXXXXX<br />
                +20 XX XXXXXXX
              </p>
            </div>
            <div className="flex flex-col items-center">
              <div className="w-12 h-12 rounded-full border border-[#c9a96a] flex items-center justify-center mb-3">
                <Mail className="w-5 h-5 text-[#c9a96a]" />
              </div>
              <p className="text-xs text-neutral-600 leading-relaxed">
                info@khgroup.com<br />
                contact@khgroup.com
              </p>
            </div>
          </div>

          <div className="pt-8 border-t border-neutral-200">
            <img src={khLogo} alt="KH Group" className="h-14 mx-auto mb-2" />
            <p className="font-arabic text-[#c9a96a] text-xs tracking-widest">نبني عن ثقة</p>
          </div>
        </div>
      </section>
      </div>
    </div>
  );
};

export default Brochure;
