import { useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import HeroSlider from "@/components/HeroSlider";
import Footer from "@/components/Footer";
import { Building2, Factory, Sprout, GraduationCap, Target, Eye, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

const Home = () => {
  const { t } = useLanguage();
  const navigate = useNavigate();

  const sectors = [
    { icon: Building2, title: t("home.realestate.title"), description: t("home.realestate.desc"), path: "/real-estate" },
    { icon: Factory, title: t("home.industrial.title"), description: t("home.industrial.desc"), path: "/industrial" },
    { icon: Sprout, title: t("home.agriculture.title"), description: t("home.agriculture.desc"), path: "/agriculture" },
    { icon: GraduationCap, title: t("home.education.title"), description: t("home.education.desc"), path: "/education" },
  ];

  const stats = [
    { number: "25+", label: t("home.stats.years") },
    { number: "50+", label: t("home.stats.projects") },
    { number: "10K+", label: t("home.stats.families") },
    { number: "500+", label: t("home.stats.hectares") },
  ];

  return (
    <div className="min-h-screen">
      <SEO title="KH Group | Real Estate & Industrial Development in Egypt" description="KH Group is an Egyptian real estate and industrial development company based in 10th of Ramadan City, delivering modern industrial complexes, real estate projects, and investment opportunities." path="/" />
      <Navigation />
      <HeroSlider />

      {/* Our Sectors */}
      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16 animate-fade-in">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">
              {t("home.sectors.title")}
            </h2>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-6" />
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              {t("home.sectors.subtitle")}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {sectors.map((sector, index) => (
              <Card
                key={index}
                className="bg-card border-border hover:border-brand-green transition-all duration-300 group hover:shadow-brand hover:scale-[1.03] cursor-pointer animate-slide-up"
                style={{ animationDelay: `${index * 100}ms` }}
                onClick={() => navigate(sector.path)}
              >
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-brand-green/10 flex items-center justify-center mx-auto mb-6 group-hover:bg-brand-green group-hover:scale-110 transition-all duration-300">
                    <sector.icon className="w-8 h-8 text-brand-green group-hover:text-white" />
                  </div>
                  <h3 className="text-2xl font-serif font-bold mb-4">{sector.title}</h3>
                  <p className="text-muted-foreground leading-relaxed mb-6">{sector.description}</p>
                  <Button className="bg-brand-green text-white hover:bg-brand-green-light w-full">
                    {t("home.sectors.explore")}
                    <ArrowRight className="w-4 h-4 ml-2" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Stats Section */}
      <section className="py-20 bg-secondary border-y border-border">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8">
            {stats.map((stat, index) => (
              <div key={index} className="text-center animate-scale-in" style={{ animationDelay: `${index * 100}ms` }}>
                <div className="text-4xl md:text-5xl font-serif font-bold text-brand-green mb-2">{stat.number}</div>
                <div className="text-white/70 text-sm md:text-base">{stat.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Vision & Mission */}
      <section className="py-24 bg-muted">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12">
            <Card className="bg-card border-brand-green/30 hover:shadow-brand transition-all duration-300">
              <CardContent className="p-10">
                <div className="w-14 h-14 rounded-full bg-brand-green/10 flex items-center justify-center mb-6">
                  <Eye className="w-7 h-7 text-brand-green" />
                </div>
                <h3 className="text-3xl font-serif font-bold mb-4">{t("home.vision.title")}</h3>
                <p className="text-muted-foreground leading-relaxed text-lg">{t("home.vision.text")}</p>
              </CardContent>
            </Card>

            <Card className="bg-card border-brand-green/30 hover:shadow-brand transition-all duration-300">
              <CardContent className="p-10">
                <div className="w-14 h-14 rounded-full bg-brand-green/10 flex items-center justify-center mb-6">
                  <Target className="w-7 h-7 text-brand-green" />
                </div>
                <h3 className="text-3xl font-serif font-bold mb-4">{t("home.mission.title")}</h3>
                <p className="text-muted-foreground leading-relaxed text-lg">{t("home.mission.text")}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Home;
