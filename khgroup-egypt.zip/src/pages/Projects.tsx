import { useState } from "react";
import { useNavigate } from "react-router-dom";
import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { Building2, Factory, Sprout, MapPin, Maximize2 } from "lucide-react";
import project6aCard from "@/assets/project6a-card.jpg";
import villa26Card from "@/assets/villa26.jpg";
import cyprusCompound from "@/assets/cyprus-compound.jpg";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";

const Projects = () => {
  const { t, language } = useLanguage();
  const navigate = useNavigate();
  const [activeFilter, setActiveFilter] = useState("All");

  const filters = [
    { key: "All", label: t("projects.filter.all") },
    { key: "Real Estate", label: t("projects.filter.realestate") },
    { key: "Industrial", label: t("projects.filter.industrial") },
    { key: "Agricultural", label: t("projects.filter.agricultural") },
  ];

  const statusLabels: Record<string, Record<string, string>> = {
    "Planning": { en: "Planning", ar: "قيد التخطيط" },
    "Completed": { en: "Completed", ar: "مكتمل" },
    "Ongoing": { en: "Ongoing", ar: "جاري التنفيذ" },
    "Under Construction": { en: "Under Construction", ar: "تحت الإنشاء" },
  };

  const categoryLabels: Record<string, Record<string, string>> = {
    "Real Estate": { en: "Real Estate", ar: "العقارات" },
    "Industrial": { en: "Industrial", ar: "الصناعة" },
    "Agricultural": { en: "Agricultural", ar: "الزراعة" },
  };

  const projects = [
    { id: 1, title: { en: "Project 6A", ar: "مشروع 6ع" }, category: "Real Estate", location: { en: "10th of Ramadan City, Egypt", ar: "العاشر من رمضان، مصر" }, area: { en: "352 Villas", ar: "352 فيلا" }, status: "Under Construction", image: project6aCard, description: { en: "A modern residential compound of 352 villas in 10th of Ramadan City, featuring smart sustainable design with integrated services including a hospital, education institute, and shopping mall.", ar: "كمباوند سكني عصري يضم 352 فيلا في مدينة العاشر من رمضان، بتصميم ذكي ومستدام مع خدمات متكاملة تشمل مستشفى ومعهد تعليمي ومركز تسوق." } },
    { id: 8, title: { en: "Villa 26", ar: "فيلا 26" }, category: "Real Estate", location: { en: "10th of Ramadan City, Neighborhood 26", ar: "العاشر من رمضان، مجاورة 26" }, area: { en: "Residential Building", ar: "مبنى سكني" }, status: "Completed", image: villa26Card, description: { en: "A premium residential building in Neighborhood 26, 10th of Ramadan City, featuring elegant architectural design with modern finishes and spacious units.", ar: "مبنى سكني فاخر في مجاورة 26 بمدينة العاشر من رمضان، بتصميم معماري أنيق وتشطيبات حديثة ووحدات واسعة." } },
    { id: 9, title: { en: "Cyprus Residential Compound", ar: "مجمع قبرص السكني" }, category: "Real Estate", location: { en: "North Cyprus", ar: "شمال قبرص" }, area: { en: "3 Donums · 5 Buildings", ar: "3 دونمات · 5 مباني" }, status: "Completed", image: cyprusCompound, description: { en: "A modern residential compound in North Cyprus with panoramic sea views for all units, featuring a unique architectural concept across 5 buildings.", ar: "مجمع سكني عصري في شمال قبرص بإطلالات بانورامية على البحر لجميع الوحدات، بتصميم معماري فريد عبر 5 مباني." } },
    { id: 2, title: { en: "Ebdaa 1 Industrial Complex", ar: "مجمع ابداع 1 الصناعي" }, category: "Industrial", location: { en: "10th of Ramadan City", ar: "مدينة العاشر من رمضان" }, area: { en: "120 Hectares", ar: "120 هكتار" }, status: "Completed", image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800", description: { en: "Integrated industrial complex completed with the latest specifications", ar: "مجمع صناعي متكامل تم الانتهاء من تنفيذه بأحدث المواصفات" } },
    { id: 3, title: { en: "Egyptian Countryside - HQI", ar: "الريف المصري - HQI" }, category: "Agricultural", location: { en: "Egypt", ar: "مصر" }, area: { en: "200 Hectares", ar: "200 هكتار" }, status: "Ongoing", image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800", description: { en: "Integrated agricultural project by HQI aimed at developing the Egyptian countryside with the latest agricultural technologies", ar: "مشروع زراعي متكامل من شركة HQI يهدف إلى تطوير الريف المصري بأحدث التقنيات الزراعية" } },
    { id: 5, title: { en: "Ebdaa 2 Industrial Complex", ar: "مجمع ابداع 2 الصناعي" }, category: "Industrial", location: { en: "10th of Ramadan City", ar: "مدينة العاشر من رمضان" }, area: { en: "150 Hectares", ar: "150 هكتار" }, status: "Under Construction", image: "https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=800", description: { en: "Modern industrial complex under construction with international specifications", ar: "مجمع صناعي حديث تحت التنفيذ بمواصفات عالمية" } },
    { id: 7, title: { en: "Ebdaa 3 Industrial Complex", ar: "مجمع ابداع 3 الصناعي" }, category: "Industrial", location: { en: "10th of Ramadan City", ar: "مدينة العاشر من رمضان" }, area: { en: "180 Hectares", ar: "180 هكتار" }, status: "Planning", image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800", description: { en: "Industrial complex in planning phase to be the largest in the region", ar: "مجمع صناعي قيد التخطيط ليكون أكبر المجمعات في المنطقة" } },
    { id: 6, title: { en: "Organic Farming Initiative", ar: "مبادرة الزراعة العضوية" }, category: "Agricultural", location: { en: "Upper Egypt", ar: "صعيد مصر" }, area: { en: "300 Hectares", ar: "300 هكتار" }, status: "Under Construction", image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800", description: { en: "Sustainable organic farming with focus on food security", ar: "زراعة عضوية مستدامة مع التركيز على الأمن الغذائي" } },
  ];

  const filteredProjects = activeFilter === "All" ? projects : projects.filter((p) => p.category === activeFilter);

  const getCategoryIcon = (category: string) => {
    switch (category) {
      case "Real Estate": return Building2;
      case "Industrial": return Factory;
      case "Agricultural": return Sprout;
      default: return Building2;
    }
  };

  return (
    <div className="min-h-screen">
      <SEO title="Our Projects | KH Group Egypt" description="Explore KH Group's portfolio of real estate compounds, industrial complexes, and agricultural projects across Egypt and beyond." path="/projects" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">{t("projects.title")}</h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">{t("projects.subtitle")}</p>
          </div>
        </div>
      </section>

      <section className="py-8 bg-background border-b border-border">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="flex flex-wrap justify-center gap-4">
            {filters.map((filter) => (
              <Button
                key={filter.key}
                onClick={() => setActiveFilter(filter.key)}
                variant={activeFilter === filter.key ? "default" : "outline"}
                className={activeFilter === filter.key ? "bg-brand-green text-white hover:bg-brand-green-light" : "border-border text-foreground hover:border-brand-green hover:text-brand-green"}
              >
                {filter.label}
              </Button>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {filteredProjects.map((project, index) => {
              const Icon = getCategoryIcon(project.category);
              return (
                <Card key={project.id} className="bg-card border-border hover:border-brand-green transition-all duration-300 group overflow-hidden animate-scale-in" style={{ animationDelay: `${index * 100}ms` }}>
                  <div className="relative overflow-hidden h-64">
                    <img src={project.image} alt={project.title[language]} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                    <div className="absolute top-4 right-4 bg-brand-green text-white px-3 py-1 rounded-full text-sm font-semibold">
                      {statusLabels[project.status]?.[language] || project.status}
                    </div>
                  </div>
                  <CardContent className="p-6">
                    <div className="flex items-center space-x-2 mb-3">
                      <Icon className="w-5 h-5 text-brand-green" />
                      <span className="text-sm text-muted-foreground">{categoryLabels[project.category]?.[language] || project.category}</span>
                    </div>
                    <h3 className="text-2xl font-serif font-bold mb-3 group-hover:text-brand-green transition-colors">{project.title[language]}</h3>
                    <p className="text-muted-foreground mb-4 leading-relaxed">{project.description[language]}</p>
                    <div className="space-y-2 text-sm">
                      <div className="flex items-center space-x-2 text-muted-foreground">
                        <MapPin className="w-4 h-4 text-brand-green" /><span>{project.location[language]}</span>
                      </div>
                      <div className="flex items-center space-x-2 text-muted-foreground">
                        <Maximize2 className="w-4 h-4 text-brand-green" /><span>{project.area[language]}</span>
                      </div>
                    </div>
                    <Button className="w-full mt-6 bg-brand-green text-white hover:bg-brand-green-light" onClick={() => navigate(`/projects/${project.id}`)}>
                      {t("projects.viewdetails")}
                    </Button>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Projects;
