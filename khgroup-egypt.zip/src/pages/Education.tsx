import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { GraduationCap, School } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";
import SectorVisionMission from "@/components/SectorVisionMission";
import { Card, CardContent } from "@/components/ui/card";
import fayoumNew1 from "@/assets/fayoum-school-new-1.jpeg";
import fayoumNew2 from "@/assets/fayoum-school-new-2.jpeg";
import fayoumNew3 from "@/assets/fayoum-school-new-3.jpeg";
import pioneer1 from "@/assets/pioneer-school-1.jpeg";

const Education = () => {
  const { language } = useLanguage();
  const isAr = language === "ar";

  const fayoumImages: { src: string; en: string; ar: string }[] = [
    { src: fayoumNew2, en: "Main Facade – Green Smart American School", ar: "الواجهة الرئيسية – مدرسة جرين سمارت الأمريكية" },
    { src: fayoumNew1, en: "Aerial View – Green Roof & Sustainable Design", ar: "منظور علوي – السطح الأخضر والتصميم المستدام" },
    { src: fayoumNew3, en: "Aerial Side View – Inner Courtyard & Campus Layout", ar: "منظور علوي جانبي – الفناء الداخلي وتنسيق الحرم المدرسي" },
  ];

  const projects = [
    {
      key: "rawad",
      titleEn: "Pioneer Al-Siddiq School",
      titleAr: "مدرسة رواد الصديق",
      descEn: "An integrated educational project designed to deliver a modern learning experience that blends academic excellence with character building.",
      descAr: "مشروع تعليمي متكامل مصمم لتقديم تجربة تعليمية حديثة تجمع بين التميز الأكاديمي وبناء الشخصية.",
      statusEn: "Completed",
      statusAr: "تم الانتهاء",
      statusVariant: "done" as const,
      images: [
        { src: pioneer1, en: "Main Facade – Pioneer Al-Siddiq School", ar: "الواجهة الرئيسية – مدرسة رواد الصديق" },
      ] as { src: string; en: string; ar: string }[],
    },
    {
      key: "fayoum",
      titleEn: "Fayoum School (Green Smart American School)",
      titleAr: "مدرسة الفيوم (Green Smart American School)",
      descEn: "A landmark green & smart American school in Fayoum, designed around sustainability, vertical greenery, and modern educational facilities.",
      descAr: "مدرسة أمريكية ذكية وخضراء بمحافظة الفيوم، مصممة حول الاستدامة والمساحات الخضراء العمودية والمرافق التعليمية الحديثة.",
      statusEn: "Under Construction",
      statusAr: "تحت التنفيذ",
      statusVariant: "progress" as const,
      images: fayoumImages,
    },
  ];

  return (
    <div className="min-h-screen">
      <SEO title="Education Sector | KH Group Egypt" description="KH Group invests in education through modern schools and learning institutions designed to empower Egypt's next generation." path="/education" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="w-20 h-20 rounded-full bg-brand-green/20 flex items-center justify-center mx-auto mb-6">
              <GraduationCap className="w-10 h-10 text-brand-green" />
            </div>
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">
              {isAr ? "قطاع التطوير التعليمي" : "Educational Development Sector"}
            </h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">
              {isAr
                ? "بناء الإنسان المتكامل من خلال نموذج تعليمي تطبيقي يجمع بين المعرفة والمهارة والشخصية."
                : "Building well-rounded individuals through an applied educational model that unites knowledge, skill, and character."}
            </p>
          </div>
        </div>
      </section>

      <SectorVisionMission
        vision={[
          {
            text: {
              en: "Leadership in shaping the integrated individual through an applied educational model that combines academic knowledge, practical skill, and well-rounded character building, empowering generations capable of leading the future.",
              ar: "الريادة في بناء الإنسان المتكامل من خلال نموذج تعليمي تطبيقي يدمج بين المعرفة الأكاديمية والمهارة العملية وبناء الشخصية المتكاملة، لتمكين أجيال قادرة على قيادة المستقبل.",
            },
          },
        ]}
        mission={[
          {
            text: {
              en: "Delivering a unique educational experience focused on practical application, aimed at refining the student's character and equipping them with the tools to become an active and productive member of society, while committing to the highest standards of educational quality.",
              ar: "تقديم تجربة تعليمية فريدة تركز على الجانب التطبيقي، تهدف إلى صقل شخصية الطالب وتزويده بالأدوات التي تجعله عنصرًا فاعلًا ومنتجًا في المجتمع، مع الالتزام بأعلى معايير الجودة التعليمية.",
            },
          },
        ]}
      />

      {/* Projects */}
      <section className="py-20 bg-background" dir={isAr ? "rtl" : "ltr"}>
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-14 animate-fade-in">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">
              {isAr ? "مشاريع القطاع التعليمي" : "Educational Sector Projects"}
            </h2>
            <div className="w-24 h-1 bg-brand-green mx-auto" />
          </div>

          <div className="space-y-16">
            {projects.map((p) => (
              <div key={p.key} className="animate-fade-in">
                <div className="flex items-center gap-4 mb-8">
                  <div className="w-12 h-12 rounded-full bg-brand-green/10 flex items-center justify-center">
                    <School className="w-6 h-6 text-brand-green" />
                  </div>
                  <div>
                    <div className="flex flex-wrap items-center gap-3">
                      <h3 className="text-2xl md:text-3xl font-serif font-bold">
                        {isAr ? p.titleAr : p.titleEn}
                      </h3>
                      <span
                        className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-semibold border ${
                          p.statusVariant === "done"
                            ? "bg-brand-green/15 text-brand-green border-brand-green/30"
                            : "bg-amber-500/15 text-amber-600 border-amber-500/30"
                        }`}
                      >
                        <span
                          className={`w-2 h-2 rounded-full ${
                            p.statusVariant === "done" ? "bg-brand-green" : "bg-amber-500 animate-pulse"
                          }`}
                        />
                        {isAr ? p.statusAr : p.statusEn}
                      </span>
                    </div>
                    <p className="text-muted-foreground mt-1 max-w-3xl">
                      {isAr ? p.descAr : p.descEn}
                    </p>
                  </div>
                </div>

                {p.images.length > 0 ? (
                  <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
                    {p.images.map((img, i) => (
                      <Card
                        key={i}
                        className="overflow-hidden bg-card border-border hover:border-brand-green hover:shadow-brand transition-all duration-300 group"
                      >
                        <div className="aspect-[4/3] overflow-hidden bg-muted">
                          <img
                            src={img.src}
                            alt={isAr ? img.ar : img.en}
                            loading="lazy"
                            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
                          />
                        </div>
                        <CardContent className="p-4">
                          <p className="text-sm font-medium text-foreground text-center">
                            {isAr ? img.ar : img.en}
                          </p>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                ) : (
                  <Card className="bg-card border-border">
                    <CardContent className="p-10 text-center text-muted-foreground">
                      {isAr ? "صور المشروع ستضاف قريبًا." : "Project images coming soon."}
                    </CardContent>
                  </Card>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Education;