import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { Sprout, MapPin, Maximize2, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import SectorVisionMission from "@/components/SectorVisionMission";

const Agriculture = () => {
  const navigate = useNavigate();
  const { language, t } = useLanguage();

  const projects = [
    { id: 3, title: language === "ar" ? "الريف المصري - HQI" : "Egyptian Countryside - HQI", location: language === "ar" ? "مصر" : "Egypt", area: language === "ar" ? "200 هكتار" : "200 Hectares", status: language === "ar" ? "جاري التنفيذ" : "Ongoing", image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800", description: language === "ar" ? "مشروع زراعي متكامل من شركة HQI يهدف إلى تطوير الريف المصري بأحدث التقنيات الزراعية" : "An integrated agricultural project by HQI aimed at developing the Egyptian countryside with the latest agricultural technologies" },
    { id: 6, title: language === "ar" ? "مبادرة الزراعة العضوية" : "Organic Farming Initiative", location: language === "ar" ? "صعيد مصر" : "Upper Egypt", area: language === "ar" ? "300 هكتار" : "300 Hectares", status: language === "ar" ? "تحت الإنشاء" : "Under Construction", image: "https://images.unsplash.com/photo-1574943320219-553eb213f72d?w=800", description: language === "ar" ? "زراعة عضوية مستدامة مع التركيز على الأمن الغذائي" : "Sustainable organic farming with focus on food security" },
  ];

  return (
    <div className="min-h-screen">
      <SEO title="Agricultural Projects | KH Group Egypt" description="KH Group's agricultural sector focuses on sustainable farming, modern irrigation, and food security projects across Egypt." path="/agriculture" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="w-20 h-20 rounded-full bg-brand-green/20 flex items-center justify-center mx-auto mb-6">
              <Sprout className="w-10 h-10 text-brand-green" />
            </div>
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">
              {language === "ar" ? "القطاع الزراعي" : "Agriculture Sector"}
            </h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">
              {language === "ar" ? "تنفيذ مشاريع زراعية مستدامة تضمن الأمن الغذائي والاستدامة" : "Implementing sustainable agricultural projects that ensure food security and sustainability"}
            </p>
          </div>
        </div>
      </section>

      <SectorVisionMission
        vision={[
          { title: { en: "Self-Sovereignty", ar: "السيادة الذاتية" }, text: { en: "Managing and developing the agricultural area with self-execution capabilities.", ar: "إدارة وتنمية الرقعة الزراعية بقدرات تنفيذية ذاتية." } },
          { title: { en: "Agricultural Intelligence", ar: "الذكاء الزراعي" }, text: { en: "Applying smart farming techniques and sustainable irrigation systems.", ar: "تطبيق تقنيات الزراعة الذكية (Smart Farming) ونظم الري المستدام." } },
          { title: { en: "Quality", ar: "الجودة" }, text: { en: "Vital agricultural production with high nutritional value.", ar: "إنتاج زراعي حيوي وعالي القيمة الغذائية." } },
          { title: { en: "Integration", ar: "التكامل" }, text: { en: "Owning the full supply chain from seeds to harvest and recycling.", ar: "امتلاك كامل سلاسل الإمداد من البذور وحتى الحصاد والتدوير." } },
          { title: { en: "Innovation", ar: "الابتكار" }, text: { en: "Using modern agricultural engineering and advanced soil sensing tools.", ar: "استخدام الهندسة الزراعية الحديثة وأدوات استشعار التربة المتقدمة." } },
        ]}
        mission={[
          { text: { en: "Transforming the agricultural sector into a smart, sustainable system that provides safe, high-quality food by leveraging science and technology in land reclamation and management, achieving balance between productivity and the preservation of natural resources.", ar: "تحويل القطاع الزراعي إلى منظومة ذكية ومستدامة توفر غذاءً آمنًا وعالي الجودة، من خلال توظيف العلم والتكنولوجيا في استصلاح وإدارة الأراضي، وتحقيق التوازن بين الإنتاجية والحفاظ على الموارد الطبيعية." } },
        ]}
      />

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-12 text-center">
            {language === "ar" ? "مشاريعنا الزراعية" : "Our Agricultural Projects"}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <Card key={project.id} className="bg-card border-border hover:border-brand-green transition-all duration-300 group overflow-hidden cursor-pointer hover:scale-[1.03] animate-scale-in" style={{ animationDelay: `${index * 100}ms` }} onClick={() => navigate(`/projects/${project.id}`)}>
                <div className="relative overflow-hidden h-64">
                  <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute top-4 right-4 bg-brand-green text-white px-3 py-1 rounded-full text-sm font-semibold">{project.status}</div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-serif font-bold mb-3 group-hover:text-brand-green transition-colors">{project.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{project.description}</p>
                  <div className="space-y-2 text-sm mb-6">
                    <div className="flex items-center space-x-2 text-muted-foreground"><MapPin className="w-4 h-4 text-brand-green" /><span>{project.location}</span></div>
                    <div className="flex items-center space-x-2 text-muted-foreground"><Maximize2 className="w-4 h-4 text-brand-green" /><span>{project.area}</span></div>
                  </div>
                  <Button className="w-full bg-brand-green text-white hover:bg-brand-green-light">{t("projects.viewdetails")} <ArrowRight className="w-4 h-4 ml-2" /></Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Agriculture;
