import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { Building2, MapPin, Maximize2, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import SectorVisionMission from "@/components/SectorVisionMission";
import villa26Card from "@/assets/villa26.jpg";
import cyprusCompound from "@/assets/cyprus-compound.jpg";
import project6aAerialTop from "@/assets/project6a-aerial-top.jpg";

const RealEstate = () => {
  const navigate = useNavigate();
  const { language, t } = useLanguage();

  const projects = [
    { id: 1, title: language === "ar" ? "مشروع 6ع" : "Project 6A", location: language === "ar" ? "العاشر من رمضان، مصر" : "10th of Ramadan, Egypt", area: language === "ar" ? "352 فيلا" : "352 Villas", status: language === "ar" ? "تحت الإنشاء" : "Under Construction", image: project6aAerialTop, description: language === "ar" ? "كمباوند سكني عصري يضم 352 فيلا في مدينة العاشر من رمضان، بتصميم ذكي ومستدام مع خدمات متكاملة تشمل مستشفى ومعهد تعليمي ومركز تسوق." : "A modern residential compound of 352 villas in 10th of Ramadan City, featuring smart sustainable design with integrated services including a hospital, education institute, and shopping mall." },
    { id: 8, title: language === "ar" ? "فيلا 26" : "Villa 26", location: language === "ar" ? "العاشر من رمضان، مجاورة 26" : "10th of Ramadan City, Neighborhood 26", area: language === "ar" ? "مبنى سكني" : "Residential Building", status: language === "ar" ? "مكتمل" : "Completed", image: villa26Card, description: language === "ar" ? "مبنى سكني فاخر في مجاورة 26 بمدينة العاشر من رمضان، بتصميم معماري أنيق وتشطيبات حديثة ووحدات واسعة." : "A premium residential building in Neighborhood 26, 10th of Ramadan City, featuring elegant architectural design with modern finishes and spacious units." },
    { id: 9, title: language === "ar" ? "مجمع قبرص السكني" : "Cyprus Residential Compound", location: language === "ar" ? "شمال قبرص" : "North Cyprus", area: language === "ar" ? "3 دونمات · 5 مباني" : "3 Donums · 5 Buildings", status: language === "ar" ? "مكتمل" : "Completed", image: cyprusCompound, description: language === "ar" ? "مجمع سكني عصري في شمال قبرص بإطلالات بانورامية على البحر لجميع الوحدات، بتصميم معماري فريد عبر 5 مباني." : "A modern residential compound in North Cyprus with panoramic sea views for all units, featuring a unique architectural concept across 5 buildings." },
  ];

  return (
    <div className="min-h-screen">
      <SEO title="Real Estate Projects | KH Group Egypt" description="Discover KH Group's modern residential and commercial real estate developments in 10th of Ramadan City and beyond, designed for quality and long-term value." path="/real-estate" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="w-20 h-20 rounded-full bg-brand-green/20 flex items-center justify-center mx-auto mb-6">
              <Building2 className="w-10 h-10 text-brand-green" />
            </div>
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">
              {language === "ar" ? "قطاع العقارات" : "Real Estate Sector"}
            </h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">
              {language === "ar" ? "تطوير مجتمعات سكنية وتجارية حديثة تعيد تعريف الحياة الحضرية في مصر" : "Developing modern residential and commercial communities that redefine urban living in Egypt"}
            </p>
          </div>
        </div>
      </section>

      <SectorVisionMission
        vision={[
          {
            text: {
              en: "To be the most trusted real estate developer through fully integrated self-execution, adopting smart city solutions and sustainable green buildings, with the highest quality standards through ownership of the latest tools and global technologies.",
              ar: "أن نكون المطور العقاري الأكثر موثوقية من خلال التنفيذ الذاتي المتكامل، متبنين حلول المدن الذكية (Smart Solutions) والأبنية الخضراء المستدامة (Green Buildings) بأعلى معايير الجودة عبر امتلاكنا لأحدث الأدوات والتقنيات العالمية.",
            },
          },
        ]}
        mission={[
          {
            text: {
              en: "Developing residential and industrial urban communities ahead of their time, grounded in engineering innovation and environmental sustainability, to deliver real added value to our clients through full control over the quality of every development element.",
              ar: "تطوير مجتمعات عمرانية سكنية وصناعية تسبق عصرها، ترتكز على الابتكار الهندسي والاستدامة البيئية، لتقديم قيمة مضافة حقيقية لعملائنا من خلال السيطرة الكاملة على جودة جميع عناصر التطوير.",
            },
          },
        ]}
      />

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-12 text-center">
            {language === "ar" ? "مشاريعنا العقارية" : "Our Real Estate Projects"}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <Card key={project.id} className="bg-card border-border hover:border-brand-green transition-all duration-300 group overflow-hidden cursor-pointer hover:scale-[1.03] animate-scale-in" style={{ animationDelay: `${index * 100}ms` }} onClick={() => navigate(`/projects/${project.id}`)}>
                <div className="relative overflow-hidden h-64">
                  <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute top-4 right-4 bg-brand-green text-white px-3 py-1 rounded-full text-sm font-semibold">{project.status}</div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-serif font-bold mb-3 group-hover:text-brand-green transition-colors">{project.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{project.description}</p>
                  <div className="space-y-2 text-sm mb-6">
                    <div className="flex items-center space-x-2 text-muted-foreground"><MapPin className="w-4 h-4 text-brand-green" /><span>{project.location}</span></div>
                    <div className="flex items-center space-x-2 text-muted-foreground"><Maximize2 className="w-4 h-4 text-brand-green" /><span>{project.area}</span></div>
                  </div>
                  <Button className="w-full bg-brand-green text-white hover:bg-brand-green-light">{t("projects.viewdetails")} <ArrowRight className="w-4 h-4 ml-2" /></Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default RealEstate;
