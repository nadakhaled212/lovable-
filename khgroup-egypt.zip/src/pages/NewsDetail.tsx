import Navigation from "@/components/Navigation";
import Footer from "@/components/Footer";
import { Calendar, ArrowLeft } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useLanguage } from "@/contexts/LanguageContext";
import { useParams, useNavigate } from "react-router-dom";

const newsArticles = [
  { id: 1, title: "KH Group Launches New Sustainable Housing Project", titleAr: "مجموعة KH تطلق مشروع إسكان مستدام جديد", date: "2024-01-15", category: "Real Estate", categoryAr: "العقارات", excerpt: "KH Group announces the launch of its latest sustainable housing development in New Cairo, featuring eco-friendly design and smart home technology.", excerptAr: "تعلن مجموعة KH عن إطلاق أحدث مشروع إسكان مستدام في القاهرة الجديدة، يتميز بتصميم صديق للبيئة وتقنية المنزل الذكي.", image: "https://images.unsplash.com/photo-1560518883-ce09059eeffa?w=800", content: "KH Group is proud to announce the launch of its latest sustainable housing development in New Cairo. This groundbreaking project features eco-friendly design principles, smart home technology integration, and community-focused amenities that set a new standard for modern living in Egypt.\n\nThe development spans over 50 acres and will include residential units ranging from apartments to luxury villas, all designed with sustainability at their core. Solar panels, rainwater harvesting systems, and energy-efficient building materials are just some of the green features incorporated into the design.\n\nSmart home technology will be standard in every unit, allowing residents to control lighting, climate, and security systems through their smartphones. The community will also feature landscaped gardens, walking trails, sports facilities, and a commercial center.\n\n\"This project represents our commitment to building communities that are not only beautiful and functional but also environmentally responsible,\" said the CEO of KH Group. \"We believe that sustainable living should be accessible to everyone, and this development is a significant step toward that vision.\"", contentAr: "تفخر مجموعة KH بالإعلان عن إطلاق أحدث مشروع إسكان مستدام في القاهرة الجديدة. يتميز هذا المشروع الرائد بمبادئ التصميم الصديق للبيئة، ودمج تقنية المنزل الذكي، والمرافق المجتمعية التي تضع معيارًا جديدًا للحياة العصرية في مصر.\n\nيمتد المشروع على مساحة تزيد عن 50 فدانًا وسيشمل وحدات سكنية تتراوح بين الشقق والفيلات الفاخرة، وكلها مصممة بالاستدامة في جوهرها. الألواح الشمسية وأنظمة تجميع مياه الأمطار ومواد البناء الموفرة للطاقة هي بعض الميزات الخضراء المدمجة في التصميم.\n\nستكون تقنية المنزل الذكي قياسية في كل وحدة، مما يتيح للسكان التحكم في الإضاءة والمناخ وأنظمة الأمان من خلال هواتفهم الذكية. سيضم المجتمع أيضًا حدائق منسقة ومسارات للمشي ومرافق رياضية ومركزًا تجاريًا." },
  { id: 2, title: "Industrial Complex Receives International Sustainability Award", titleAr: "المجمع الصناعي يحصل على جائزة الاستدامة الدولية", date: "2024-01-10", category: "Industrial", categoryAr: "الصناعة", excerpt: "Our Smart Industrial Park has been recognized with the Global Sustainability Excellence Award for innovative green manufacturing practices.", excerptAr: "تم تكريم مجمعنا الصناعي الذكي بجائزة التميز في الاستدامة العالمية لممارسات التصنيع الأخضر المبتكرة.", image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800", content: "KH Group's Smart Industrial Park has been awarded the prestigious Global Sustainability Excellence Award, recognizing its innovative approach to green manufacturing and sustainable industrial practices.\n\nThe award highlights the park's commitment to reducing environmental impact while maintaining high productivity standards. Key features include advanced waste management systems, renewable energy integration, and water recycling facilities that have reduced the park's carbon footprint by over 60%.\n\nThe industrial complex serves as a model for sustainable manufacturing in the Middle East and North Africa region, attracting international companies seeking environmentally responsible production facilities.", contentAr: "حصل المجمع الصناعي الذكي التابع لمجموعة KH على جائزة التميز في الاستدامة العالمية المرموقة، تقديرًا لنهجه المبتكر في التصنيع الأخضر والممارسات الصناعية المستدامة.\n\nتسلط الجائزة الضوء على التزام المجمع بتقليل التأثير البيئي مع الحفاظ على معايير إنتاجية عالية. تشمل الميزات الرئيسية أنظمة إدارة النفايات المتقدمة ودمج الطاقة المتجددة ومرافق إعادة تدوير المياه التي خفضت البصمة الكربونية للمجمع بأكثر من 60%." },
  { id: 3, title: "Partnership with Ministry of Agriculture Announced", titleAr: "الإعلان عن شراكة مع وزارة الزراعة", date: "2024-01-05", category: "Agriculture", categoryAr: "الزراعة", excerpt: "KH Group partners with the Ministry of Agriculture to develop state-of-the-art agricultural facilities promoting food security in Egypt.", excerptAr: "تتعاون مجموعة KH مع وزارة الزراعة لتطوير مرافق زراعية متطورة تعزز الأمن الغذائي في مصر.", image: "https://images.unsplash.com/photo-1625246333195-78d9c38ad449?w=800", content: "KH Group has announced a strategic partnership with the Egyptian Ministry of Agriculture to develop cutting-edge agricultural facilities across the country. This collaboration aims to enhance food security, promote sustainable farming practices, and create employment opportunities in rural areas.\n\nThe partnership will focus on developing modern greenhouse complexes, irrigation systems, and post-harvest processing facilities. Advanced agricultural technologies including precision farming, drone monitoring, and AI-powered crop management will be implemented across all facilities.\n\nThe first phase of the project will cover 10,000 acres in the Nile Delta region, with plans to expand to 50,000 acres over the next five years.", contentAr: "أعلنت مجموعة KH عن شراكة استراتيجية مع وزارة الزراعة المصرية لتطوير مرافق زراعية متطورة في جميع أنحاء البلاد. يهدف هذا التعاون إلى تعزيز الأمن الغذائي وتشجيع الممارسات الزراعية المستدامة وخلق فرص عمل في المناطق الريفية." },
  { id: 4, title: "Record-Breaking Year for KH Group", titleAr: "عام قياسي لمجموعة KH", date: "2023-12-28", category: "Company News", categoryAr: "أخبار الشركة", excerpt: "2023 marks our most successful year yet, with over 15 projects completed and 5,000 new families settling into our communities.", excerptAr: "يمثل عام 2023 أنجح عام لنا حتى الآن، مع إتمام أكثر من 15 مشروعًا واستقرار 5000 عائلة جديدة في مجتمعاتنا.", image: "https://images.unsplash.com/photo-1454165804606-c3d57bc86b40?w=800", content: "KH Group celebrates a record-breaking 2023, with remarkable achievements across all business sectors. The company completed over 15 major projects, welcomed 5,000 new families into its residential communities, and expanded its industrial and agricultural portfolios significantly.\n\nKey highlights include the completion of three major residential compounds, the inauguration of two industrial zones, and the launch of innovative agricultural projects that have increased crop yields by 35% in partner facilities.\n\nThe company also invested heavily in technology and sustainability, implementing smart city solutions across its developments and achieving carbon neutrality in two of its industrial parks.", contentAr: "تحتفل مجموعة KH بعام 2023 القياسي، مع إنجازات ملحوظة عبر جميع قطاعات الأعمال. أكملت الشركة أكثر من 15 مشروعًا رئيسيًا، ورحبت بـ 5000 عائلة جديدة في مجتمعاتها السكنية، ووسعت محافظها الصناعية والزراعية بشكل كبير." },
  { id: 5, title: "Groundbreaking Ceremony for North Coast Development", titleAr: "حفل وضع حجر الأساس لمشروع الساحل الشمالي", date: "2023-12-20", category: "Real Estate", categoryAr: "العقارات", excerpt: "Officials and stakeholders gather for the groundbreaking of our premium North Coast resort, set to redefine luxury coastal living.", excerptAr: "يجتمع المسؤولون وأصحاب المصلحة لحفل وضع حجر الأساس لمنتجعنا الفاخر على الساحل الشمالي، المصمم لإعادة تعريف الحياة الساحلية الفاخرة.", image: "https://images.unsplash.com/photo-1582268611958-ebfd161ef9cf?w=800", content: "KH Group held a prestigious groundbreaking ceremony for its highly anticipated North Coast development. The event brought together government officials, industry leaders, and key stakeholders to mark the beginning of what promises to be a landmark project in luxury coastal living.\n\nThe development will feature premium villas, beachfront apartments, a world-class marina, international restaurants, and extensive leisure facilities. Designed by renowned architects, the project incorporates sustainable building practices and smart technology throughout.\n\nConstruction is expected to be completed in phases over the next four years, with the first units ready for delivery by 2025.", contentAr: "أقامت مجموعة KH حفل وضع حجر الأساس المرموق لمشروعها المنتظر على الساحل الشمالي. جمع الحدث مسؤولين حكوميين وقادة صناعة وأصحاب مصلحة رئيسيين لتمييز بداية ما يعد بأن يكون مشروعًا بارزًا في الحياة الساحلية الفاخرة." },
  { id: 6, title: "KH Group Invests in Renewable Energy Infrastructure", titleAr: "مجموعة KH تستثمر في البنية التحتية للطاقة المتجددة", date: "2023-12-15", category: "Industrial", categoryAr: "الصناعة", excerpt: "New solar energy facilities installed across our industrial parks, reducing carbon footprint by 40% and supporting Egypt's green transition.", excerptAr: "تم تركيب مرافق جديدة للطاقة الشمسية عبر مجمعاتنا الصناعية، مما يقلل البصمة الكربونية بنسبة 40% ويدعم التحول الأخضر في مصر.", image: "https://images.unsplash.com/photo-1509391366360-2e959784a276?w=800", content: "KH Group has made a significant investment in renewable energy infrastructure, installing state-of-the-art solar energy facilities across its industrial parks. This initiative has reduced the company's overall carbon footprint by 40% and positions KH Group as a leader in Egypt's green energy transition.\n\nThe solar installations have a combined capacity of 50 megawatts, enough to power the majority of operations across three industrial complexes. In addition to solar panels, the company has implemented energy storage systems and smart grid technology to optimize energy distribution.\n\nThis investment aligns with Egypt's Vision 2030 and the country's commitment to increasing renewable energy's share of the national energy mix to 42% by 2035.", contentAr: "قامت مجموعة KH باستثمار كبير في البنية التحتية للطاقة المتجددة، حيث قامت بتركيب مرافق طاقة شمسية متطورة عبر مجمعاتها الصناعية. خفضت هذه المبادرة البصمة الكربونية الإجمالية للشركة بنسبة 40% وتضع مجموعة KH كرائدة في التحول إلى الطاقة الخضراء في مصر." },
  { id: 7, title: "KH Group Opens New Tech Innovation Center", titleAr: "مجموعة KH تفتتح مركز الابتكار التقني الجديد", date: "2024-02-10", category: "Company News", categoryAr: "أخبار الشركة", excerpt: "KH Group inaugurates a new Tech Innovation Center in New Cairo to drive digital transformation and develop smart city solutions.", excerptAr: "افتتحت مجموعة KH مركزًا جديدًا للابتكار التقني في القاهرة الجديدة لدعم التحول الرقمي وتطوير حلول المدن الذكية.", image: "https://images.unsplash.com/photo-1497366216548-37526070297c?w=800", content: "KH Group has inaugurated its state-of-the-art Tech Innovation Center in New Cairo, marking a significant milestone in the company's digital transformation journey.\n\nThe center will serve as a hub for developing smart city solutions, AI-powered building management systems, and IoT integration for residential and industrial projects. Equipped with the latest technology and staffed by a team of engineers and data scientists, the center aims to position KH Group at the forefront of PropTech innovation in the region.\n\n\"Technology is the backbone of modern development,\" said the company's Chief Technology Officer. \"This center will allow us to prototype, test, and deploy smart solutions that enhance the quality of life in our communities and improve operational efficiency across our industrial parks.\"", contentAr: "افتتحت مجموعة KH مركز الابتكار التقني المتطور في القاهرة الجديدة، مما يمثل علامة فارقة في رحلة التحول الرقمي للشركة.\n\nسيكون المركز محورًا لتطوير حلول المدن الذكية وأنظمة إدارة المباني المدعومة بالذكاء الاصطناعي ودمج إنترنت الأشياء للمشاريع السكنية والصناعية." },
  { id: 8, title: "AI Training Program Launched for Employees", titleAr: "إطلاق برنامج التدريب بالذكاء الاصطناعي للموظفين", date: "2024-02-20", category: "Company News", categoryAr: "أخبار الشركة", excerpt: "KH Group rolls out a comprehensive AI training program for all employees to boost efficiency and productivity across every department.", excerptAr: "أطلقت مجموعة KH برنامج تدريب شامل بالذكاء الاصطناعي لجميع الموظفين لتعزيز الكفاءة والإنتاجية عبر جميع الأقسام.", image: "https://images.unsplash.com/photo-1531482615713-2afd69097998?w=800", content: "KH Group has launched a comprehensive AI training program designed to equip all employees with the skills needed to leverage artificial intelligence in their daily work.\n\nThe program covers a wide range of topics from basic AI literacy to advanced applications specific to each department. Employees in architecture will learn to use AI-powered design tools, while those in finance will master predictive analytics and automated reporting.\n\nThe initiative includes partnerships with leading online learning platforms, hands-on workshops, and a structured roadmap that takes employees from beginner to advanced proficiency levels over 12 months.", contentAr: "أطلقت مجموعة KH برنامج تدريب شامل بالذكاء الاصطناعي مصمم لتزويد جميع الموظفين بالمهارات اللازمة للاستفادة من الذكاء الاصطناعي في عملهم اليومي.\n\nيغطي البرنامج مجموعة واسعة من الموضوعات من محو الأمية الأساسية في الذكاء الاصطناعي إلى التطبيقات المتقدمة الخاصة بكل قسم." },
  { id: 9, title: "Smart Greenhouse Project Expansion Announced", titleAr: "توسعة مشروع الصوب الزراعية الذكية", date: "2024-03-05", category: "Agriculture", categoryAr: "الزراعة", excerpt: "KH Group announces a 5,000-acre expansion of its Smart Greenhouse project using precision farming and drip irrigation technologies.", excerptAr: "تعلن مجموعة KH عن توسعة مشروع الصوب الزراعية الذكية بمساحة 5000 فدان إضافية باستخدام تقنيات الزراعة الدقيقة والري بالتنقيط.", image: "https://images.unsplash.com/photo-1530836369250-ef72a3f5cda8?w=800", content: "KH Group has announced a major expansion of its Smart Greenhouse project, adding 5,000 acres of advanced agricultural facilities equipped with precision farming and drip irrigation technologies.\n\nThe expansion will incorporate sensor-based monitoring, automated climate control, and data-driven crop management systems that have already demonstrated a 45% increase in yield in pilot facilities.\n\nThis project is part of KH Group's broader commitment to food security and sustainable agriculture in Egypt, supporting the national strategy to reduce food imports and promote self-sufficiency.", contentAr: "أعلنت مجموعة KH عن توسعة كبيرة لمشروع الصوب الزراعية الذكية، بإضافة 5000 فدان من المرافق الزراعية المتطورة المجهزة بتقنيات الزراعة الدقيقة والري بالتنقيط." },
  { id: 10, title: "KH Group Signs EGP 500M Green Financing Agreement", titleAr: "مجموعة KH توقع اتفاقية تمويل أخضر بقيمة 500 مليون جنيه", date: "2024-03-18", category: "Industrial", categoryAr: "الصناعة", excerpt: "KH Group secures a EGP 500 million green financing deal with Banque Misr to fund renewable energy and sustainable infrastructure projects.", excerptAr: "وقعت مجموعة KH اتفاقية تمويل أخضر مع بنك مصر لتمويل مشاريع الطاقة المتجددة والبنية التحتية المستدامة.", image: "https://images.unsplash.com/photo-1560472354-b33ff0c44a43?w=800", content: "KH Group has signed a landmark EGP 500 million green financing agreement with Banque Misr, one of Egypt's largest state-owned banks. The funds will be directed toward renewable energy installations, sustainable infrastructure development, and green building certifications across the company's portfolio.\n\nThis agreement underscores KH Group's commitment to environmental sustainability and positions the company as a pioneer in green financing within the Egyptian real estate and industrial sectors.\n\nThe financing will support the installation of solar farms, energy-efficient HVAC systems, and water treatment plants across multiple projects currently under development.", contentAr: "وقعت مجموعة KH اتفاقية تمويل أخضر بقيمة 500 مليون جنيه مع بنك مصر، أحد أكبر البنوك الحكومية في مصر. ستوجه الأموال نحو منشآت الطاقة المتجددة وتطوير البنية التحتية المستدامة وشهادات المباني الخضراء." },
  { id: 11, title: "Phase One Delivery of Beit Al Watan Project", titleAr: "تسليم المرحلة الأولى من مشروع بيت الوطن", date: "2024-04-01", category: "Real Estate", categoryAr: "العقارات", excerpt: "KH Group delivers Phase One of the Beit Al Watan project, comprising 800 fully finished luxury residential units.", excerptAr: "أعلنت مجموعة KH عن تسليم المرحلة الأولى من مشروع بيت الوطن والذي يضم 800 وحدة سكنية بتشطيبات فاخرة.", image: "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?w=800", content: "KH Group has successfully delivered Phase One of the prestigious Beit Al Watan project, comprising 800 fully finished luxury residential units. The handover ceremony was attended by government officials and homeowners who were welcomed into their new community.\n\nThe development features modern architectural design, premium finishes, and comprehensive amenities including swimming pools, fitness centers, children's play areas, and landscaped gardens. Smart home features come standard in every unit.\n\nPhase Two is already under construction and will add an additional 1,200 units along with a commercial district and community services center.", contentAr: "نجحت مجموعة KH في تسليم المرحلة الأولى من مشروع بيت الوطن المرموق، والذي يضم 800 وحدة سكنية فاخرة بتشطيبات كاملة. حضر حفل التسليم مسؤولون حكوميون وأصحاب منازل رحب بهم في مجتمعهم الجديد." },
];

const NewsDetail = () => {
  const { language } = useLanguage();
  const { id } = useParams();
  const navigate = useNavigate();

  const article = newsArticles.find((a) => a.id === Number(id));

  if (!article) {
    return (
      <div className="min-h-screen">
        <Navigation />
        <div className="pt-32 pb-20 text-center">
          <h1 className="text-3xl font-serif font-bold mb-4">
            {language === "ar" ? "المقال غير موجود" : "Article Not Found"}
          </h1>
          <Button onClick={() => navigate("/news")} className="bg-brand-green text-white hover:bg-brand-green-light">
            <ArrowLeft className="w-4 h-4 mr-2" />
            {language === "ar" ? "العودة للأخبار" : "Back to News"}
          </Button>
        </div>
        <Footer />
      </div>
    );
  }

  const formatDate = (dateString: string) =>
    new Date(dateString).toLocaleDateString(language === "ar" ? "ar-EG" : "en-US", { year: "numeric", month: "long", day: "numeric" });

  const title = language === "ar" ? article.titleAr : article.title;
  const category = language === "ar" ? article.categoryAr : article.category;
  const content = language === "ar" ? article.contentAr : article.content;

  return (
    <div className="min-h-screen">
      <Navigation />

      {/* Hero */}
      <section className="relative pt-24">
        <div className="h-[400px] md:h-[500px] w-full relative">
          <img src={article.image} alt={title} className="w-full h-full object-cover" />
          <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/40 to-transparent" />
          <div className="absolute bottom-0 left-0 right-0 p-8 md:p-16">
            <div className="container mx-auto max-w-4xl">
              <span className="inline-block bg-brand-green text-white px-4 py-1.5 rounded-full text-sm font-semibold mb-4">
                {category}
              </span>
              <h1 className="text-3xl md:text-5xl font-serif font-bold text-white mb-4 leading-tight">
                {title}
              </h1>
              <div className="flex items-center gap-2 text-white/70 text-sm">
                <Calendar className="w-4 h-4" />
                <span>{formatDate(article.date)}</span>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Content */}
      <section className="py-16 bg-background">
        <div className="container mx-auto px-4 max-w-4xl">
          <Button
            variant="ghost"
            onClick={() => navigate("/news")}
            className="mb-8 text-brand-green hover:text-brand-green-light hover:bg-brand-green/10"
          >
            <ArrowLeft className="w-4 h-4 mr-2" />
            {language === "ar" ? "العودة للأخبار" : "Back to News"}
          </Button>

          <div className="prose prose-lg max-w-none">
            {content.split("\n\n").map((paragraph, i) => (
              <p key={i} className="text-muted-foreground leading-relaxed mb-6 text-lg">
                {paragraph}
              </p>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default NewsDetail;
