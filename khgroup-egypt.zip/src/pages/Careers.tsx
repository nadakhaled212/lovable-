import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { Upload, Users, TrendingUp, Award, Heart } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import { useLanguage } from "@/contexts/LanguageContext";
import { Form, FormControl, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";

const careersSchema = z.object({
  fullName: z.string().trim().min(2, "Full name must be at least 2 characters").max(100),
  email: z.string().trim().email("Invalid email address").max(255),
  phone: z.string().trim().regex(/^\+?[0-9]{10,15}$/, "Phone must be 10-15 digits").max(20),
  position: z.string().trim().min(1, "Position is required").max(100),
  experience: z.string().trim().min(1, "Experience is required").max(50),
  coverLetter: z.string().trim().min(50, "Cover letter must be at least 50 characters").max(2000),
});

type CareersFormValues = z.infer<typeof careersSchema>;

const Careers = () => {
  const { toast } = useToast();
  const { t } = useLanguage();

  const form = useForm<CareersFormValues>({
    resolver: zodResolver(careersSchema),
    defaultValues: { fullName: "", email: "", phone: "", position: "", experience: "", coverLetter: "" },
  });

  const benefits = [
    { icon: TrendingUp, titleKey: "careers.benefit.growth.title", descKey: "careers.benefit.growth.desc" },
    { icon: Award, titleKey: "careers.benefit.competitive.title", descKey: "careers.benefit.competitive.desc" },
    { icon: Users, titleKey: "careers.benefit.team.title", descKey: "careers.benefit.team.desc" },
    { icon: Heart, titleKey: "careers.benefit.balance.title", descKey: "careers.benefit.balance.desc" },
  ];

  const onSubmit = (data: CareersFormValues) => {
    console.log("Form submitted:", data);
    toast({ title: t("careers.form.success.title"), description: t("careers.form.success.desc") });
    form.reset();
  };

  return (
    <div className="min-h-screen">
      <SEO title="Careers at KH Group | Join Our Team" description="Explore career opportunities at KH Group and join a leading Egyptian development company shaping real estate, industry, and agriculture." path="/careers" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">{t("careers.title")}</h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">{t("careers.subtitle")}</p>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">{t("careers.whyjoin.title")}</h2>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-6" />
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("careers.whyjoin.subtitle")}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {benefits.map((benefit, index) => (
              <Card key={index} className="bg-card border-border hover:border-brand-green transition-all duration-300 group">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-brand-green/10 flex items-center justify-center mx-auto mb-6 group-hover:bg-brand-green group-hover:scale-110 transition-all duration-300">
                    <benefit.icon className="w-8 h-8 text-brand-green group-hover:text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-4">{t(benefit.titleKey)}</h3>
                  <p className="text-muted-foreground leading-relaxed">{t(benefit.descKey)}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <section className="py-24 bg-muted">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-3xl mx-auto">
            <Card className="bg-card border-brand-green/30">
              <CardContent className="p-10">
                <div className="text-center mb-8">
                  <h2 className="text-3xl md:text-4xl font-serif font-bold mb-4">{t("careers.apply.title")}</h2>
                  <p className="text-muted-foreground">{t("careers.apply.subtitle")}</p>
                </div>
                <Form {...form}>
                  <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField control={form.control} name="fullName" render={({ field }) => (<FormItem><FormLabel>{t("careers.form.fullname")} *</FormLabel><FormControl><Input {...field} maxLength={100} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>)} />
                      <FormField control={form.control} name="email" render={({ field }) => (<FormItem><FormLabel>{t("careers.form.email")} *</FormLabel><FormControl><Input {...field} type="email" maxLength={255} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>)} />
                    </div>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      <FormField control={form.control} name="phone" render={({ field }) => (<FormItem><FormLabel>{t("careers.form.phone")} *</FormLabel><FormControl><Input {...field} type="tel" maxLength={20} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>)} />
                      <FormField control={form.control} name="position" render={({ field }) => (<FormItem><FormLabel>{t("careers.form.position")} *</FormLabel><FormControl><Input {...field} maxLength={100} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>)} />
                    </div>
                    <FormField control={form.control} name="experience" render={({ field }) => (<FormItem><FormLabel>{t("careers.form.experience")} *</FormLabel><FormControl><Input {...field} maxLength={50} className="bg-background border-border" /></FormControl><FormMessage /></FormItem>)} />
                    <FormField control={form.control} name="coverLetter" render={({ field }) => (<FormItem><FormLabel>{t("careers.form.coverletter")} *</FormLabel><FormControl><Textarea {...field} rows={6} maxLength={2000} className="bg-background border-border resize-none" /></FormControl><FormMessage /></FormItem>)} />
                    <div>
                      <label className="block text-sm font-medium mb-2">{t("careers.form.uploadcv")} *</label>
                      <div className="border-2 border-dashed border-border rounded-lg p-8 text-center hover:border-brand-green transition-colors cursor-pointer">
                        <Upload className="w-12 h-12 text-brand-green mx-auto mb-4" />
                        <p className="text-muted-foreground mb-2">{t("careers.form.uploadtext")}</p>
                        <p className="text-sm text-muted-foreground">{t("careers.form.uploadsubtext")}</p>
                      </div>
                    </div>
                    <Button type="submit" className="w-full bg-brand-green text-white hover:bg-brand-green-light text-lg py-6">
                      {t("careers.form.submit")}
                    </Button>
                  </form>
                </Form>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Careers;
