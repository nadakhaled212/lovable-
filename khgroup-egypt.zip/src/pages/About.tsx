import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { Eye, Target, Award, Users, TrendingUp, Shield } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useLanguage } from "@/contexts/LanguageContext";

const About = () => {
  const { t } = useLanguage();

  const values = [
    { icon: Award, title: t("about.value.excellence.title"), description: t("about.value.excellence.desc") },
    { icon: Shield, title: t("about.value.integrity.title"), description: t("about.value.integrity.desc") },
    { icon: TrendingUp, title: t("about.value.innovation.title"), description: t("about.value.innovation.desc") },
    { icon: Users, title: t("about.value.community.title"), description: t("about.value.community.desc") },
  ];

  return (
    <div className="min-h-screen">
      <SEO title="About KH Group | Egyptian Development Company" description="Learn about KH Group — an Egyptian real estate, industrial, and agricultural development company building sustainable communities and modern industrial complexes in 10th of Ramadan City." path="/about" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">{t("about.title")}</h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">{t("about.subtitle")}</p>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-5xl mx-auto">
            <h2 className="text-4xl font-serif font-bold mb-8 text-center">{t("about.whoweare.title")}</h2>
            <div className="space-y-6 text-lg text-muted-foreground leading-relaxed">
              <p>{t("about.whoweare.p1")}</p>
              <p>{t("about.whoweare.p2")}</p>
              <p>{t("about.whoweare.p3")}</p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-24 bg-muted">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 max-w-6xl mx-auto">
            <Card className="bg-card border-brand-green/30 hover:shadow-brand transition-all duration-300">
              <CardContent className="p-10">
                <div className="w-16 h-16 rounded-full bg-brand-green/10 flex items-center justify-center mb-8">
                  <Eye className="w-8 h-8 text-brand-green" />
                </div>
                <h3 className="text-3xl font-serif font-bold mb-6">{t("home.vision.title")}</h3>
                <p className="text-muted-foreground leading-relaxed text-lg">{t("about.vision.text")}</p>
              </CardContent>
            </Card>
            <Card className="bg-card border-brand-green/30 hover:shadow-brand transition-all duration-300">
              <CardContent className="p-10">
                <div className="w-16 h-16 rounded-full bg-brand-green/10 flex items-center justify-center mb-8">
                  <Target className="w-8 h-8 text-brand-green" />
                </div>
                <h3 className="text-3xl font-serif font-bold mb-6">{t("home.mission.title")}</h3>
                <p className="text-muted-foreground leading-relaxed text-lg">{t("about.mission.text")}</p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-4xl md:text-5xl font-serif font-bold mb-4">{t("about.values.title")}</h2>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-6" />
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">{t("about.values.subtitle")}</p>
          </div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {values.map((value, index) => (
              <Card key={index} className="bg-card border-border hover:border-brand-green transition-all duration-300 group">
                <CardContent className="p-8 text-center">
                  <div className="w-16 h-16 rounded-full bg-brand-green/10 flex items-center justify-center mx-auto mb-6 group-hover:bg-brand-green group-hover:scale-110 transition-all duration-300">
                    <value.icon className="w-8 h-8 text-brand-green group-hover:text-white" />
                  </div>
                  <h3 className="text-xl font-serif font-bold mb-4">{value.title}</h3>
                  <p className="text-muted-foreground leading-relaxed">{value.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default About;
