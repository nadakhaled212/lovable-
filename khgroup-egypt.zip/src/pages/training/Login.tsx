import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader } from "@/components/ui/card";
import { supabase } from "@/integrations/supabase/client";
import { useLanguage } from "@/contexts/LanguageContext";
import { Lock, User, Globe, UserPlus } from "lucide-react";
import khLogo from "@/assets/kh-logo.png";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import { useEffect } from "react";

const Login = () => {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [mode, setMode] = useState<"login" | "signup">("login");
  const [fullName, setFullName] = useState("");
  const { signIn, user, loading } = useTrainingAuthContext();
  const { language, setLanguage } = useLanguage();
  const navigate = useNavigate();

  const isAr = language === "ar";

  useEffect(() => {
    if (!loading && user) {
      navigate("/training/dashboard", { replace: true });
    }
  }, [user, loading, navigate]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);
    const { error: signInError } = await signIn(email, password);
    if (signInError) {
      setError(isAr ? "بيانات الدخول غير صحيحة" : "Invalid credentials. Please try again.");
    }
    setIsLoading(false);
  };

  const handleSignup = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setIsLoading(true);

    const { data, error: signUpError } = await supabase.auth.signUp({
      email,
      password,
    });

    if (signUpError) {
      setError(signUpError.message);
      setIsLoading(false);
      return;
    }

    // Auto-create employee profile
    if (data.user) {
      const empId = `EMP-${Date.now().toString(36).toUpperCase()}`;
      await supabase.rpc("create_employee_profile", {
        _user_id: data.user.id,
        _full_name: fullName || email.split("@")[0],
        _employee_id: empId,
      });
    }

    setIsLoading(false);
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-muted via-background to-muted p-4" dir={isAr ? "rtl" : "ltr"}>
      <Button
        variant="ghost"
        size="sm"
        className="absolute top-4 right-4"
        onClick={() => setLanguage(isAr ? "en" : "ar")}
      >
        <Globe className="w-4 h-4 mr-1" />
        {isAr ? "EN" : "AR"}
      </Button>

      <Card className="w-full max-w-md shadow-elegant border-0">
        <CardHeader className="text-center pb-2 pt-8">
          <img src={khLogo} alt="KH Group" className="h-16 w-auto mx-auto mb-4" />
          <h1 className="text-xl font-bold text-secondary">
            {isAr ? "بوابة تدريب KH Group" : "KH Group AI Training Portal"}
          </h1>
          <p className="text-sm text-muted-foreground mt-1">
            {mode === "login"
              ? (isAr ? "سجل الدخول للوصول إلى لوحة التدريب" : "Sign in to access your training dashboard")
              : (isAr ? "إنشاء حساب جديد" : "Create a new account")}
          </p>
        </CardHeader>
        <CardContent className="pt-4 pb-8 px-8">
          <form onSubmit={mode === "login" ? handleLogin : handleSignup} className="space-y-4">
            {mode === "signup" && (
              <div className="space-y-2">
                <label className="text-sm font-medium text-foreground">
                  {isAr ? "الاسم الكامل" : "Full Name"}
                </label>
                <div className="relative">
                  <UserPlus className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder={isAr ? "أدخل اسمك الكامل" : "Enter your full name"}
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            )}

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                {isAr ? "البريد الإلكتروني" : "Email"}
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="email"
                  placeholder={isAr ? "أدخل بريدك الإلكتروني" : "Enter your email"}
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="pl-10"
                  required
                />
              </div>
            </div>

            <div className="space-y-2">
              <label className="text-sm font-medium text-foreground">
                {isAr ? "كلمة المرور" : "Password"}
              </label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                <Input
                  type="password"
                  placeholder={isAr ? "أدخل كلمة المرور" : "Enter your password"}
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="pl-10"
                  required
                  minLength={6}
                />
              </div>
            </div>

            {error && (
              <p className="text-sm text-destructive text-center">{error}</p>
            )}

            <Button type="submit" className="w-full" disabled={isLoading}>
              {isLoading
                ? (isAr ? "جاري التحميل..." : "Loading...")
                : mode === "login"
                  ? (isAr ? "تسجيل الدخول" : "Sign In")
                  : (isAr ? "إنشاء حساب" : "Create Account")}
            </Button>
          </form>

          <div className="text-center mt-4">
            <button
              type="button"
              className="text-sm text-primary hover:underline"
              onClick={() => { setMode(mode === "login" ? "signup" : "login"); setError(""); }}
            >
              {mode === "login"
                ? (isAr ? "ليس لديك حساب؟ أنشئ حساباً" : "Don't have an account? Sign up")
                : (isAr ? "لديك حساب بالفعل؟ سجل الدخول" : "Already have an account? Sign in")}
            </button>
          </div>

          <p className="text-xs text-muted-foreground text-center mt-6">
            {isAr
              ? "هذه البوابة مخصصة لموظفي KH Group فقط"
              : "This portal is for KH Group employees only"}
          </p>
        </CardContent>
      </Card>
    </div>
  );
};

export default Login;
