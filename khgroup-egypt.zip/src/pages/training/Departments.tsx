import { useEffect, useState } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { Search, Building2 } from "lucide-react";

interface Department {
  id: string;
  name: string;
  name_ar: string | null;
  goals: string | null;
  goals_ar: string | null;
  recommended_tools: string[] | null;
  recommended_courses: string[] | null;
}

const Departments = () => {
  const { isAdmin, isManager } = useTrainingAuthContext();
  const { language } = useLanguage();
  const isAr = language === "ar";
  const [departments, setDepartments] = useState<Department[]>([]);
  const [search, setSearch] = useState("");
  const [filter, setFilter] = useState("all");

  useEffect(() => {
    const fetch = async () => {
      const { data } = await supabase.from("departments").select("*").order("name");
      setDepartments((data as Department[]) ?? []);
    };
    fetch();
  }, []);

  const filtered = departments.filter((d) => {
    const q = search.toLowerCase();
    const name = (isAr ? d.name_ar ?? d.name : d.name).toLowerCase();
    return name.includes(q);
  });

  return (
    <div dir={isAr ? "rtl" : "ltr"} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-secondary">
          {isAr ? "الأقسام" : "Departments"}
        </h1>
        <p className="text-muted-foreground mt-1">
          {isAr
            ? (isAdmin || isManager ? "عرض جميع الأقسام" : "قسمك المعين")
            : (isAdmin || isManager ? "View all departments" : "Your assigned department")}
        </p>
      </div>

      {/* Search */}
      <div className="relative max-w-md">
        <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
        <Input
          placeholder={isAr ? "بحث في الأقسام..." : "Search departments..."}
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="pl-10"
        />
      </div>

      {/* Department cards */}
      {filtered.length === 0 ? (
        <p className="text-muted-foreground">{isAr ? "لا توجد نتائج" : "No departments found."}</p>
      ) : (
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {filtered.map((dept) => (
            <Card key={dept.id} className="hover:shadow-md transition-shadow">
              <CardContent className="pt-6">
                <div className="flex items-start gap-3">
                  <div className="p-2 rounded-lg bg-primary/10">
                    <Building2 className="w-5 h-5 text-primary" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h3 className="font-semibold text-secondary">
                      {isAr ? dept.name_ar ?? dept.name : dept.name}
                    </h3>
                    <p className="text-sm text-muted-foreground mt-1 line-clamp-2">
                      {isAr ? dept.goals_ar ?? dept.goals : dept.goals}
                    </p>
                  </div>
                </div>

                {dept.recommended_tools && dept.recommended_tools.length > 0 && (
                  <div className="mt-4">
                    <p className="text-xs font-medium text-muted-foreground mb-1.5">
                      {isAr ? "الأدوات الموصى بها" : "Recommended Tools"}
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {dept.recommended_tools.map((tool) => (
                        <Badge key={tool} variant="outline" className="text-xs">
                          {tool}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}

                {dept.recommended_courses && dept.recommended_courses.length > 0 && (
                  <div className="mt-3">
                    <p className="text-xs font-medium text-muted-foreground mb-1.5">
                      {isAr ? "الدورات الموصى بها" : "Recommended Courses"}
                    </p>
                    <div className="flex flex-wrap gap-1.5">
                      {dept.recommended_courses.map((course) => (
                        <Badge key={course} variant="secondary" className="text-xs">
                          {course}
                        </Badge>
                      ))}
                    </div>
                  </div>
                )}
              </CardContent>
            </Card>
          ))}
        </div>
      )}
    </div>
  );
};

export default Departments;
