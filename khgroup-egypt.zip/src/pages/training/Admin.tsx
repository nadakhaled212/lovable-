import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsList, TabsTrigger, TabsContent } from "@/components/ui/tabs";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { UserPlus, Users, Shield, Search } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

interface Department {
  id: string;
  name: string;
  name_ar: string | null;
}

interface Employee {
  id: string;
  user_id: string;
  full_name: string;
  employee_id: string;
  department_id: string | null;
  job_role: string | null;
  roadmap_level: string;
}

interface Course {
  id: string;
  title: string;
  title_ar: string | null;
  level: string;
  department_id: string | null;
}

interface Tool {
  id: string;
  name: string;
  category: string | null;
}

const Admin = () => {
  const { isAdmin, user } = useTrainingAuthContext();
  const { language } = useLanguage();
  const { toast } = useToast();
  const isAr = language === "ar";

  const [departments, setDepartments] = useState<Department[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [courses, setCourses] = useState<Course[]>([]);
  const [tools, setTools] = useState<Tool[]>([]);
  const [search, setSearch] = useState("");

  // Add employee form
  const [newEmail, setNewEmail] = useState("");
  const [newPassword, setNewPassword] = useState("123456");
  const [newName, setNewName] = useState("");
  const [newEmpId, setNewEmpId] = useState("");
  const [newDept, setNewDept] = useState("");
  const [newRole, setNewRole] = useState("employee");
  const [newJobRole, setNewJobRole] = useState("");
  const [newLevel, setNewLevel] = useState("beginner");
  const [selectedCourses, setSelectedCourses] = useState<string[]>([]);
  const [selectedTools, setSelectedTools] = useState<string[]>([]);

  // Auto-select courses when department changes
  useEffect(() => {
    if (!newDept) return;
    const deptCourses = courses.filter((c: any) => c.department_id === newDept);
    if (deptCourses.length > 0) {
      setSelectedCourses(deptCourses.slice(0, 2).map((c) => c.id));
    }
    // Auto-select first tool
    if (tools.length > 0 && selectedTools.length === 0) {
      setSelectedTools([tools[0].id]);
    }
  }, [newDept, courses, tools]);
  const [isCreating, setIsCreating] = useState(false);

  // Role assignment
  const [roleUserId, setRoleUserId] = useState("");
  const [roleToAssign, setRoleToAssign] = useState("employee");

  useEffect(() => {
    fetchAll();
  }, []);

  const fetchAll = async () => {
    const [depts, emps, crs, tls] = await Promise.all([
      supabase.from("departments").select("id, name, name_ar").order("name"),
      supabase.from("employees").select("*").order("full_name"),
      supabase.from("courses").select("id, title, title_ar, level, department_id").order("title"),
      supabase.from("ai_tools").select("id, name, category").order("name"),
    ]);
    setDepartments((depts.data as Department[]) ?? []);
    setEmployees((emps.data as Employee[]) ?? []);
    setCourses((crs.data as Course[]) ?? []);
    setTools((tls.data as Tool[]) ?? []);
  };

  const handleCreateEmployee = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsCreating(true);

    try {
      // Call seed-admin edge function to create auth user + employee
      const { data, error } = await supabase.functions.invoke("seed-admin", {
        body: {
          email: newEmail,
          password: newPassword,
          full_name: newName,
          employee_id: newEmpId || `EMP-${Date.now().toString(36).toUpperCase()}`,
          role: newRole,
        },
      });

      if (error) throw error;

      const userId = data.user_id;

      // Update department and job role if set
      if (userId && (newDept || newJobRole || newLevel !== "beginner")) {
        await supabase
          .from("employees")
          .update({
            department_id: newDept || null,
            job_role: newJobRole || null,
            roadmap_level: newLevel,
          })
          .eq("user_id", userId);
      }

      // Assign courses
      if (userId && selectedCourses.length > 0) {
        const empRecord = await supabase.from("employees").select("id").eq("user_id", userId).maybeSingle();
        if (empRecord.data) {
          const courseInserts = selectedCourses.map((courseId) => ({
            employee_id: empRecord.data.id,
            course_id: courseId,
          }));
          await supabase.from("employee_courses").upsert(courseInserts, { onConflict: "employee_id,course_id" });
        }
      }

      // Assign tools
      if (userId && selectedTools.length > 0) {
        const empRecord = await supabase.from("employees").select("id").eq("user_id", userId).maybeSingle();
        if (empRecord.data) {
          const toolInserts = selectedTools.map((toolId) => ({
            employee_id: empRecord.data.id,
            tool_id: toolId,
          }));
          await supabase.from("employee_tools").upsert(toolInserts, { onConflict: "employee_id,tool_id" });
        }
      }

      toast({
        title: isAr ? "تم إنشاء الموظف" : "Employee Created",
        description: isAr ? `تم إنشاء حساب ${newName}` : `Account for ${newName} has been created.`,
      });

      // Reset form
      setNewEmail("");
      setNewPassword("123456");
      setNewName("");
      setNewEmpId("");
      setNewDept("");
      setNewRole("employee");
      setNewJobRole("");
      setNewLevel("beginner");
      setSelectedCourses([]);
      setSelectedTools([]);
      fetchAll();
    } catch (err: any) {
      toast({
        title: isAr ? "خطأ" : "Error",
        description: err.message || "Failed to create employee",
        variant: "destructive",
      });
    }

    setIsCreating(false);
  };

  const handleAssignRole = async () => {
    if (!roleUserId) return;
    try {
      const { error } = await supabase.rpc("assign_user_role", {
        _target_user_id: roleUserId,
        _role: roleToAssign as "admin" | "manager" | "employee",
      });
      if (error) throw error;
      toast({
        title: isAr ? "تم تعيين الدور" : "Role Assigned",
        description: `${roleToAssign} role assigned successfully.`,
      });
    } catch (err: any) {
      toast({
        title: isAr ? "خطأ" : "Error",
        description: err.message,
        variant: "destructive",
      });
    }
  };

  const filteredEmployees = employees.filter((e) =>
    e.full_name.toLowerCase().includes(search.toLowerCase()) ||
    e.employee_id.toLowerCase().includes(search.toLowerCase())
  );

  if (!isAdmin) {
    return (
      <div className="flex items-center justify-center min-h-[50vh]">
        <Card className="max-w-md">
          <CardContent className="pt-6 text-center">
            <Shield className="w-12 h-12 text-muted-foreground mx-auto mb-4" />
            <h2 className="text-lg font-semibold text-secondary">
              {isAr ? "الوصول مقيد" : "Access Restricted"}
            </h2>
            <p className="text-sm text-muted-foreground mt-2">
              {isAr ? "هذه الصفحة متاحة للمسؤولين فقط" : "This page is only available to admins."}
            </p>
          </CardContent>
        </Card>
      </div>
    );
  }

  return (
    <div dir={isAr ? "rtl" : "ltr"} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-secondary">
          {isAr ? "لوحة الإدارة" : "Admin Panel"}
        </h1>
        <p className="text-muted-foreground mt-1">
          {isAr ? "إدارة الموظفين والأدوار والدورات" : "Manage employees, roles, and courses"}
        </p>
      </div>

      <Tabs defaultValue="add">
        <TabsList>
          <TabsTrigger value="add">
            <UserPlus className="w-4 h-4 mr-1.5" />
            {isAr ? "إضافة موظف" : "Add Employee"}
          </TabsTrigger>
          <TabsTrigger value="employees">
            <Users className="w-4 h-4 mr-1.5" />
            {isAr ? "الموظفون" : "Employees"}
          </TabsTrigger>
          <TabsTrigger value="roles">
            <Shield className="w-4 h-4 mr-1.5" />
            {isAr ? "الأدوار" : "Roles"}
          </TabsTrigger>
        </TabsList>

        {/* Add Employee Tab */}
        <TabsContent value="add">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{isAr ? "إنشاء موظف جديد" : "Create New Employee"}</CardTitle>
            </CardHeader>
            <CardContent>
              <form onSubmit={handleCreateEmployee} className="space-y-4 max-w-2xl">
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "الاسم الكامل" : "Full Name"} *</label>
                    <Input value={newName} onChange={(e) => setNewName(e.target.value)} required placeholder="Ahmed Ali" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "البريد الإلكتروني" : "Email"} *</label>
                    <Input type="email" value={newEmail} onChange={(e) => setNewEmail(e.target.value)} required placeholder="ahmed@khgroup.com" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "كلمة المرور" : "Password"}</label>
                    <Input value={newPassword} onChange={(e) => setNewPassword(e.target.value)} placeholder="123456" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "رقم الموظف" : "Employee ID"}</label>
                    <Input value={newEmpId} onChange={(e) => setNewEmpId(e.target.value)} placeholder="EMP-001" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "القسم" : "Department"}</label>
                    <Select value={newDept} onValueChange={setNewDept}>
                      <SelectTrigger><SelectValue placeholder={isAr ? "اختر القسم" : "Select department"} /></SelectTrigger>
                      <SelectContent>
                        {departments.map((d) => (
                          <SelectItem key={d.id} value={d.id}>
                            {isAr ? d.name_ar ?? d.name : d.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "الدور" : "Role"}</label>
                    <Select value={newRole} onValueChange={setNewRole}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="employee">{isAr ? "موظف" : "Employee"}</SelectItem>
                        <SelectItem value="manager">{isAr ? "مدير" : "Manager"}</SelectItem>
                        <SelectItem value="admin">{isAr ? "مسؤول" : "Admin"}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "المسمى الوظيفي" : "Job Role"}</label>
                    <Input value={newJobRole} onChange={(e) => setNewJobRole(e.target.value)} placeholder="Software Engineer" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-medium">{isAr ? "مستوى خارطة الطريق" : "Roadmap Level"}</label>
                    <Select value={newLevel} onValueChange={setNewLevel}>
                      <SelectTrigger><SelectValue /></SelectTrigger>
                      <SelectContent>
                        <SelectItem value="beginner">{isAr ? "مبتدئ" : "Beginner"}</SelectItem>
                        <SelectItem value="intermediate">{isAr ? "متوسط" : "Intermediate"}</SelectItem>
                        <SelectItem value="advanced">{isAr ? "متقدم" : "Advanced"}</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                {/* Course selection */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">{isAr ? "الدورات المعينة" : "Assigned Courses"}</label>
                  <div className="flex flex-wrap gap-2 p-3 border rounded-lg bg-muted/30 max-h-40 overflow-y-auto">
                    {courses.map((c) => (
                      <button
                        type="button"
                        key={c.id}
                        onClick={() =>
                          setSelectedCourses((prev) =>
                            prev.includes(c.id) ? prev.filter((x) => x !== c.id) : [...prev, c.id]
                          )
                        }
                        className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${
                          selectedCourses.includes(c.id)
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-card text-foreground border-border hover:border-primary"
                        }`}
                      >
                        {isAr ? c.title_ar ?? c.title : c.title}
                      </button>
                    ))}
                  </div>
                </div>

                {/* Tool selection */}
                <div className="space-y-2">
                  <label className="text-sm font-medium">{isAr ? "الأدوات المعينة" : "Assigned Tools"}</label>
                  <div className="flex flex-wrap gap-2 p-3 border rounded-lg bg-muted/30 max-h-40 overflow-y-auto">
                    {tools.map((t) => (
                      <button
                        type="button"
                        key={t.id}
                        onClick={() =>
                          setSelectedTools((prev) =>
                            prev.includes(t.id) ? prev.filter((x) => x !== t.id) : [...prev, t.id]
                          )
                        }
                        className={`text-xs px-2.5 py-1 rounded-full border transition-colors ${
                          selectedTools.includes(t.id)
                            ? "bg-primary text-primary-foreground border-primary"
                            : "bg-card text-foreground border-border hover:border-primary"
                        }`}
                      >
                        {t.name}
                      </button>
                    ))}
                  </div>
                </div>

                <Button type="submit" disabled={isCreating}>
                  <UserPlus className="w-4 h-4 mr-1.5" />
                  {isCreating
                    ? (isAr ? "جاري الإنشاء..." : "Creating...")
                    : (isAr ? "إنشاء الموظف" : "Create Employee")}
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Employees list Tab */}
        <TabsContent value="employees">
          <Card>
            <CardHeader>
              <div className="flex items-center justify-between">
                <CardTitle className="text-lg">{isAr ? "قائمة الموظفين" : "Employee List"}</CardTitle>
                <div className="relative w-64">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
                  <Input
                    placeholder={isAr ? "بحث..." : "Search..."}
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="pl-10"
                  />
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {filteredEmployees.length === 0 ? (
                <p className="text-sm text-muted-foreground">{isAr ? "لا يوجد موظفون" : "No employees found."}</p>
              ) : (
                <div className="space-y-2">
                  {filteredEmployees.map((emp) => {
                    const dept = departments.find((d) => d.id === emp.department_id);
                    return (
                      <div key={emp.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                        <div>
                          <p className="font-medium text-secondary">{emp.full_name}</p>
                          <p className="text-xs text-muted-foreground">
                            {emp.employee_id} · {isAr ? dept?.name_ar ?? dept?.name ?? "—" : dept?.name ?? "—"}
                          </p>
                        </div>
                        <div className="flex items-center gap-2">
                          <Badge variant="outline" className="text-xs">{emp.roadmap_level}</Badge>
                          <Badge variant="secondary" className="text-xs">{emp.job_role ?? "—"}</Badge>
                        </div>
                      </div>
                    );
                  })}
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Roles Tab */}
        <TabsContent value="roles">
          <Card>
            <CardHeader>
              <CardTitle className="text-lg">{isAr ? "تعيين الأدوار" : "Assign Roles"}</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="max-w-md space-y-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">{isAr ? "الموظف" : "Employee"}</label>
                  <Select value={roleUserId} onValueChange={setRoleUserId}>
                    <SelectTrigger><SelectValue placeholder={isAr ? "اختر الموظف" : "Select employee"} /></SelectTrigger>
                    <SelectContent>
                      {employees.map((e) => (
                        <SelectItem key={e.id} value={e.user_id}>
                          {e.full_name} ({e.employee_id})
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-medium">{isAr ? "الدور" : "Role"}</label>
                  <Select value={roleToAssign} onValueChange={setRoleToAssign}>
                    <SelectTrigger><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="employee">{isAr ? "موظف" : "Employee"}</SelectItem>
                      <SelectItem value="manager">{isAr ? "مدير" : "Manager"}</SelectItem>
                      <SelectItem value="admin">{isAr ? "مسؤول" : "Admin"}</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button onClick={handleAssignRole}>
                  <Shield className="w-4 h-4 mr-1.5" />
                  {isAr ? "تعيين الدور" : "Assign Role"}
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Admin;
