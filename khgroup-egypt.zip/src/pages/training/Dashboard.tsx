import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { BookOpen, Wrench, TrendingUp, Building2 } from "lucide-react";

interface CourseAssignment {
  id: string;
  status: string;
  progress: number;
  course: { title: string; title_ar: string | null; level: string; duration: string | null };
}

interface ToolAssignment {
  id: string;
  tool: { name: string; description: string | null; description_ar: string | null; category: string | null; icon_name: string | null };
}

const statusColor: Record<string, string> = {
  not_started: "bg-muted text-muted-foreground",
  in_progress: "bg-yellow-100 text-yellow-800",
  completed: "bg-green-100 text-green-800",
};

const statusLabel = (s: string, isAr: boolean) => {
  const map: Record<string, [string, string]> = {
    not_started: ["Not Started", "لم يبدأ"],
    in_progress: ["In Progress", "قيد التنفيذ"],
    completed: ["Completed", "مكتمل"],
  };
  return (map[s] ?? [s, s])[isAr ? 1 : 0];
};

const levelLabel = (l: string, isAr: boolean) => {
  const map: Record<string, [string, string]> = {
    beginner: ["Beginner", "مبتدئ"],
    intermediate: ["Intermediate", "متوسط"],
    advanced: ["Advanced", "متقدم"],
  };
  return (map[l] ?? [l, l])[isAr ? 1 : 0];
};

const Dashboard = () => {
  const { profile, department } = useTrainingAuthContext();
  const { language } = useLanguage();
  const isAr = language === "ar";
  const [courses, setCourses] = useState<CourseAssignment[]>([]);
  const [tools, setTools] = useState<ToolAssignment[]>([]);

  useEffect(() => {
    if (!profile) return;

    const fetchData = async () => {
      const { data: ec } = await supabase
        .from("employee_courses")
        .select("id, status, progress, course:courses(title, title_ar, level, duration)")
        .eq("employee_id", profile.id);
      setCourses((ec as any) ?? []);

      const { data: et } = await supabase
        .from("employee_tools")
        .select("id, tool:ai_tools(name, description, description_ar, category, icon_name)")
        .eq("employee_id", profile.id);
      setTools((et as any) ?? []);
    };
    fetchData();
  }, [profile]);

  if (!profile) return null;

  const completedCount = courses.filter((c) => c.status === "completed").length;
  const totalProgress = courses.length
    ? Math.round(courses.reduce((sum, c) => sum + c.progress, 0) / courses.length)
    : 0;

  return (
    <div dir={isAr ? "rtl" : "ltr"} className="space-y-6">
      {/* Welcome */}
      <div>
        <h1 className="text-2xl font-bold text-secondary">
          {isAr ? `مرحباً، ${profile.full_name}` : `Welcome, ${profile.full_name}`}
        </h1>
        <p className="text-muted-foreground mt-1">
          {isAr ? "لوحة التدريب الخاصة بك" : "Your personal training dashboard"}
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <Building2 className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{isAr ? "القسم" : "Department"}</p>
              <p className="font-semibold text-secondary">
                {isAr ? department?.name_ar ?? department?.name : department?.name ?? "—"}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <TrendingUp className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{isAr ? "المستوى" : "Level"}</p>
              <p className="font-semibold text-secondary">{levelLabel(profile.roadmap_level, isAr)}</p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <BookOpen className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{isAr ? "الدورات" : "Courses"}</p>
              <p className="font-semibold text-secondary">
                {completedCount}/{courses.length} {isAr ? "مكتمل" : "completed"}
              </p>
            </div>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 flex items-center gap-4">
            <div className="p-3 rounded-lg bg-primary/10">
              <Wrench className="w-5 h-5 text-primary" />
            </div>
            <div>
              <p className="text-sm text-muted-foreground">{isAr ? "الأدوات" : "AI Tools"}</p>
              <p className="font-semibold text-secondary">{tools.length}</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Overall progress */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{isAr ? "التقدم العام" : "Overall Progress"}</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="flex items-center gap-4">
            <Progress value={totalProgress} className="flex-1 h-3" />
            <span className="text-sm font-semibold text-secondary">{totalProgress}%</span>
          </div>
        </CardContent>
      </Card>

      {/* Courses */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{isAr ? "الدورات المعينة" : "Assigned Courses"}</CardTitle>
        </CardHeader>
        <CardContent>
          {courses.length === 0 ? (
            <p className="text-sm text-muted-foreground">{isAr ? "لا توجد دورات معينة" : "No courses assigned yet."}</p>
          ) : (
            <div className="space-y-3">
              {courses.map((c) => (
                <div key={c.id} className="flex items-center justify-between p-3 rounded-lg bg-muted/50">
                  <div className="flex-1">
                    <p className="font-medium text-secondary">
                      {isAr ? c.course?.title_ar ?? c.course?.title : c.course?.title}
                    </p>
                    <div className="flex items-center gap-2 mt-1">
                      <Badge variant="outline" className="text-xs">
                        {levelLabel(c.course?.level ?? "beginner", isAr)}
                      </Badge>
                      {c.course?.duration && (
                        <span className="text-xs text-muted-foreground">{c.course.duration}</span>
                      )}
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    <Progress value={c.progress} className="w-24 h-2" />
                    <Badge className={`text-xs ${statusColor[c.status]}`}>
                      {statusLabel(c.status, isAr)}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Tools */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{isAr ? "أدوات الذكاء الاصطناعي المعينة" : "Assigned AI Tools"}</CardTitle>
        </CardHeader>
        <CardContent>
          {tools.length === 0 ? (
            <p className="text-sm text-muted-foreground">{isAr ? "لا توجد أدوات معينة" : "No tools assigned yet."}</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
              {tools.map((t) => (
                <div key={t.id} className="p-4 rounded-lg border bg-card">
                  <p className="font-medium text-secondary">{t.tool?.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {isAr ? t.tool?.description_ar ?? t.tool?.description : t.tool?.description}
                  </p>
                  {t.tool?.category && (
                    <Badge variant="outline" className="mt-2 text-xs">{t.tool.category}</Badge>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;
