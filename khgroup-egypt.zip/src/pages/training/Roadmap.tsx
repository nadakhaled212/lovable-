import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { CheckCircle2, Circle, ArrowRight } from "lucide-react";

interface Phase {
  id: string;
  level: string;
  title: string;
  title_ar: string | null;
  description: string | null;
  description_ar: string | null;
  required_tools: string[] | null;
  required_courses: string[] | null;
  expected_outcomes: string[] | null;
  expected_outcomes_ar: string[] | null;
  sort_order: number;
}

const levelColors: Record<string, string> = {
  beginner: "bg-green-100 text-green-800 border-green-200",
  intermediate: "bg-blue-100 text-blue-800 border-blue-200",
  advanced: "bg-purple-100 text-purple-800 border-purple-200",
};

const levelLabel = (l: string, isAr: boolean) => {
  const map: Record<string, [string, string]> = {
    beginner: ["Beginner", "مبتدئ"],
    intermediate: ["Intermediate", "متوسط"],
    advanced: ["Advanced", "متقدم"],
  };
  return (map[l] ?? [l, l])[isAr ? 1 : 0];
};

const Roadmap = () => {
  const { profile, department } = useTrainingAuthContext();
  const { language } = useLanguage();
  const isAr = language === "ar";
  const [phases, setPhases] = useState<Phase[]>([]);

  useEffect(() => {
    if (!profile?.department_id) return;
    const fetch = async () => {
      const { data } = await supabase
        .from("roadmap_phases")
        .select("*")
        .eq("department_id", profile.department_id!)
        .order("sort_order");
      setPhases((data as Phase[]) ?? []);
    };
    fetch();
  }, [profile?.department_id]);

  const currentLevelOrder = { beginner: 0, intermediate: 1, advanced: 2 };
  const currentIdx = currentLevelOrder[profile?.roadmap_level as keyof typeof currentLevelOrder] ?? 0;

  return (
    <div dir={isAr ? "rtl" : "ltr"} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-secondary">
          {isAr ? "خارطة طريق التعلم" : "Learning Roadmap"}
        </h1>
        <p className="text-muted-foreground mt-1">
          {isAr
            ? `خارطة الطريق لقسم ${department?.name_ar ?? department?.name ?? ""}`
            : `Roadmap for ${department?.name ?? ""} department`}
        </p>
      </div>

      {/* Current level indicator */}
      {profile && (
        <div className="flex items-center gap-2">
          <span className="text-sm text-muted-foreground">
            {isAr ? "مستواك الحالي:" : "Your current level:"}
          </span>
          <Badge className={levelColors[profile.roadmap_level]}>
            {levelLabel(profile.roadmap_level, isAr)}
          </Badge>
        </div>
      )}

      {phases.length === 0 ? (
        <p className="text-muted-foreground">{isAr ? "لا توجد خارطة طريق بعد" : "No roadmap phases found."}</p>
      ) : (
        <div className="space-y-4">
          {phases.map((phase, idx) => {
            const phaseIdx = currentLevelOrder[phase.level as keyof typeof currentLevelOrder] ?? 0;
            const isDone = phaseIdx < currentIdx;
            const isCurrent = phaseIdx === currentIdx;

            return (
              <div key={phase.id} className="flex gap-4">
                {/* Timeline indicator */}
                <div className="flex flex-col items-center">
                  {isDone ? (
                    <CheckCircle2 className="w-6 h-6 text-primary flex-shrink-0" />
                  ) : isCurrent ? (
                    <div className="w-6 h-6 rounded-full border-2 border-primary bg-primary/20 flex-shrink-0" />
                  ) : (
                    <Circle className="w-6 h-6 text-muted-foreground flex-shrink-0" />
                  )}
                  {idx < phases.length - 1 && (
                    <div className={`w-0.5 flex-1 mt-1 ${isDone ? "bg-primary" : "bg-border"}`} />
                  )}
                </div>

                <Card className={`flex-1 ${isCurrent ? "border-primary shadow-md" : ""}`}>
                  <CardHeader className="pb-3">
                    <div className="flex items-center justify-between">
                      <CardTitle className="text-base">
                        {isAr ? phase.title_ar ?? phase.title : phase.title}
                      </CardTitle>
                      <Badge className={levelColors[phase.level]}>{levelLabel(phase.level, isAr)}</Badge>
                    </div>
                    <p className="text-sm text-muted-foreground">
                      {isAr ? phase.description_ar ?? phase.description : phase.description}
                    </p>
                  </CardHeader>
                  <CardContent className="space-y-3">
                    {phase.required_tools && phase.required_tools.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">
                          {isAr ? "الأدوات المطلوبة" : "Required Tools"}
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {phase.required_tools.map((t) => (
                            <Badge key={t} variant="outline" className="text-xs">{t}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {phase.required_courses && phase.required_courses.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">
                          {isAr ? "الدورات المطلوبة" : "Required Courses"}
                        </p>
                        <div className="flex flex-wrap gap-1.5">
                          {phase.required_courses.map((c) => (
                            <Badge key={c} variant="secondary" className="text-xs">{c}</Badge>
                          ))}
                        </div>
                      </div>
                    )}
                    {phase.expected_outcomes && phase.expected_outcomes.length > 0 && (
                      <div>
                        <p className="text-xs font-medium text-muted-foreground mb-1">
                          {isAr ? "النتائج المتوقعة" : "Expected Outcomes"}
                        </p>
                        <ul className="space-y-1">
                          {(isAr ? phase.expected_outcomes_ar ?? phase.expected_outcomes : phase.expected_outcomes).map((o, i) => (
                            <li key={i} className="flex items-start gap-2 text-sm text-foreground">
                              <ArrowRight className="w-3.5 h-3.5 mt-0.5 text-primary flex-shrink-0" />
                              {o}
                            </li>
                          ))}
                        </ul>
                      </div>
                    )}
                  </CardContent>
                </Card>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};

export default Roadmap;
