import { useEffect, useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Progress } from "@/components/ui/progress";
import { Input } from "@/components/ui/input";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useTrainingAuthContext } from "@/contexts/TrainingAuthContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { supabase } from "@/integrations/supabase/client";
import { Search, BookOpen, Wrench, Target } from "lucide-react";

interface CourseAssignment {
  id: string;
  status: string;
  progress: number;
  assigned_at: string;
  course: {
    title: string;
    title_ar: string | null;
    description: string | null;
    description_ar: string | null;
    level: string;
    duration: string | null;
    url: string | null;
  };
}

interface ToolAssignment {
  id: string;
  tool: {
    name: string;
    description: string | null;
    description_ar: string | null;
    category: string | null;
  };
}

const statusColor: Record<string, string> = {
  not_started: "bg-muted text-muted-foreground",
  in_progress: "bg-yellow-100 text-yellow-800",
  completed: "bg-green-100 text-green-800",
};

const statusLabel = (s: string, isAr: boolean) => {
  const map: Record<string, [string, string]> = {
    not_started: ["Not Started", "لم يبدأ"],
    in_progress: ["In Progress", "قيد التنفيذ"],
    completed: ["Completed", "مكتمل"],
  };
  return (map[s] ?? [s, s])[isAr ? 1 : 0];
};

const levelLabel = (l: string, isAr: boolean) => {
  const map: Record<string, [string, string]> = {
    beginner: ["Beginner", "مبتدئ"],
    intermediate: ["Intermediate", "متوسط"],
    advanced: ["Advanced", "متقدم"],
  };
  return (map[l] ?? [l, l])[isAr ? 1 : 0];
};

const Plan = () => {
  const { profile, department } = useTrainingAuthContext();
  const { language } = useLanguage();
  const isAr = language === "ar";
  const [courses, setCourses] = useState<CourseAssignment[]>([]);
  const [tools, setTools] = useState<ToolAssignment[]>([]);
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    if (!profile) return;
    const fetch = async () => {
      const { data: ec } = await supabase
        .from("employee_courses")
        .select("id, status, progress, assigned_at, course:courses(title, title_ar, description, description_ar, level, duration, url)")
        .eq("employee_id", profile.id);
      setCourses((ec as any) ?? []);

      const { data: et } = await supabase
        .from("employee_tools")
        .select("id, tool:ai_tools(name, description, description_ar, category)")
        .eq("employee_id", profile.id);
      setTools((et as any) ?? []);
    };
    fetch();
  }, [profile]);

  const filteredCourses = courses.filter((c) => {
    const q = search.toLowerCase();
    const title = (isAr ? c.course?.title_ar ?? c.course?.title : c.course?.title ?? "").toLowerCase();
    const matchesSearch = title.includes(q);
    const matchesStatus = statusFilter === "all" || c.status === statusFilter;
    return matchesSearch && matchesStatus;
  });

  const completedCount = courses.filter((c) => c.status === "completed").length;
  const inProgressCount = courses.filter((c) => c.status === "in_progress").length;

  return (
    <div dir={isAr ? "rtl" : "ltr"} className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-secondary">
          {isAr ? "خطة التدريب الكاملة" : "Full Training Plan"}
        </h1>
        <p className="text-muted-foreground mt-1">
          {isAr ? "خطتك التدريبية المفصلة والأدوات المعينة" : "Your detailed training plan and assigned tools"}
        </p>
      </div>

      {/* Summary */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <Card>
          <CardContent className="pt-6 text-center">
            <Target className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold text-secondary">{courses.length}</p>
            <p className="text-sm text-muted-foreground">{isAr ? "إجمالي الدورات" : "Total Courses"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <BookOpen className="w-6 h-6 text-yellow-600 mx-auto mb-2" />
            <p className="text-2xl font-bold text-secondary">{inProgressCount}</p>
            <p className="text-sm text-muted-foreground">{isAr ? "قيد التنفيذ" : "In Progress"}</p>
          </CardContent>
        </Card>
        <Card>
          <CardContent className="pt-6 text-center">
            <Wrench className="w-6 h-6 text-primary mx-auto mb-2" />
            <p className="text-2xl font-bold text-secondary">{tools.length}</p>
            <p className="text-sm text-muted-foreground">{isAr ? "أدوات معينة" : "Assigned Tools"}</p>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input
            placeholder={isAr ? "بحث في الدورات..." : "Search courses..."}
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
        <Tabs value={statusFilter} onValueChange={setStatusFilter}>
          <TabsList>
            <TabsTrigger value="all">{isAr ? "الكل" : "All"}</TabsTrigger>
            <TabsTrigger value="not_started">{isAr ? "لم يبدأ" : "Not Started"}</TabsTrigger>
            <TabsTrigger value="in_progress">{isAr ? "قيد التنفيذ" : "In Progress"}</TabsTrigger>
            <TabsTrigger value="completed">{isAr ? "مكتمل" : "Completed"}</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Courses detail */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{isAr ? "الدورات التدريبية" : "Training Courses"}</CardTitle>
        </CardHeader>
        <CardContent>
          {filteredCourses.length === 0 ? (
            <p className="text-sm text-muted-foreground">{isAr ? "لا توجد دورات" : "No courses found."}</p>
          ) : (
            <div className="space-y-4">
              {filteredCourses.map((c) => (
                <div key={c.id} className="p-4 rounded-lg border bg-card">
                  <div className="flex items-start justify-between gap-4">
                    <div className="flex-1">
                      <h4 className="font-semibold text-secondary">
                        {isAr ? c.course?.title_ar ?? c.course?.title : c.course?.title}
                      </h4>
                      <p className="text-sm text-muted-foreground mt-1">
                        {isAr ? c.course?.description_ar ?? c.course?.description : c.course?.description}
                      </p>
                      <div className="flex items-center gap-2 mt-2">
                        <Badge variant="outline" className="text-xs">
                          {levelLabel(c.course?.level ?? "beginner", isAr)}
                        </Badge>
                        {c.course?.duration && (
                          <span className="text-xs text-muted-foreground">⏱ {c.course.duration}</span>
                        )}
                      </div>
                    </div>
                    <Badge className={`text-xs flex-shrink-0 ${statusColor[c.status]}`}>
                      {statusLabel(c.status, isAr)}
                    </Badge>
                  </div>
                  <div className="flex items-center gap-3 mt-3">
                    <Progress value={c.progress} className="flex-1 h-2" />
                    <span className="text-xs font-medium text-muted-foreground">{c.progress}%</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Assigned tools */}
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">{isAr ? "الأدوات المعينة" : "Assigned AI Tools"}</CardTitle>
        </CardHeader>
        <CardContent>
          {tools.length === 0 ? (
            <p className="text-sm text-muted-foreground">{isAr ? "لا توجد أدوات" : "No tools assigned."}</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              {tools.map((t) => (
                <div key={t.id} className="p-4 rounded-lg border bg-card">
                  <p className="font-medium text-secondary">{t.tool?.name}</p>
                  <p className="text-xs text-muted-foreground mt-1">
                    {isAr ? t.tool?.description_ar ?? t.tool?.description : t.tool?.description}
                  </p>
                  {t.tool?.category && (
                    <Badge variant="outline" className="mt-2 text-xs">{t.tool.category}</Badge>
                  )}
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default Plan;
