import Navigation from "@/components/Navigation";
import SEO from "@/components/SEO";
import Footer from "@/components/Footer";
import { Factory, MapPin, Maximize2, ArrowRight } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useNavigate } from "react-router-dom";
import { useLanguage } from "@/contexts/LanguageContext";
import SectorVisionMission from "@/components/SectorVisionMission";

const Industrial = () => {
  const navigate = useNavigate();
  const { language, t } = useLanguage();

  const projects = [
    { id: 2, title: language === "ar" ? "مجمع ابداع 1 الصناعي" : "Ibdaa 1 Industrial Complex", location: language === "ar" ? "مدينة العاشر من رمضان" : "10th of Ramadan City", area: language === "ar" ? "120 هكتار" : "120 Hectares", status: language === "ar" ? "مكتمل" : "Completed", image: "https://images.unsplash.com/photo-1586528116311-ad8dd3c8310d?w=800", description: language === "ar" ? "مجمع صناعي متكامل تم الانتهاء من تنفيذه بأحدث المواصفات" : "A fully integrated industrial complex completed with the latest specifications" },
    { id: 5, title: language === "ar" ? "مجمع ابداع 2 الصناعي" : "Ibdaa 2 Industrial Complex", location: language === "ar" ? "مدينة العاشر من رمضان" : "10th of Ramadan City", area: language === "ar" ? "150 هكتار" : "150 Hectares", status: language === "ar" ? "تحت الإنشاء" : "Under Construction", image: "https://images.unsplash.com/photo-1565043589221-1a6fd9ae45c7?w=800", description: language === "ar" ? "مجمع صناعي حديث تحت التنفيذ بمواصفات عالمية" : "A modern industrial complex under construction with international specifications" },
    { id: 7, title: language === "ar" ? "مجمع ابداع 3 الصناعي" : "Ibdaa 3 Industrial Complex", location: language === "ar" ? "مدينة العاشر من رمضان" : "10th of Ramadan City", area: language === "ar" ? "180 هكتار" : "180 Hectares", status: language === "ar" ? "قيد التخطيط" : "Planning", image: "https://images.unsplash.com/photo-1581094794329-c8112a89af12?w=800", description: language === "ar" ? "مجمع صناعي قيد التخطيط ليكون أكبر المجمعات في المنطقة" : "An industrial complex being planned to be the largest in the region" },
  ];

  return (
    <div className="min-h-screen">
      <SEO title="Industrial Development | KH Group Egypt" description="KH Group delivers world-class industrial complexes in 10th of Ramadan City, supporting Egypt's economic growth with smart, sustainable manufacturing facilities." path="/industrial" />
      <Navigation />

      <section className="pt-32 pb-20 bg-secondary">
        <div className="container mx-auto px-4 lg:px-8">
          <div className="max-w-4xl mx-auto text-center animate-fade-in">
            <div className="w-20 h-20 rounded-full bg-brand-green/20 flex items-center justify-center mx-auto mb-6">
              <Factory className="w-10 h-10 text-brand-green" />
            </div>
            <h1 className="text-5xl md:text-6xl font-serif font-bold text-white mb-6">
              {language === "ar" ? "القطاع الصناعي" : "Industrial Sector"}
            </h1>
            <div className="w-24 h-1 bg-brand-green mx-auto mb-8" />
            <p className="text-xl text-white/70 leading-relaxed">
              {language === "ar" ? "بناء منشآت صناعية حديثة تدفع النمو الاقتصادي لمصر" : "Building state-of-the-art industrial facilities that drive Egypt's economic growth"}
            </p>
          </div>
        </div>
      </section>

      <SectorVisionMission
        vision={[
          { title: { en: "Independence", ar: "الاستقلالية" }, text: { en: "Achieving self-sufficiency through self-executed and self-operated production lines.", ar: "تحقيق الاكتفاء من خلال خطوط إنتاج ذاتية التنفيذ والتشغيل." } },
          { title: { en: "Sustainability", ar: "الاستدامة" }, text: { en: "Adopting the smart factory concept and clean, eco-friendly manufacturing.", ar: "تبني مفهوم المصنع الذكي (Smart Factory) والتصنيع النظيف الصديق للبيئة." } },
          { title: { en: "Standards", ar: "المعايير" }, text: { en: "High-quality industrial production that competes at global levels.", ar: "إنتاج صناعي عالي الجودة ينافس المستويات العالمية." } },
          { title: { en: "Empowerment", ar: "التمكين" }, text: { en: "Owning the technology and machinery used to ensure continuity of supply.", ar: "امتلاك التكنولوجيا والآلات المستخدمة لضمان استمرارية الإمداد." } },
          { title: { en: "Modernity", ar: "الحداثة" }, text: { en: "Integrating AI and automation across all production stages.", ar: "دمج تقنيات الذكاء الاصطناعي والأتمتة في كافة مراحل الإنتاج." } },
        ]}
        mission={[
          { text: { en: "Establishing advanced industrial foundations that support the national economy by delivering high-quality products manufactured with the latest technologies, with full commitment to environmental responsibility and reliance on our own capabilities.", ar: "إرساء قواعد صناعية متطورة تدعم الاقتصاد الوطني من خلال تقديم منتجات عالية الجودة تُصنع بأحدث وسائل التكنولوجيا، مع الالتزام التام بالمسؤولية البيئية والاعتماد على قدراتنا الذاتية." } },
        ]}
      />

      <section className="py-24 bg-background">
        <div className="container mx-auto px-4 lg:px-8">
          <h2 className="text-3xl md:text-4xl font-serif font-bold mb-12 text-center">
            {language === "ar" ? "مشاريعنا الصناعية" : "Our Industrial Projects"}
          </h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {projects.map((project, index) => (
              <Card key={project.id} className="bg-card border-border hover:border-brand-green transition-all duration-300 group overflow-hidden cursor-pointer hover:scale-[1.03] animate-scale-in" style={{ animationDelay: `${index * 100}ms` }} onClick={() => navigate(`/projects/${project.id}`)}>
                <div className="relative overflow-hidden h-64">
                  <img src={project.image} alt={project.title} className="w-full h-full object-cover group-hover:scale-110 transition-transform duration-500" />
                  <div className="absolute top-4 right-4 bg-brand-green text-white px-3 py-1 rounded-full text-sm font-semibold">{project.status}</div>
                </div>
                <CardContent className="p-6">
                  <h3 className="text-2xl font-serif font-bold mb-3 group-hover:text-brand-green transition-colors">{project.title}</h3>
                  <p className="text-muted-foreground mb-4 leading-relaxed">{project.description}</p>
                  <div className="space-y-2 text-sm mb-6">
                    <div className="flex items-center space-x-2 text-muted-foreground"><MapPin className="w-4 h-4 text-brand-green" /><span>{project.location}</span></div>
                    <div className="flex items-center space-x-2 text-muted-foreground"><Maximize2 className="w-4 h-4 text-brand-green" /><span>{project.area}</span></div>
                  </div>
                  <Button className="w-full bg-brand-green text-white hover:bg-brand-green-light">{t("projects.viewdetails")} <ArrowRight className="w-4 h-4 ml-2" /></Button>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
};

export default Industrial;
