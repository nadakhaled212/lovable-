import { createContext, useContext, useState, ReactNode } from "react";

type Language = "en" | "ar";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: string) => string;
}

const translations = {
  en: {
    // Navigation
    "nav.home": "Home",
    "nav.about": "About Us",
    "nav.projects": "Our Projects",
    "nav.news": "News",
    "nav.careers": "Careers",
    "nav.contact": "Contact Us",
    
    // Hero
    "hero.title": "Building Egypt's Future",
    "hero.subtitle": "Through Real Estate, Industry, and Agriculture",
    "hero.cta.projects": "Explore Our Projects",
    "hero.cta.about": "About KH Group",
    
    // Home
    "home.sectors.title": "Our Sectors",
    "home.sectors.subtitle": "Diversified expertise across multiple industries, united by a commitment to excellence",
    "home.sectors.explore": "Explore Projects",
    "home.realestate.title": "Real Estate",
    "home.realestate.desc": "Developing modern residential and commercial communities that redefine urban living in Egypt.",
    "home.industrial.title": "Industrial",
    "home.industrial.desc": "Building state-of-the-art industrial facilities that drive Egypt's economic growth.",
    "home.agriculture.title": "Agriculture",
    "home.agriculture.desc": "Implementing sustainable agricultural projects that ensure food security and sustainability.",
    "home.education.title": "Educational Development",
    "home.education.desc": "Building well-rounded individuals through an applied educational model uniting knowledge, skill, and character.",
    "home.stats.years": "Years of Excellence",
    "home.stats.projects": "Projects Delivered",
    "home.stats.families": "Happy Families",
    "home.stats.hectares": "Hectares Developed",
    "home.vision.title": "Our Vision",
    "home.vision.text": "To be the most trusted developer through fully integrated self-execution, adopting smart city solutions and sustainable green buildings, with the highest quality standards through ownership of the latest tools and global technologies.",
    "home.mission.title": "Our Mission",
    "home.mission.text": "Developing residential and industrial urban communities ahead of their time, grounded in engineering innovation and environmental sustainability, to deliver real added value to our clients through full control over the quality of every development element.",
    
    // About
    "about.title": "About KH Group",
    "about.subtitle": "A multidisciplinary developer shaping Egypt's future through real estate, industrial, and agricultural excellence",
    "about.whoweare.title": "Who We Are",
    "about.whoweare.p1": "KH Group stands as one of Egypt's premier development companies, with a distinguished portfolio spanning real estate, industrial facilities, and agricultural projects. Since our establishment, we have been committed to transforming Egypt's landscape through innovative, sustainable, and community-focused developments.",
    "about.whoweare.p2": "Our multidisciplinary approach allows us to create integrated solutions that address Egypt's evolving needs. From modern residential communities to state-of-the-art industrial complexes and advanced agricultural projects, we bring expertise, vision, and dedication to every venture.",
    "about.whoweare.p3": "With decades of combined experience, our team of professionals works tirelessly to deliver projects that exceed expectations while contributing to Egypt's economic growth and social development.",
    "about.vision.text": "To be the most trusted developer through fully integrated self-execution, adopting smart city solutions (Smart Solutions) and sustainable green buildings (Green Buildings), with the highest quality standards through ownership of the latest tools and global technologies.",
    "about.mission.text": "Developing residential and industrial urban communities ahead of their time, grounded in engineering innovation and environmental sustainability, to deliver real added value to our clients through full control over the quality of every development element.",
    "about.values.title": "Our Values",
    "about.values.subtitle": "The principles that guide everything we do",
    "about.value.excellence.title": "Excellence",
    "about.value.excellence.desc": "Committed to the highest standards in every project we undertake",
    "about.value.integrity.title": "Integrity",
    "about.value.integrity.desc": "Building trust through transparency and ethical business practices",
    "about.value.innovation.title": "Innovation",
    "about.value.innovation.desc": "Embracing new technologies and sustainable development solutions",
    "about.value.community.title": "Community",
    "about.value.community.desc": "Creating spaces where communities thrive and flourish",
    
    // Projects
    "projects.title": "Our Projects",
    "projects.subtitle": "Explore our diverse portfolio of developments shaping Egypt's future",
    "projects.filter.all": "All",
    "projects.filter.realestate": "Real Estate",
    "projects.filter.industrial": "Industrial",
    "projects.filter.agricultural": "Agricultural",
    "projects.viewdetails": "View Details",
    
    // News
    "news.title": "News & Media",
    "news.subtitle": "Stay updated with the latest developments, achievements, and announcements from KH Group",
    "news.featured": "Featured",
    "news.recentupdates": "Recent Updates",
    "news.readfull": "Read Full Article",
    "news.readmore": "Read More",
    
    // Careers
    "careers.title": "Join Our Team",
    "careers.subtitle": "Build your career with Egypt's leading multidisciplinary development company",
    "careers.whyjoin.title": "Why Join KH Group?",
    "careers.whyjoin.subtitle": "Be part of a team that's shaping Egypt's future",
    "careers.benefit.growth.title": "Career Growth",
    "careers.benefit.growth.desc": "Clear advancement paths and professional development opportunities",
    "careers.benefit.competitive.title": "Competitive Benefits",
    "careers.benefit.competitive.desc": "Industry-leading compensation and comprehensive benefits package",
    "careers.benefit.team.title": "Team Culture",
    "careers.benefit.team.desc": "Collaborative environment with passionate, talented professionals",
    "careers.benefit.balance.title": "Work-Life Balance",
    "careers.benefit.balance.desc": "Flexible arrangements and emphasis on employee wellbeing",
    "careers.apply.title": "Apply Now",
    "careers.apply.subtitle": "Fill out the form below to submit your application",
    "careers.form.fullname": "Full Name",
    "careers.form.email": "Email Address",
    "careers.form.phone": "Phone Number",
    "careers.form.position": "Position Applied For",
    "careers.form.experience": "Years of Experience",
    "careers.form.coverletter": "Cover Letter",
    "careers.form.uploadcv": "Upload CV",
    "careers.form.uploadtext": "Click to upload or drag and drop",
    "careers.form.uploadsubtext": "PDF, DOC, DOCX (Max 5MB)",
    "careers.form.submit": "Submit Application",
    "careers.form.success.title": "Application Submitted!",
    "careers.form.success.desc": "Thank you for your interest in joining KH Group. We'll review your application and get back to you soon.",
    
    // Contact
    "contact.title": "Contact Us",
    "contact.subtitle": "Get in touch with our team to learn more about our projects and services",
    "contact.info.office": "Head Office",
    "contact.info.phone": "Phone",
    "contact.info.email": "Email",
    "contact.info.hours": "Working Hours",
    "contact.info.hours.weekdays": "Sunday - Thursday: 9:00 AM - 5:00 PM",
    "contact.info.hours.weekend": "Friday - Saturday: Closed",
    "contact.form.title": "Send Us a Message",
    "contact.form.name": "Full Name",
    "contact.form.email": "Email",
    "contact.form.phone": "Phone",
    "contact.form.subject": "Subject",
    "contact.form.message": "Message",
    "contact.form.send": "Send Message",
    "contact.form.success.title": "Message Sent!",
    "contact.form.success.desc": "Thank you for contacting KH Group. We'll get back to you within 24 hours.",
    
    // Footer
    "footer.description": "A leading real estate, industrial, and agricultural development company in Egypt, creating sustainable and innovative communities.",
    "footer.quicklinks": "Quick Links",
    "footer.contact": "Contact Us",
    "footer.follow": "Follow Us",
    "footer.rights": "All Rights Reserved.",
    "footer.privacy": "Privacy Policy",
    "footer.terms": "Terms of Service",
  },
  ar: {
    // Navigation
    "nav.home": "الرئيسية",
    "nav.about": "من نحن",
    "nav.projects": "مشاريعنا",
    "nav.news": "الأخبار",
    "nav.careers": "الوظائف",
    "nav.contact": "اتصل بنا",
    
    // Hero
    "hero.title": "بناء مستقبل مصر",
    "hero.subtitle": "من خلال العقارات والصناعة والزراعة",
    "hero.cta.projects": "استكشف مشاريعنا",
    "hero.cta.about": "عن مجموعة KH",
    
    // Home
    "home.sectors.title": "قطاعاتنا",
    "home.sectors.subtitle": "خبرة متنوعة عبر صناعات متعددة، متحدة بالتزام بالتميز",
    "home.sectors.explore": "استكشف المشاريع",
    "home.realestate.title": "العقارات",
    "home.realestate.desc": "تطوير مجتمعات سكنية وتجارية حديثة تعيد تعريف الحياة الحضرية في مصر.",
    "home.industrial.title": "الصناعة",
    "home.industrial.desc": "بناء منشآت صناعية حديثة تدفع النمو الاقتصادي لمصر.",
    "home.agriculture.title": "الزراعة",
    "home.agriculture.desc": "تنفيذ مشاريع زراعية مستدامة تضمن الأمن الغذائي والاستدامة.",
    "home.education.title": "التطوير التعليمي",
    "home.education.desc": "بناء الإنسان المتكامل من خلال نموذج تعليمي تطبيقي يجمع بين المعرفة والمهارة والشخصية.",
    "home.stats.years": "عاماً من التميز",
    "home.stats.projects": "مشروع منجز",
    "home.stats.families": "عائلة سعيدة",
    "home.stats.hectares": "هكتار مطور",
    "home.vision.title": "رؤيتنا",
    "home.vision.text": "أن نكون المطور الأكثر موثوقية من خلال التنفيذ الذاتي المتكامل، متبنين حلول المدن الذكية (Smart Solutions) والأبنية الخضراء المستدامة (Green Buildings) بأعلى معايير الجودة عبر امتلاكنا لأحدث الأدوات والتقنيات العالمية.",
    "home.mission.title": "مهمتنا",
    "home.mission.text": "تطوير مجتمعات عمرانية سكنية وصناعية تسبق عصرها، ترتكز على الابتكار الهندسي والاستدامة البيئية، لتقديم قيمة مضافة حقيقية لعملائنا من خلال السيطرة الكاملة على جودة جميع عناصر التطوير.",
    
    // About
    "about.title": "عن مجموعة KH",
    "about.subtitle": "مطور متعدد التخصصات يشكل مستقبل مصر من خلال التميز العقاري والصناعي والزراعي",
    "about.whoweare.title": "من نحن",
    "about.whoweare.p1": "تقف مجموعة KH كواحدة من الشركات الرائدة في التطوير في مصر، مع محفظة متميزة تشمل العقارات والمنشآت الصناعية والمشاريع الزراعية. منذ تأسيسنا، نلتزم بتحويل المشهد المصري من خلال تطويرات مبتكرة ومستدامة وموجهة نحو المجتمع.",
    "about.whoweare.p2": "يتيح لنا نهجنا متعدد التخصصات إنشاء حلول متكاملة تلبي احتياجات مصر المتطورة. من المجتمعات السكنية الحديثة إلى المجمعات الصناعية المتطورة والمشاريع الزراعية المتقدمة، نجلب الخبرة والرؤية والتفاني لكل مشروع.",
    "about.whoweare.p3": "بفضل عقود من الخبرة المشتركة، يعمل فريقنا من المحترفين بلا كلل لتقديم مشاريع تتجاوز التوقعات مع المساهمة في النمو الاقتصادي والتنمية الاجتماعية لمصر.",
    "about.vision.text": "أن نكون المطور الأكثر موثوقية من خلال التنفيذ الذاتي المتكامل، متبنين حلول المدن الذكية (Smart Solutions) والأبنية الخضراء المستدامة (Green Buildings) بأعلى معايير الجودة عبر امتلاكنا لأحدث الأدوات والتقنيات العالمية.",
    "about.mission.text": "تطوير مجتمعات عمرانية سكنية وصناعية تسبق عصرها، ترتكز على الابتكار الهندسي والاستدامة البيئية، لتقديم قيمة مضافة حقيقية لعملائنا من خلال السيطرة الكاملة على جودة جميع عناصر التطوير.",
    "about.values.title": "قيمنا",
    "about.values.subtitle": "المبادئ التي توجه كل ما نقوم به",
    "about.value.excellence.title": "التميز",
    "about.value.excellence.desc": "ملتزمون بأعلى المعايير في كل مشروع نقوم به",
    "about.value.integrity.title": "النزاهة",
    "about.value.integrity.desc": "بناء الثقة من خلال الشفافية والممارسات التجارية الأخلاقية",
    "about.value.innovation.title": "الابتكار",
    "about.value.innovation.desc": "احتضان التقنيات الجديدة وحلول التنمية المستدامة",
    "about.value.community.title": "المجتمع",
    "about.value.community.desc": "خلق مساحات حيث تزدهر المجتمعات وتنمو",
    
    // Projects
    "projects.title": "مشاريعنا",
    "projects.subtitle": "استكشف محفظتنا المتنوعة من التطويرات التي تشكل مستقبل مصر",
    "projects.filter.all": "الكل",
    "projects.filter.realestate": "العقارات",
    "projects.filter.industrial": "الصناعة",
    "projects.filter.agricultural": "الزراعة",
    "projects.viewdetails": "عرض التفاصيل",
    
    // News
    "news.title": "الأخبار والإعلام",
    "news.subtitle": "ابق على اطلاع بأحدث التطورات والإنجازات والإعلانات من مجموعة KH",
    "news.featured": "مميز",
    "news.recentupdates": "التحديثات الأخيرة",
    "news.readfull": "اقرأ المقال كاملاً",
    "news.readmore": "اقرأ المزيد",
    
    // Careers
    "careers.title": "انضم إلى فريقنا",
    "careers.subtitle": "ابنِ مسيرتك المهنية مع شركة التطوير الرائدة متعددة التخصصات في مصر",
    "careers.whyjoin.title": "لماذا تنضم إلى مجموعة KH؟",
    "careers.whyjoin.subtitle": "كن جزءًا من فريق يشكل مستقبل مصر",
    "careers.benefit.growth.title": "النمو الوظيفي",
    "careers.benefit.growth.desc": "مسارات واضحة للتقدم وفرص التطوير المهني",
    "careers.benefit.competitive.title": "مزايا تنافسية",
    "careers.benefit.competitive.desc": "تعويضات رائدة في الصناعة وحزمة مزايا شاملة",
    "careers.benefit.team.title": "ثقافة الفريق",
    "careers.benefit.team.desc": "بيئة تعاونية مع محترفين موهوبين ومتحمسين",
    "careers.benefit.balance.title": "التوازن بين العمل والحياة",
    "careers.benefit.balance.desc": "ترتيبات مرنة وتركيز على رفاهية الموظفين",
    "careers.apply.title": "قدم الآن",
    "careers.apply.subtitle": "املأ النموذج أدناه لتقديم طلبك",
    "careers.form.fullname": "الاسم الكامل",
    "careers.form.email": "البريد الإلكتروني",
    "careers.form.phone": "رقم الهاتف",
    "careers.form.position": "الوظيفة المتقدم لها",
    "careers.form.experience": "سنوات الخبرة",
    "careers.form.coverletter": "خطاب التقديم",
    "careers.form.uploadcv": "رفع السيرة الذاتية",
    "careers.form.uploadtext": "انقر للتحميل أو اسحب وأفلت",
    "careers.form.uploadsubtext": "PDF، DOC، DOCX (حد أقصى 5 ميجابايت)",
    "careers.form.submit": "إرسال الطلب",
    "careers.form.success.title": "تم إرسال الطلب!",
    "careers.form.success.desc": "شكرًا لاهتمامك بالانضمام إلى مجموعة KH. سنراجع طلبك ونعود إليك قريبًا.",
    
    // Contact
    "contact.title": "اتصل بنا",
    "contact.subtitle": "تواصل مع فريقنا لمعرفة المزيد عن مشاريعنا وخدماتنا",
    "contact.info.office": "المكتب الرئيسي",
    "contact.info.phone": "الهاتف",
    "contact.info.email": "البريد الإلكتروني",
    "contact.info.hours": "ساعات العمل",
    "contact.info.hours.weekdays": "الأحد - الخميس: 9:00 صباحًا - 5:00 مساءً",
    "contact.info.hours.weekend": "الجمعة - السبت: مغلق",
    "contact.form.title": "أرسل لنا رسالة",
    "contact.form.name": "الاسم الكامل",
    "contact.form.email": "البريد الإلكتروني",
    "contact.form.phone": "الهاتف",
    "contact.form.subject": "الموضوع",
    "contact.form.message": "الرسالة",
    "contact.form.send": "إرسال الرسالة",
    "contact.form.success.title": "تم إرسال الرسالة!",
    "contact.form.success.desc": "شكرًا لتواصلك مع مجموعة KH. سنعود إليك خلال 24 ساعة.",
    
    // Footer
    "footer.description": "شركة رائدة في تطوير العقارات والصناعة والزراعة في مصر، تخلق مجتمعات مستدامة ومبتكرة.",
    "footer.quicklinks": "روابط سريعة",
    "footer.contact": "اتصل بنا",
    "footer.follow": "تابعنا",
    "footer.rights": "جميع الحقوق محفوظة.",
    "footer.privacy": "سياسة الخصوصية",
    "footer.terms": "شروط الخدمة",
  },
};

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguage] = useState<Language>("en");

  const t = (key: string): string => {
    return translations[language][key as keyof typeof translations.en] || key;
  };

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t }}>
      <div dir={language === "ar" ? "rtl" : "ltr"} className={language === "ar" ? "font-arabic" : ""}>
        {children}
      </div>
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};
