import React, { createContext, useContext } from "react";
import { useTrainingAuth } from "@/hooks/useTrainingAuth";

type TrainingAuthContextType = ReturnType<typeof useTrainingAuth>;

const TrainingAuthContext = createContext<TrainingAuthContextType | null>(null);

export function TrainingAuthProvider({ children }: { children: React.ReactNode }) {
  const auth = useTrainingAuth();
  return (
    <TrainingAuthContext.Provider value={auth}>
      {children}
    </TrainingAuthContext.Provider>
  );
}

export function useTrainingAuthContext() {
  const ctx = useContext(TrainingAuthContext);
  if (!ctx) throw new Error("useTrainingAuthContext must be used within TrainingAuthProvider");
  return ctx;
}
