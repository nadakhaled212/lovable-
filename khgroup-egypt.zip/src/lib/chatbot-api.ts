import { supabase } from "@/integrations/supabase/client";

type ChatbotLanguage = "en" | "ar";

interface ChatbotResponse {
  reply?: string;
  error?: "WORKFLOW_INACTIVE" | "WEBHOOK_UNAVAILABLE" | "INVALID_RESPONSE";
}

const fallbackMessages: Record<ChatbotLanguage, { generic: string; inactive: string }> = {
  en: {
    generic: "Something went wrong, please try again",
    inactive:
      "The chatbot workflow is not active yet. Please activate the workflow in n8n or run the test webhook again.",
  },
  ar: {
    generic: "حدث خطأ ما، يرجى المحاولة مرة أخرى",
    inactive:
      "الـ chatbot غير مفعل حالياً. يرجى تفعيل الـ workflow في n8n أو تشغيل رابط الاختبار مرة أخرى.",
  },
};

export async function sendChatbotMessage(message: string, language: ChatbotLanguage) {
  const { data, error } = await supabase.functions.invoke<ChatbotResponse>("chatbot-webhook", {
    body: { message },
  });

  if (error) {
    return fallbackMessages[language].generic;
  }

  if (typeof data?.reply === "string" && data.reply.trim()) {
    return data.reply;
  }

  if (data?.error === "WORKFLOW_INACTIVE") {
    return fallbackMessages[language].inactive;
  }

  return fallbackMessages[language].generic;
}