export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      ai_tools: {
        Row: {
          category: string | null
          created_at: string
          description: string | null
          description_ar: string | null
          icon_name: string | null
          id: string
          name: string
        }
        Insert: {
          category?: string | null
          created_at?: string
          description?: string | null
          description_ar?: string | null
          icon_name?: string | null
          id?: string
          name: string
        }
        Update: {
          category?: string | null
          created_at?: string
          description?: string | null
          description_ar?: string | null
          icon_name?: string | null
          id?: string
          name?: string
        }
        Relationships: []
      }
      courses: {
        Row: {
          created_at: string
          department_id: string | null
          description: string | null
          description_ar: string | null
          duration: string | null
          id: string
          level: string
          title: string
          title_ar: string | null
          url: string | null
        }
        Insert: {
          created_at?: string
          department_id?: string | null
          description?: string | null
          description_ar?: string | null
          duration?: string | null
          id?: string
          level?: string
          title: string
          title_ar?: string | null
          url?: string | null
        }
        Update: {
          created_at?: string
          department_id?: string | null
          description?: string | null
          description_ar?: string | null
          duration?: string | null
          id?: string
          level?: string
          title?: string
          title_ar?: string | null
          url?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "courses_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      departments: {
        Row: {
          created_at: string
          goals: string | null
          goals_ar: string | null
          id: string
          name: string
          name_ar: string | null
          recommended_courses: string[] | null
          recommended_tools: string[] | null
          updated_at: string
        }
        Insert: {
          created_at?: string
          goals?: string | null
          goals_ar?: string | null
          id?: string
          name: string
          name_ar?: string | null
          recommended_courses?: string[] | null
          recommended_tools?: string[] | null
          updated_at?: string
        }
        Update: {
          created_at?: string
          goals?: string | null
          goals_ar?: string | null
          id?: string
          name?: string
          name_ar?: string | null
          recommended_courses?: string[] | null
          recommended_tools?: string[] | null
          updated_at?: string
        }
        Relationships: []
      }
      employee_courses: {
        Row: {
          assigned_at: string
          completed_at: string | null
          course_id: string
          employee_id: string
          id: string
          progress: number
          status: string
        }
        Insert: {
          assigned_at?: string
          completed_at?: string | null
          course_id: string
          employee_id: string
          id?: string
          progress?: number
          status?: string
        }
        Update: {
          assigned_at?: string
          completed_at?: string | null
          course_id?: string
          employee_id?: string
          id?: string
          progress?: number
          status?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_courses_course_id_fkey"
            columns: ["course_id"]
            isOneToOne: false
            referencedRelation: "courses"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_courses_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      employee_tools: {
        Row: {
          assigned_at: string
          employee_id: string
          id: string
          tool_id: string
        }
        Insert: {
          assigned_at?: string
          employee_id: string
          id?: string
          tool_id: string
        }
        Update: {
          assigned_at?: string
          employee_id?: string
          id?: string
          tool_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employee_tools_employee_id_fkey"
            columns: ["employee_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employee_tools_tool_id_fkey"
            columns: ["tool_id"]
            isOneToOne: false
            referencedRelation: "ai_tools"
            referencedColumns: ["id"]
          },
        ]
      }
      employees: {
        Row: {
          avatar_url: string | null
          created_at: string
          department_id: string | null
          employee_id: string
          full_name: string
          id: string
          job_role: string | null
          job_role_ar: string | null
          manager_id: string | null
          roadmap_level: string
          updated_at: string
          user_id: string
        }
        Insert: {
          avatar_url?: string | null
          created_at?: string
          department_id?: string | null
          employee_id: string
          full_name: string
          id?: string
          job_role?: string | null
          job_role_ar?: string | null
          manager_id?: string | null
          roadmap_level?: string
          updated_at?: string
          user_id: string
        }
        Update: {
          avatar_url?: string | null
          created_at?: string
          department_id?: string | null
          employee_id?: string
          full_name?: string
          id?: string
          job_role?: string | null
          job_role_ar?: string | null
          manager_id?: string | null
          roadmap_level?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "employees_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "employees_manager_id_fkey"
            columns: ["manager_id"]
            isOneToOne: false
            referencedRelation: "employees"
            referencedColumns: ["id"]
          },
        ]
      }
      roadmap_phases: {
        Row: {
          created_at: string
          department_id: string | null
          description: string | null
          description_ar: string | null
          expected_outcomes: string[] | null
          expected_outcomes_ar: string[] | null
          id: string
          level: string
          required_courses: string[] | null
          required_tools: string[] | null
          sort_order: number
          title: string
          title_ar: string | null
        }
        Insert: {
          created_at?: string
          department_id?: string | null
          description?: string | null
          description_ar?: string | null
          expected_outcomes?: string[] | null
          expected_outcomes_ar?: string[] | null
          id?: string
          level: string
          required_courses?: string[] | null
          required_tools?: string[] | null
          sort_order?: number
          title: string
          title_ar?: string | null
        }
        Update: {
          created_at?: string
          department_id?: string | null
          description?: string | null
          description_ar?: string | null
          expected_outcomes?: string[] | null
          expected_outcomes_ar?: string[] | null
          id?: string
          level?: string
          required_courses?: string[] | null
          required_tools?: string[] | null
          sort_order?: number
          title?: string
          title_ar?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "roadmap_phases_department_id_fkey"
            columns: ["department_id"]
            isOneToOne: false
            referencedRelation: "departments"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      admin_create_employee: {
        Args: {
          _department_id?: string
          _employee_id: string
          _full_name: string
          _job_role?: string
          _job_role_ar?: string
          _roadmap_level?: string
          _role?: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: string
      }
      assign_user_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _target_user_id: string
        }
        Returns: undefined
      }
      create_employee_profile: {
        Args: { _employee_id: string; _full_name: string; _user_id: string }
        Returns: string
      }
    }
    Enums: {
      app_role: "admin" | "manager" | "employee"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["admin", "manager", "employee"],
    },
  },
} as const
