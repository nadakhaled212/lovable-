
-- create_employee_profile: only the signed-in user can create their own profile
CREATE OR REPLACE FUNCTION public.create_employee_profile(
  _user_id UUID,
  _full_name TEXT,
  _employee_id TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _emp_id UUID;
BEGIN
  IF auth.uid() IS NULL OR auth.uid() <> _user_id THEN
    RAISE EXCEPTION 'Not authorized to create this profile';
  END IF;

  INSERT INTO public.employees (user_id, full_name, employee_id)
  VALUES (_user_id, _full_name, _employee_id)
  ON CONFLICT (user_id) DO NOTHING
  RETURNING id INTO _emp_id;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (_user_id, 'employee')
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN _emp_id;
END;
$$;

-- assign_user_role: rewire to private.has_role
CREATE OR REPLACE FUNCTION public.assign_user_role(
  _target_user_id UUID,
  _role public.app_role
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT private.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Only admins can assign roles';
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (_target_user_id, _role)
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;

-- admin_create_employee: rewire to private.has_role
CREATE OR REPLACE FUNCTION public.admin_create_employee(
  _user_id UUID,
  _full_name TEXT,
  _employee_id TEXT,
  _department_id UUID DEFAULT NULL,
  _job_role TEXT DEFAULT NULL,
  _job_role_ar TEXT DEFAULT NULL,
  _roadmap_level TEXT DEFAULT 'beginner',
  _role public.app_role DEFAULT 'employee'
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _emp_id UUID;
BEGIN
  IF NOT private.has_role(auth.uid(), 'admin'::public.app_role) THEN
    RAISE EXCEPTION 'Only admins can create employees';
  END IF;

  INSERT INTO public.employees (user_id, full_name, employee_id, department_id, job_role, job_role_ar, roadmap_level)
  VALUES (_user_id, _full_name, _employee_id, _department_id, _job_role, _job_role_ar, _roadmap_level)
  ON CONFLICT (user_id) DO UPDATE SET
    full_name = EXCLUDED.full_name,
    employee_id = EXCLUDED.employee_id,
    department_id = EXCLUDED.department_id,
    job_role = EXCLUDED.job_role,
    job_role_ar = EXCLUDED.job_role_ar,
    roadmap_level = EXCLUDED.roadmap_level
  RETURNING id INTO _emp_id;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (_user_id, _role)
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN _emp_id;
END;
$$;

-- Revoke anonymous access; only signed-in users may invoke these RPCs
REVOKE EXECUTE ON FUNCTION public.create_employee_profile(uuid, text, text) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.assign_user_role(uuid, public.app_role) FROM PUBLIC, anon;
REVOKE EXECUTE ON FUNCTION public.admin_create_employee(uuid, text, text, uuid, text, text, text, public.app_role) FROM PUBLIC, anon;

GRANT EXECUTE ON FUNCTION public.create_employee_profile(uuid, text, text) TO authenticated;
GRANT EXECUTE ON FUNCTION public.assign_user_role(uuid, public.app_role) TO authenticated;
GRANT EXECUTE ON FUNCTION public.admin_create_employee(uuid, text, text, uuid, text, text, text, public.app_role) TO authenticated;
