
-- 1) Move has_role into a private schema so it is not exposed via the API
CREATE SCHEMA IF NOT EXISTS private;

CREATE OR REPLACE FUNCTION private.has_role(_user_id uuid, _role public.app_role)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

REVOKE ALL ON FUNCTION private.has_role(uuid, public.app_role) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.has_role(uuid, public.app_role) TO authenticated, anon, service_role;

-- 2) Recreate all policies referencing public.has_role to use private.has_role
-- user_roles
DROP POLICY IF EXISTS "Admins can manage roles" ON public.user_roles;
CREATE POLICY "Admins can manage roles" ON public.user_roles
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

-- departments
DROP POLICY IF EXISTS "Admins manage departments" ON public.departments;
CREATE POLICY "Admins manage departments" ON public.departments
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Employees see own department" ON public.departments;
CREATE POLICY "Employees see own department" ON public.departments
  FOR SELECT TO authenticated
  USING (
    EXISTS (SELECT 1 FROM public.employees e WHERE e.user_id = auth.uid() AND e.department_id = departments.id)
    OR private.has_role(auth.uid(), 'admin'::public.app_role)
    OR private.has_role(auth.uid(), 'manager'::public.app_role)
  );

-- employees
DROP POLICY IF EXISTS "Admins manage employees" ON public.employees;
CREATE POLICY "Admins manage employees" ON public.employees
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Managers see department employees" ON public.employees;
CREATE POLICY "Managers see department employees" ON public.employees
  FOR SELECT TO authenticated
  USING (
    private.has_role(auth.uid(), 'manager'::public.app_role)
    AND department_id IN (SELECT e.department_id FROM public.employees e WHERE e.user_id = auth.uid())
  );

-- Prevent privilege escalation on INSERT: users may only create their own minimal profile
DROP POLICY IF EXISTS "Users can create own employee profile" ON public.employees;
CREATE POLICY "Users can create own employee profile" ON public.employees
  FOR INSERT TO authenticated
  WITH CHECK (
    user_id = auth.uid()
    AND manager_id IS NULL
    AND department_id IS NULL
    AND roadmap_level = 'beginner'
  );

-- courses
DROP POLICY IF EXISTS "Admins manage courses" ON public.courses;
CREATE POLICY "Admins manage courses" ON public.courses
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

-- employee_courses
DROP POLICY IF EXISTS "Admins manage course assignments" ON public.employee_courses;
CREATE POLICY "Admins manage course assignments" ON public.employee_courses
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Managers see dept course assignments" ON public.employee_courses;
CREATE POLICY "Managers see dept course assignments" ON public.employee_courses
  FOR SELECT TO authenticated
  USING (
    private.has_role(auth.uid(), 'manager'::public.app_role)
    AND employee_id IN (
      SELECT e.id FROM public.employees e
      WHERE e.department_id IN (SELECT e2.department_id FROM public.employees e2 WHERE e2.user_id = auth.uid())
    )
  );

-- Restrict employee course progress updates to authenticated users only
DROP POLICY IF EXISTS "Employees update own course progress" ON public.employee_courses;
CREATE POLICY "Employees update own course progress" ON public.employee_courses
  FOR UPDATE TO authenticated
  USING (employee_id IN (SELECT employees.id FROM public.employees WHERE employees.user_id = auth.uid()))
  WITH CHECK (employee_id IN (SELECT employees.id FROM public.employees WHERE employees.user_id = auth.uid()));

-- roadmap_phases
DROP POLICY IF EXISTS "Admins manage roadmap" ON public.roadmap_phases;
CREATE POLICY "Admins manage roadmap" ON public.roadmap_phases
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

-- employee_tools
DROP POLICY IF EXISTS "Admins manage tool assignments" ON public.employee_tools;
CREATE POLICY "Admins manage tool assignments" ON public.employee_tools
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

DROP POLICY IF EXISTS "Managers see dept tool assignments" ON public.employee_tools;
CREATE POLICY "Managers see dept tool assignments" ON public.employee_tools
  FOR SELECT TO authenticated
  USING (
    private.has_role(auth.uid(), 'manager'::public.app_role)
    AND employee_id IN (
      SELECT e.id FROM public.employees e
      WHERE e.department_id IN (SELECT e2.department_id FROM public.employees e2 WHERE e2.user_id = auth.uid())
    )
  );

-- ai_tools
DROP POLICY IF EXISTS "Admins manage tools" ON public.ai_tools;
CREATE POLICY "Admins manage tools" ON public.ai_tools
  FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'::public.app_role))
  WITH CHECK (private.has_role(auth.uid(), 'admin'::public.app_role));

-- 3) Drop the public.has_role function so it is no longer reachable via the API
DROP FUNCTION IF EXISTS public.has_role(uuid, public.app_role);
