
-- Function: auto-create employee profile after signup
CREATE OR REPLACE FUNCTION public.create_employee_profile(
  _user_id UUID,
  _full_name TEXT,
  _employee_id TEXT
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _emp_id UUID;
BEGIN
  INSERT INTO public.employees (user_id, full_name, employee_id)
  VALUES (_user_id, _full_name, _employee_id)
  ON CONFLICT (user_id) DO NOTHING
  RETURNING id INTO _emp_id;

  -- Assign default employee role
  INSERT INTO public.user_roles (user_id, role)
  VALUES (_user_id, 'employee')
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN _emp_id;
END;
$$;

-- Function: assign a role to a user (admin only via RPC)
CREATE OR REPLACE FUNCTION public.assign_user_role(
  _target_user_id UUID,
  _role app_role
)
RETURNS VOID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can assign roles';
  END IF;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (_target_user_id, _role)
  ON CONFLICT (user_id, role) DO NOTHING;
END;
$$;

-- Function: admin create full employee record
CREATE OR REPLACE FUNCTION public.admin_create_employee(
  _user_id UUID,
  _full_name TEXT,
  _employee_id TEXT,
  _department_id UUID DEFAULT NULL,
  _job_role TEXT DEFAULT NULL,
  _job_role_ar TEXT DEFAULT NULL,
  _roadmap_level TEXT DEFAULT 'beginner',
  _role app_role DEFAULT 'employee'
)
RETURNS UUID
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
DECLARE
  _emp_id UUID;
BEGIN
  IF NOT public.has_role(auth.uid(), 'admin') THEN
    RAISE EXCEPTION 'Only admins can create employees';
  END IF;

  INSERT INTO public.employees (user_id, full_name, employee_id, department_id, job_role, job_role_ar, roadmap_level)
  VALUES (_user_id, _full_name, _employee_id, _department_id, _job_role, _job_role_ar, _roadmap_level)
  ON CONFLICT (user_id) DO UPDATE SET
    full_name = EXCLUDED.full_name,
    employee_id = EXCLUDED.employee_id,
    department_id = EXCLUDED.department_id,
    job_role = EXCLUDED.job_role,
    job_role_ar = EXCLUDED.job_role_ar,
    roadmap_level = EXCLUDED.roadmap_level
  RETURNING id INTO _emp_id;

  INSERT INTO public.user_roles (user_id, role)
  VALUES (_user_id, _role)
  ON CONFLICT (user_id, role) DO NOTHING;

  RETURN _emp_id;
END;
$$;

-- Policy: let authenticated users insert their own employee record
CREATE POLICY "Users can create own employee profile"
ON public.employees
FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- Policy: let employees update their own profile
CREATE POLICY "Employees can update own profile"
ON public.employees
FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());
