
-- Scope SELECT policies to authenticated only
DROP POLICY "Employees see own profile" ON public.employees;
CREATE POLICY "Employees see own profile" ON public.employees FOR SELECT TO authenticated USING (user_id = auth.uid());

DROP POLICY "Employees see own course assignments" ON public.employee_courses;
CREATE POLICY "Employees see own course assignments" ON public.employee_courses FOR SELECT TO authenticated USING (employee_id IN (SELECT id FROM public.employees WHERE user_id = auth.uid()));

DROP POLICY "Employees see own tool assignments" ON public.employee_tools;
CREATE POLICY "Employees see own tool assignments" ON public.employee_tools FOR SELECT TO authenticated USING (employee_id IN (SELECT id FROM public.employees WHERE user_id = auth.uid()));

DROP POLICY "Users can view own roles" ON public.user_roles;
CREATE POLICY "Users can view own roles" ON public.user_roles FOR SELECT TO authenticated USING (auth.uid() = user_id);

-- Restrict employee self-update to safe columns only (avatar_url, job_role, job_role_ar)
DROP POLICY "Employees can update own profile" ON public.employees;
CREATE POLICY "Employees can update own profile" ON public.employees
  FOR UPDATE TO authenticated
  USING (user_id = auth.uid())
  WITH CHECK (
    user_id = auth.uid()
    AND department_id IS NOT DISTINCT FROM (SELECT department_id FROM public.employees WHERE user_id = auth.uid())
    AND manager_id IS NOT DISTINCT FROM (SELECT manager_id FROM public.employees WHERE user_id = auth.uid())
    AND roadmap_level IS NOT DISTINCT FROM (SELECT roadmap_level FROM public.employees WHERE user_id = auth.uid())
    AND employee_id IS NOT DISTINCT FROM (SELECT employee_id FROM public.employees WHERE user_id = auth.uid())
    AND full_name IS NOT DISTINCT FROM (SELECT full_name FROM public.employees WHERE user_id = auth.uid())
  );
