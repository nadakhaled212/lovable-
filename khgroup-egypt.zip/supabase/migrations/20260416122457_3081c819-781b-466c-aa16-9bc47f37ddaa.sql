
-- 1. Role enum and user_roles table
CREATE TYPE public.app_role AS ENUM ('admin', 'manager', 'employee');

CREATE TABLE public.user_roles (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL,
  role app_role NOT NULL DEFAULT 'employee',
  UNIQUE (user_id, role)
);
ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

-- 2. Security definer function for role checks
CREATE OR REPLACE FUNCTION public.has_role(_user_id UUID, _role app_role)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1 FROM public.user_roles
    WHERE user_id = _user_id AND role = _role
  )
$$;

-- 3. Departments
CREATE TABLE public.departments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  name_ar TEXT,
  goals TEXT,
  goals_ar TEXT,
  recommended_tools TEXT[],
  recommended_courses TEXT[],
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.departments ENABLE ROW LEVEL SECURITY;

-- 4. Employees (profiles)
CREATE TABLE public.employees (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES auth.users(id) ON DELETE CASCADE NOT NULL UNIQUE,
  full_name TEXT NOT NULL,
  employee_id TEXT UNIQUE NOT NULL,
  department_id UUID REFERENCES public.departments(id),
  job_role TEXT,
  job_role_ar TEXT,
  roadmap_level TEXT NOT NULL DEFAULT 'beginner',
  manager_id UUID REFERENCES public.employees(id),
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.employees ENABLE ROW LEVEL SECURITY;

-- 5. AI Tools
CREATE TABLE public.ai_tools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  name TEXT NOT NULL,
  description TEXT,
  description_ar TEXT,
  category TEXT,
  icon_name TEXT DEFAULT 'bot',
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.ai_tools ENABLE ROW LEVEL SECURITY;

-- 6. Courses
CREATE TABLE public.courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  title TEXT NOT NULL,
  title_ar TEXT,
  description TEXT,
  description_ar TEXT,
  level TEXT NOT NULL DEFAULT 'beginner',
  department_id UUID REFERENCES public.departments(id),
  url TEXT,
  duration TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.courses ENABLE ROW LEVEL SECURITY;

-- 7. Employee course assignments
CREATE TABLE public.employee_courses (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID REFERENCES public.employees(id) ON DELETE CASCADE NOT NULL,
  course_id UUID REFERENCES public.courses(id) ON DELETE CASCADE NOT NULL,
  status TEXT NOT NULL DEFAULT 'not_started',
  progress INTEGER NOT NULL DEFAULT 0,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  completed_at TIMESTAMPTZ,
  UNIQUE (employee_id, course_id)
);
ALTER TABLE public.employee_courses ENABLE ROW LEVEL SECURITY;

-- 8. Employee tool assignments
CREATE TABLE public.employee_tools (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  employee_id UUID REFERENCES public.employees(id) ON DELETE CASCADE NOT NULL,
  tool_id UUID REFERENCES public.ai_tools(id) ON DELETE CASCADE NOT NULL,
  assigned_at TIMESTAMPTZ NOT NULL DEFAULT now(),
  UNIQUE (employee_id, tool_id)
);
ALTER TABLE public.employee_tools ENABLE ROW LEVEL SECURITY;

-- 9. Roadmap phases
CREATE TABLE public.roadmap_phases (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  department_id UUID REFERENCES public.departments(id),
  level TEXT NOT NULL,
  title TEXT NOT NULL,
  title_ar TEXT,
  description TEXT,
  description_ar TEXT,
  required_tools TEXT[],
  required_courses TEXT[],
  expected_outcomes TEXT[],
  expected_outcomes_ar TEXT[],
  sort_order INTEGER NOT NULL DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT now()
);
ALTER TABLE public.roadmap_phases ENABLE ROW LEVEL SECURITY;

-- ============ RLS POLICIES ============

-- user_roles: users see own roles, admins see all
CREATE POLICY "Users can view own roles" ON public.user_roles
  FOR SELECT USING (auth.uid() = user_id);

CREATE POLICY "Admins can manage roles" ON public.user_roles
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- departments: employees see own dept, managers/admins see all
CREATE POLICY "Employees see own department" ON public.departments
  FOR SELECT USING (
    EXISTS (
      SELECT 1 FROM public.employees e
      WHERE e.user_id = auth.uid() AND e.department_id = departments.id
    )
    OR public.has_role(auth.uid(), 'admin')
    OR public.has_role(auth.uid(), 'manager')
  );

CREATE POLICY "Admins manage departments" ON public.departments
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- employees: see own record, managers see dept, admins see all
CREATE POLICY "Employees see own profile" ON public.employees
  FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Managers see department employees" ON public.employees
  FOR SELECT USING (
    public.has_role(auth.uid(), 'manager')
    AND department_id IN (
      SELECT e.department_id FROM public.employees e WHERE e.user_id = auth.uid()
    )
  );

CREATE POLICY "Admins manage employees" ON public.employees
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- ai_tools: authenticated users can read
CREATE POLICY "Authenticated users read tools" ON public.ai_tools
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins manage tools" ON public.ai_tools
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- courses: authenticated users can read
CREATE POLICY "Authenticated users read courses" ON public.courses
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins manage courses" ON public.courses
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- employee_courses: see own, managers see dept, admins see all
CREATE POLICY "Employees see own course assignments" ON public.employee_courses
  FOR SELECT USING (
    employee_id IN (SELECT id FROM public.employees WHERE user_id = auth.uid())
  );

CREATE POLICY "Managers see dept course assignments" ON public.employee_courses
  FOR SELECT USING (
    public.has_role(auth.uid(), 'manager')
    AND employee_id IN (
      SELECT e.id FROM public.employees e
      WHERE e.department_id IN (
        SELECT e2.department_id FROM public.employees e2 WHERE e2.user_id = auth.uid()
      )
    )
  );

CREATE POLICY "Employees update own course progress" ON public.employee_courses
  FOR UPDATE USING (
    employee_id IN (SELECT id FROM public.employees WHERE user_id = auth.uid())
  );

CREATE POLICY "Admins manage course assignments" ON public.employee_courses
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- employee_tools: see own, managers see dept, admins see all
CREATE POLICY "Employees see own tool assignments" ON public.employee_tools
  FOR SELECT USING (
    employee_id IN (SELECT id FROM public.employees WHERE user_id = auth.uid())
  );

CREATE POLICY "Managers see dept tool assignments" ON public.employee_tools
  FOR SELECT USING (
    public.has_role(auth.uid(), 'manager')
    AND employee_id IN (
      SELECT e.id FROM public.employees e
      WHERE e.department_id IN (
        SELECT e2.department_id FROM public.employees e2 WHERE e2.user_id = auth.uid()
      )
    )
  );

CREATE POLICY "Admins manage tool assignments" ON public.employee_tools
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- roadmap_phases: authenticated read, admins manage
CREATE POLICY "Authenticated users read roadmap" ON public.roadmap_phases
  FOR SELECT TO authenticated USING (true);

CREATE POLICY "Admins manage roadmap" ON public.roadmap_phases
  FOR ALL USING (public.has_role(auth.uid(), 'admin'));

-- ============ TIMESTAMP TRIGGER ============
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER AS $$
BEGIN
  NEW.updated_at = now();
  RETURN NEW;
END;
$$ LANGUAGE plpgsql SET search_path = public;

CREATE TRIGGER update_departments_updated_at
  BEFORE UPDATE ON public.departments
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_employees_updated_at
  BEFORE UPDATE ON public.employees
  FOR EACH ROW EXECUTE FUNCTION public.update_updated_at_column();

-- ============ SEED DATA ============

-- Departments
INSERT INTO public.departments (id, name, name_ar, goals, goals_ar, recommended_tools, recommended_courses) VALUES
  ('d1000000-0000-0000-0000-000000000001', 'Executive', 'الإدارة التنفيذية', 'Strategic AI adoption and leadership decision-making', 'تبني الذكاء الاصطناعي الاستراتيجي واتخاذ القرارات القيادية', ARRAY['ChatGPT', 'Gamma', 'Notion AI'], ARRAY['AI for Leaders', 'Strategic AI Planning']),
  ('d1000000-0000-0000-0000-000000000002', 'Architecture', 'الهندسة المعمارية', 'AI-enhanced design workflows and visualization', 'تحسين سير عمل التصميم والتصور بالذكاء الاصطناعي', ARRAY['Midjourney', 'SketchUp AI', 'ArchiGAN'], ARRAY['AI in Architecture', 'Generative Design']),
  ('d1000000-0000-0000-0000-000000000003', 'Structural Engineering', 'الهندسة الإنشائية', 'AI-powered structural analysis and optimization', 'التحليل والتحسين الإنشائي بالذكاء الاصطناعي', ARRAY['ETABS AI', 'ChatGPT', 'Python AI'], ARRAY['AI Structural Analysis', 'ML for Engineers']),
  ('d1000000-0000-0000-0000-000000000004', 'HR', 'الموارد البشرية', 'AI-driven recruitment, training, and employee analytics', 'التوظيف والتدريب وتحليل الموظفين بالذكاء الاصطناعي', ARRAY['ChatGPT', 'Notion AI', 'HireVue'], ARRAY['AI in HR', 'People Analytics']),
  ('d1000000-0000-0000-0000-000000000005', 'Finance', 'المالية', 'AI-enhanced financial analysis and forecasting', 'التحليل المالي والتنبؤ المحسن بالذكاء الاصطناعي', ARRAY['ChatGPT', 'Excel Copilot', 'Power BI AI'], ARRAY['AI in Finance', 'Predictive Analytics']),
  ('d1000000-0000-0000-0000-000000000006', 'Marketing', 'التسويق', 'AI content creation, analytics, and campaign optimization', 'إنشاء المحتوى والتحليلات وتحسين الحملات بالذكاء الاصطناعي', ARRAY['ChatGPT', 'Canva AI', 'Jasper'], ARRAY['AI Marketing', 'Content AI Strategy']);

-- AI Tools
INSERT INTO public.ai_tools (name, description, description_ar, category, icon_name) VALUES
  ('ChatGPT', 'AI conversational assistant for text generation and analysis', 'مساعد محادثة ذكي لتوليد النصوص والتحليل', 'General', 'message-square'),
  ('Midjourney', 'AI image generation for design concepts', 'توليد صور بالذكاء الاصطناعي لمفاهيم التصميم', 'Design', 'image'),
  ('Gamma', 'AI-powered presentation and document creation', 'إنشاء عروض ومستندات بالذكاء الاصطناعي', 'Productivity', 'presentation'),
  ('Notion AI', 'AI-enhanced workspace and knowledge management', 'مساحة عمل وإدارة معرفة محسنة بالذكاء الاصطناعي', 'Productivity', 'notebook-pen'),
  ('Canva AI', 'AI-powered graphic design and content creation', 'تصميم جرافيك وإنشاء محتوى بالذكاء الاصطناعي', 'Design', 'palette'),
  ('Excel Copilot', 'AI assistant for spreadsheet analysis and automation', 'مساعد ذكي لتحليل جداول البيانات والأتمتة', 'Analytics', 'table'),
  ('Power BI AI', 'AI-driven business intelligence and data visualization', 'ذكاء أعمال وتصور بيانات بالذكاء الاصطناعي', 'Analytics', 'bar-chart-3'),
  ('Jasper', 'AI marketing content and copywriting tool', 'أداة كتابة محتوى تسويقي بالذكاء الاصطناعي', 'Marketing', 'pen-tool'),
  ('SketchUp AI', 'AI-assisted 3D modeling for architecture', 'نمذجة ثلاثية الأبعاد بمساعدة الذكاء الاصطناعي للعمارة', 'Design', 'box'),
  ('ArchiGAN', 'Generative adversarial network for architectural design', 'شبكة توليدية للتصميم المعماري', 'Design', 'building'),
  ('HireVue', 'AI-powered video interviewing and assessment', 'مقابلات فيديو وتقييم بالذكاء الاصطناعي', 'HR', 'video'),
  ('Python AI', 'Python-based machine learning and automation', 'تعلم آلي وأتمتة مبنية على بايثون', 'Engineering', 'code');

-- Courses
INSERT INTO public.courses (title, title_ar, description, description_ar, level, department_id, duration) VALUES
  ('AI for Leaders', 'الذكاء الاصطناعي للقادة', 'Strategic overview of AI adoption in business', 'نظرة استراتيجية لتبني الذكاء الاصطناعي في الأعمال', 'beginner', 'd1000000-0000-0000-0000-000000000001', '4 hours'),
  ('Strategic AI Planning', 'التخطيط الاستراتيجي للذكاء الاصطناعي', 'Building AI roadmaps for organizations', 'بناء خرائط طريق الذكاء الاصطناعي للمؤسسات', 'intermediate', 'd1000000-0000-0000-0000-000000000001', '6 hours'),
  ('AI in Architecture', 'الذكاء الاصطناعي في العمارة', 'Using AI tools in architectural design workflows', 'استخدام أدوات الذكاء الاصطناعي في التصميم المعماري', 'beginner', 'd1000000-0000-0000-0000-000000000002', '5 hours'),
  ('Generative Design', 'التصميم التوليدي', 'Advanced generative design with AI algorithms', 'التصميم التوليدي المتقدم بخوارزميات الذكاء الاصطناعي', 'advanced', 'd1000000-0000-0000-0000-000000000002', '8 hours'),
  ('AI Structural Analysis', 'التحليل الإنشائي بالذكاء الاصطناعي', 'AI-powered structural engineering analysis', 'التحليل الهندسي الإنشائي بالذكاء الاصطناعي', 'intermediate', 'd1000000-0000-0000-0000-000000000003', '6 hours'),
  ('ML for Engineers', 'تعلم الآلة للمهندسين', 'Machine learning fundamentals for structural engineers', 'أساسيات تعلم الآلة للمهندسين الإنشائيين', 'advanced', 'd1000000-0000-0000-0000-000000000003', '10 hours'),
  ('AI in HR', 'الذكاء الاصطناعي في الموارد البشرية', 'Applying AI in recruitment and talent management', 'تطبيق الذكاء الاصطناعي في التوظيف وإدارة المواهب', 'beginner', 'd1000000-0000-0000-0000-000000000004', '4 hours'),
  ('People Analytics', 'تحليلات الأفراد', 'Data-driven HR decision making with AI', 'اتخاذ قرارات الموارد البشرية القائمة على البيانات بالذكاء الاصطناعي', 'intermediate', 'd1000000-0000-0000-0000-000000000004', '5 hours'),
  ('AI in Finance', 'الذكاء الاصطناعي في المالية', 'AI applications in financial analysis', 'تطبيقات الذكاء الاصطناعي في التحليل المالي', 'beginner', 'd1000000-0000-0000-0000-000000000005', '4 hours'),
  ('Predictive Analytics', 'التحليلات التنبؤية', 'Building predictive models for financial forecasting', 'بناء نماذج تنبؤية للتنبؤ المالي', 'advanced', 'd1000000-0000-0000-0000-000000000005', '8 hours'),
  ('AI Marketing', 'التسويق بالذكاء الاصطناعي', 'AI-driven marketing strategies and tools', 'استراتيجيات وأدوات التسويق بالذكاء الاصطناعي', 'beginner', 'd1000000-0000-0000-0000-000000000006', '4 hours'),
  ('Content AI Strategy', 'استراتيجية محتوى الذكاء الاصطناعي', 'Creating content strategies with AI tools', 'إنشاء استراتيجيات المحتوى باستخدام أدوات الذكاء الاصطناعي', 'intermediate', 'd1000000-0000-0000-0000-000000000006', '5 hours'),
  ('Prompt Engineering Basics', 'أساسيات هندسة الأوامر', 'How to write effective AI prompts', 'كيفية كتابة أوامر ذكاء اصطناعي فعالة', 'beginner', NULL, '3 hours'),
  ('Advanced Prompt Engineering', 'هندسة الأوامر المتقدمة', 'Advanced techniques for AI prompt design', 'تقنيات متقدمة لتصميم أوامر الذكاء الاصطناعي', 'intermediate', NULL, '5 hours'),
  ('AI Ethics & Governance', 'أخلاقيات وحوكمة الذكاء الاصطناعي', 'Understanding ethical AI use in business', 'فهم الاستخدام الأخلاقي للذكاء الاصطناعي في الأعمال', 'beginner', NULL, '3 hours'),
  ('Data Literacy for All', 'محو الأمية البيانية للجميع', 'Understanding data fundamentals for AI readiness', 'فهم أساسيات البيانات للاستعداد للذكاء الاصطناعي', 'beginner', NULL, '4 hours'),
  ('AI Automation Workflows', 'أتمتة سير العمل بالذكاء الاصطناعي', 'Building automated workflows using AI tools', 'بناء سير عمل آلي باستخدام أدوات الذكاء الاصطناعي', 'intermediate', NULL, '6 hours'),
  ('AI Project Management', 'إدارة مشاريع الذكاء الاصطناعي', 'Managing AI implementation projects', 'إدارة مشاريع تطبيق الذكاء الاصطناعي', 'advanced', NULL, '7 hours');

-- Roadmap phases for each department
INSERT INTO public.roadmap_phases (department_id, level, title, title_ar, description, description_ar, required_tools, required_courses, expected_outcomes, expected_outcomes_ar, sort_order) VALUES
  ('d1000000-0000-0000-0000-000000000001', 'beginner', 'AI Awareness', 'الوعي بالذكاء الاصطناعي', 'Understand AI fundamentals and business applications', 'فهم أساسيات الذكاء الاصطناعي وتطبيقاته التجارية', ARRAY['ChatGPT'], ARRAY['AI for Leaders', 'Prompt Engineering Basics'], ARRAY['Understand AI capabilities', 'Use ChatGPT for basic tasks'], ARRAY['فهم إمكانيات الذكاء الاصطناعي', 'استخدام ChatGPT للمهام الأساسية'], 1),
  ('d1000000-0000-0000-0000-000000000001', 'intermediate', 'Strategic Application', 'التطبيق الاستراتيجي', 'Apply AI strategically to business decisions', 'تطبيق الذكاء الاصطناعي استراتيجياً في قرارات العمل', ARRAY['ChatGPT', 'Gamma', 'Notion AI'], ARRAY['Strategic AI Planning', 'AI Ethics & Governance'], ARRAY['Build AI adoption roadmap', 'Lead AI initiatives'], ARRAY['بناء خارطة طريق تبني الذكاء الاصطناعي', 'قيادة مبادرات الذكاء الاصطناعي'], 2),
  ('d1000000-0000-0000-0000-000000000001', 'advanced', 'AI Leadership', 'القيادة بالذكاء الاصطناعي', 'Lead organizational AI transformation', 'قيادة التحول المؤسسي بالذكاء الاصطناعي', ARRAY['ChatGPT', 'Gamma', 'Notion AI', 'Power BI AI'], ARRAY['AI Project Management'], ARRAY['Drive company-wide AI strategy', 'Measure AI ROI'], ARRAY['قيادة استراتيجية الذكاء الاصطناعي على مستوى الشركة', 'قياس عائد الاستثمار في الذكاء الاصطناعي'], 3),
  ('d1000000-0000-0000-0000-000000000002', 'beginner', 'AI Design Basics', 'أساسيات التصميم بالذكاء الاصطناعي', 'Introduction to AI tools in architecture', 'مقدمة في أدوات الذكاء الاصطناعي في العمارة', ARRAY['Midjourney', 'ChatGPT'], ARRAY['AI in Architecture', 'Prompt Engineering Basics'], ARRAY['Generate design concepts with AI', 'Use AI for research'], ARRAY['توليد مفاهيم تصميمية بالذكاء الاصطناعي', 'استخدام الذكاء الاصطناعي للبحث'], 1),
  ('d1000000-0000-0000-0000-000000000002', 'intermediate', 'AI-Enhanced Workflows', 'سير عمل محسن بالذكاء الاصطناعي', 'Integrate AI into daily design workflows', 'دمج الذكاء الاصطناعي في سير العمل اليومي', ARRAY['Midjourney', 'SketchUp AI', 'ChatGPT'], ARRAY['AI Automation Workflows'], ARRAY['Automate repetitive design tasks', 'Create AI-assisted presentations'], ARRAY['أتمتة مهام التصميم المتكررة', 'إنشاء عروض بمساعدة الذكاء الاصطناعي'], 2),
  ('d1000000-0000-0000-0000-000000000002', 'advanced', 'Generative Architecture', 'العمارة التوليدية', 'Master generative design and AI optimization', 'إتقان التصميم التوليدي والتحسين بالذكاء الاصطناعي', ARRAY['Midjourney', 'SketchUp AI', 'ArchiGAN'], ARRAY['Generative Design'], ARRAY['Lead AI-driven design projects', 'Create parametric designs'], ARRAY['قيادة مشاريع تصميم بالذكاء الاصطناعي', 'إنشاء تصاميم بارامترية'], 3);
