import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get("SUPABASE_URL")!;
    const serviceRoleKey = Deno.env.get("SUPABASE_SERVICE_ROLE_KEY")!;
    const supabase = createClient(supabaseUrl, serviceRoleKey, {
      auth: { autoRefreshToken: false, persistSession: false },
    });

    const { email, password, full_name, employee_id, role } = await req.json();

    // Create auth user
    const { data: authData, error: authError } = await supabase.auth.admin.createUser({
      email,
      password,
      email_confirm: true,
    });

    if (authError) {
      // If user exists, get their ID
      if (authError.message?.includes("already been registered")) {
        const { data: { users } } = await supabase.auth.admin.listUsers();
        const existing = users?.find((u: any) => u.email === email);
        if (existing) {
          // Create employee record
          await supabase.from("employees").upsert({
            user_id: existing.id,
            full_name: full_name || "Admin",
            employee_id: employee_id || "ADMIN-001",
          }, { onConflict: "user_id" });

          // Assign role
          await supabase.from("user_roles").upsert({
            user_id: existing.id,
            role: role || "admin",
          }, { onConflict: "user_id,role" });

          return new Response(
            JSON.stringify({ success: true, user_id: existing.id, message: "Existing user updated" }),
            { headers: { ...corsHeaders, "Content-Type": "application/json" } }
          );
        }
      }
      throw authError;
    }

    const userId = authData.user!.id;

    // Create employee record
    await supabase.from("employees").insert({
      user_id: userId,
      full_name: full_name || "Admin",
      employee_id: employee_id || "ADMIN-001",
    });

    // Assign role
    await supabase.from("user_roles").insert({
      user_id: userId,
      role: role || "admin",
    });

    return new Response(
      JSON.stringify({ success: true, user_id: userId }),
      { headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  } catch (error) {
    return new Response(
      JSON.stringify({ error: error.message }),
      { status: 400, headers: { ...corsHeaders, "Content-Type": "application/json" } }
    );
  }
});
