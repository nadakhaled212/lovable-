const DEFAULT_WEBHOOK_URL = "https://nada67.app.n8n.cloud/webhook/chatbot";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

type WebhookFailure = {
  body: unknown;
  status: number;
  url: string;
};

const json = (payload: unknown, status = 200) =>
  new Response(JSON.stringify(payload), {
    status,
    headers: {
      ...corsHeaders,
      "Content-Type": "application/json",
    },
  });

const buildCandidateUrls = (seedUrl: string) => {
  // Use the URL as-is (test or production)
  return [seedUrl];
};

const parseResponseBody = async (response: Response) => {
  const text = await response.text();

  if (!text) {
    return null;
  }

  try {
    return JSON.parse(text);
  } catch {
    return text;
  }
};

const extractReply = (payload: unknown): string | null => {
  if (typeof payload === "string") {
    return payload.trim() || null;
  }

  if (Array.isArray(payload)) {
    for (const item of payload) {
      const nestedReply = extractReply(item);
      if (nestedReply) {
        return nestedReply;
      }
    }
    return null;
  }

  if (payload && typeof payload === "object") {
    const record = payload as Record<string, unknown>;
    const candidates = [record.reply, record.output, record.message, record.text];

    for (const candidate of candidates) {
      if (typeof candidate === "string" && candidate.trim()) {
        return candidate;
      }
    }

    // Fallback: return the first non-empty string value found
    for (const val of Object.values(record)) {
      if (typeof val === "string" && val.trim()) {
        return val;
      }
    }
  }

  return null;
};

const callWebhook = async (url: string, message: string) => {
  const response = await fetch(url, {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      Accept: "application/json",
    },
    body: JSON.stringify({ message }),
  });

  const body = await parseResponseBody(response);
  const reply = extractReply(body);

  if (response.ok && reply) {
    return { ok: true as const, reply, url };
  }

  return {
    ok: false as const,
    failure: {
      body,
      status: response.status,
      url,
    },
  };
};

const resolveErrorCode = (failures: WebhookFailure[]) => {
  const failureText = JSON.stringify(failures).toLowerCase();

  if (failureText.includes("not registered") || failureText.includes("workflow must be active")) {
    return "WORKFLOW_INACTIVE";
  }

  if (failureText.includes("respond to webhook")) {
    return "INVALID_RESPONSE";
  }

  return "WEBHOOK_UNAVAILABLE";
};

Deno.serve(async (request) => {
  if (request.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  if (request.method !== "POST") {
    return json({ error: "METHOD_NOT_ALLOWED" }, 405);
  }

  try {
    const { message } = await request.json();

    if (typeof message !== "string" || !message.trim()) {
      return json({ error: "INVALID_MESSAGE" }, 400);
    }

    const configuredUrl = Deno.env.get("N8N_CHATBOT_WEBHOOK_URL") ?? DEFAULT_WEBHOOK_URL;
    const failures: WebhookFailure[] = [];

    for (const url of buildCandidateUrls(configuredUrl)) {
      try {
        const result = await callWebhook(url, message.trim());

        if (result.ok) {
          return json({ reply: result.reply });
        }

        failures.push(result.failure);
      } catch (error) {
        failures.push({
          body: error instanceof Error ? error.message : "Unknown error",
          status: 500,
          url,
        });
      }
    }

    console.error("chatbot-webhook failed", failures);

    return json({ error: resolveErrorCode(failures) });
  } catch (error) {
    console.error("chatbot-webhook unexpected error", error);
    return json({ error: "WEBHOOK_UNAVAILABLE" });
  }
});